import { Component, OnInit } from '@angular/core';
import { TokenStorageService } from './_services/token-storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  private roles: string[] = [];
  isLoggedIn = false;
  isAdmin = false;
  showModeratorBoard = false;
  userName: string = '';

  constructor(private tokenStorageService: TokenStorageService) { }

  ngOnInit(): void {
    this.isLoggedIn = !!this.tokenStorageService.getToken();

    if (this.isLoggedIn) {
      const user = this.tokenStorageService.getUser();
      this.roles = user.roles;

      this.isAdmin = this.roles.includes('Admin');
      this.showModeratorBoard = this.roles.includes('TestModerator');

      this.userName = user.userName;
    }
  }

  logout(): void {
    this.tokenStorageService.signOut();
    location.reload();
  }
}
