import { Component, Input } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { atLeastOneCheckboxSelected } from '../validators';

@Component({
  selector: 'app-add-questions',
  templateUrl: './add-questions.component.html',
  styleUrls: ['./add-questions.component.css']
})
export class AddQuestionsComponent {

  @Input() questions: FormArray<FormGroup> = new FormArray<FormGroup>([]);
  @Input() isFormSubmitted = false;
  page: number = 1;

  addQuestion() {
    const questionForm = new FormGroup({
      questionText: new FormControl('', Validators.required),
      points: new FormControl('', [Validators.required, Validators.min(1)]),
      answers: new FormArray<FormGroup>([this.createAnswerFormGroup()],
        [Validators.required, atLeastOneCheckboxSelected])
    })

    this.questions.push(questionForm);
  }

  deleteQuestion(questionIndex: number) {
    this.questions.removeAt(questionIndex);
  }

  getAnswersControls(questionForm: FormGroup): FormArray<FormGroup> {
    return questionForm.controls['answers'] as FormArray<FormGroup>;
  }

  addAnswer(questionForm: FormGroup) {
    const answers = this.getAnswersControls(questionForm);
    answers.push(this.createAnswerFormGroup());
  }

  deleteAnswer(questionForm: FormGroup, answerIndex: number) {
    const answers = this.getAnswersControls(questionForm);
    answers.removeAt(answerIndex);
  }

  createAnswerFormGroup(): FormGroup {
    return new FormGroup({
      answerText: new FormControl('', Validators.required),
      isCorrect: new FormControl(false)
    });
  }
}