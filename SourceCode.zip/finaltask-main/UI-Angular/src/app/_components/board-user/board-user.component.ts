import { Component, ViewChild } from '@angular/core';
import FilterTest from 'src/app/_models/filter-test.model';
import { TestService } from 'src/app/_services/test.service';
import { TestsComponent } from '../tests/tests.component';
import { map } from 'rxjs';

@Component({
  selector: 'app-board-user',
  templateUrl: './board-user.component.html',
  styleUrls: ['./board-user.component.css']
})
export class BoardUserComponent {

  filterTest: FilterTest = new FilterTest();

  @ViewChild(TestsComponent, { static: false })
  testsComponent: TestsComponent | undefined;

  constructor(private testService: TestService) { }

  filter(): void {
    if (this.testsComponent) {
      this.testsComponent.tests$ = this.testService.getTestsByFilter(this.filterTest)
        .pipe(
          map(tests => tests.filter(test => test.questionCount > 0))
        );
      this.testsComponent.trigger();
    }
  }
}
