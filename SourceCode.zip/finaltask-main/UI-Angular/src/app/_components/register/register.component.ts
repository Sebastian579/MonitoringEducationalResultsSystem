import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AuthService } from 'src/app/_services/auth.service';
import { Validation } from '../validators';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  myForm: FormGroup = new FormGroup({});
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage: string[] = [];

  constructor(private authService: AuthService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.myForm = this.formBuilder.group({
      firstname: [''],
      lastname: [''],
      username: ['', [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(20)
      ]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(40)
      ]],
      confirmedPassword: ['', [Validators.required]]
    },
      {
        validators: [Validation.match('password', 'confirmedPassword')]
      }
    );
  }

  get f(): { [key: string]: AbstractControl } {
    return this.myForm.controls;
  }

  onSubmit(): void {
    this.authService.register(this.myForm.value).subscribe({
      next: data => {
        this.isSuccessful = true;
        this.isSignUpFailed = false;
      },
      error: err => {
        this.isSignUpFailed = true;
        this.errorMessage = [];
        console.log(err);
        for (let error of err.error.errors)
          this.errorMessage.push(error.description);
      }
    });
  }
}
