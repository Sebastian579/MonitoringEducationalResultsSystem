import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import Question from 'src/app/_models/question.model';
import Answer from 'src/app/_models/answer.model';
import Test from 'src/app/_models/test.model';
import { TestService } from 'src/app/_services/test.service';
import { TokenStorageService } from 'src/app/_services/token-storage.service';
import { atLeastOneCheckboxSelected, combinedPointsSumValidator, pointsSumValidator } from '../validators';
import { AIService } from 'src/app/_services/ai.service';

@Component({
  selector: 'app-edit-test',
  templateUrl: './edit-test.component.html',
  styleUrls: ['./edit-test.component.css']
})
export class EditTestComponent implements OnInit, OnDestroy {

  sub$: Subscription = new Subscription();
  myForm: FormGroup = new FormGroup({});
  test: Test | null = null;
  isFailed = false;
  isSuccessful = false;
  errorMessage: string[] = [];
  testQuestions: Array<Question> = [];
  isQuestionAddingFailde = false;
  isQuestionEditingFailed = false;
  isModerator = false;
  isAdmin = false;
  page: number = 1;
  isLoading = false;

  constructor(
    private route: ActivatedRoute,
    private testService: TestService,
    private aiService: AIService,
    private formBuilder: FormBuilder,
    private router: Router,
    private storageService: TokenStorageService) { }

  ngOnInit(): void {
    this.myForm = this.formBuilder.group({
      id: ['', [Validators.required]],
      name: ['', [Validators.required]],
      executionTime: ['', [
        Validators.required,
        Validators.min(5),
        Validators.max(600)
      ]],
      passScore: ['', [
        Validators.required,
        Validators.min(1)
      ]],
      description: [''],
      addQuestions: this.formBuilder.array([]),
      editQuestions: this.formBuilder.array([])
    });

    this.myForm.setValidators(combinedPointsSumValidator(this.addQuestions, this.editQuestions, this.myForm.get('passScore')!));

    const user = this.storageService.getUser();
    const testId = this.route.snapshot.params['id'];
    this.isModerator = user.roles.includes('TestModerator');
    this.isAdmin = user.roles.includes('Admin');
    this.sub$.add(this.testService.getTest(testId).subscribe({
      next: data => {
        if (data.userId === user.id || this.isModerator || this.isAdmin) {
          this.test = data;
          this.myForm.patchValue({
            id: this.test.id,
            name: this.test.name,
            executionTime: this.test.executionTime,
            passScore: this.test.passScore
          });
          this.sub$.add(this.testService.getQuestionsByTest(this.test.id).subscribe({
            next: data => {
              this.testQuestions = data;
              for (let question of this.testQuestions) {
                const questionForm = this.setQuestion(question);
                const answersFormArray = questionForm.controls['answers'] as FormArray<FormGroup>;

                this.sub$.add(this.testService.getAnswersByQuestion(question.id).subscribe({
                  next: data => {
                    question.answers = data;
                    for (let answer of question.answers) {
                      this.setAnswer(answer, answersFormArray);
                    }
                  }
                }))
              }
            }
          }));
        }
      }
    }));
  }

  get f(): { [key: string]: AbstractControl } {
    return this.myForm.controls;
  }

  get addQuestions() {
    return this.myForm.controls['addQuestions'] as FormArray<FormGroup>;
  }

  get editQuestions() {
    return this.myForm.controls['editQuestions'] as FormArray<FormGroup>;
  }

  getAnswersControls(questionForm: FormGroup): FormArray<FormGroup> {
    return questionForm.controls['answers'] as FormArray<FormGroup>;
  }

  onSubmit(): void {
    const test = {
      name: this.myForm.value.name,
      executionTime: this.myForm.value.executionTime,
      passScore: this.myForm.value.passScore
    };

    this.errorMessage = [];
    this.isQuestionEditingFailed = false;
    this.isQuestionAddingFailde = false;
    this.isFailed = false;

    this.testService.updateTest(this.myForm.value.id, test).subscribe({
      next: data => {
        this.isSuccessful = true;
      },
      error: err => {
        this.isSuccessful = false;
        this.isFailed = true;
        this.errorMessage.push('Test editing was failed');
      }
    });

    if (this.addQuestions.length > 0) {
      this.testService.addQuestions(this.myForm.value.id, this.myForm.value.addQuestions).subscribe({
        next: data => {
          for (let question of data) {
            const questionForm = this.setQuestion(question);
            const answersFormArray = questionForm.controls['answers'] as FormArray<FormGroup>;

            for (let answer of question.answers) {
              this.setAnswer(answer, answersFormArray);
            }
          }
          this.addQuestions.clear();
        },
        error: err => {
          this.isQuestionAddingFailde = true;
          this.errorMessage.push('Questions adding was failed');
        }
      });
    }

    if (this.editQuestions.length > 0) {
      this.testService.updateQuestions(this.myForm.value.id, this.myForm.value.editQuestions).subscribe({
        error: err => {
          this.isQuestionEditingFailed = true;
          this.errorMessage.push('Questions editing was failed');
        }
      });
    }
  }

  deleteTest(): void {
    if (confirm("Are you sure to delete " + this.myForm.value.name + " test"))
      this.testService.deleteTest(this.myForm.value.id).subscribe({
        next: data => {
          if (this.isModerator || this.isAdmin)
            this.router.navigate(['/mod']);
          else
            this.router.navigate(['/profile']);
        },
        error: err => {
          this.errorMessage = [];
          this.isSuccessful = false;
          this.isFailed = true;
        }
      });
  }

  setQuestion(question: Question): FormGroup {
    const questionForm = this.formBuilder.group({
      id: [question.id, [Validators.required]],
      questionText: [question.questionText, [Validators.required]],
      points: [question.points, [
        Validators.required,
        Validators.min(1)
      ]],
      answers: this.formBuilder.array([], [Validators.required, atLeastOneCheckboxSelected])
    })

    this.editQuestions.push(questionForm);
    return questionForm;
  }

  deleteQuestion(questionId: string, index: number): void {
    if (confirm("Are you sure to delete the question")) {
      this.testService.deleteQuestion(this.myForm.value.id, questionId).subscribe({
        next: data => {
          this.editQuestions.removeAt(index);
        }
      });
    }
  }

  setAnswer(answer: Answer, answersFormArray: FormArray<FormGroup>) {
    const answerForm = this.formBuilder.group({
      id: [answer.id, [Validators.required]],
      answerText: [answer.answerText, Validators.required],
      isCorrect: [answer.isCorrect]
    })

    answersFormArray.push(answerForm);
  }

  deleteAnswer(questionId: string, index: number, answerId: string, answersFormArray: FormArray<FormGroup>): void {
    if (answersFormArray.length > 0) {
      if (!answerId) {
        answersFormArray.removeAt(index);
      }
      else if (confirm("Are you sure to delete the answer")) {
        this.testService.deleteAnswer(questionId, answerId).subscribe({
          next: data => {
            answersFormArray.removeAt(index);
          }
        });
      }
    }
  }

  addAnswer(questionForm: FormGroup) {
    const answers = this.getAnswersControls(questionForm);
    answers.push(this.createAnswerFormGroup());
  }

  createAnswerFormGroup(): FormGroup {
    return this.formBuilder.group({
      answerText: ['', Validators.required],
      isCorrect: [false]
    })
  }

  generateTest(): void {
    this.isLoading = true;
    const description = this.myForm.value.description;

    this.sub$.add(this.aiService.generateTest(description).subscribe({
      next: data => {
        this.addQuestions.clear();
        data.questions.forEach((question: any) => {
          this.addQuestions.push(this.formBuilder.group({
            questionText: [question.questionText, Validators.required],
            points: [question.points, [Validators.required, Validators.min(1)]],
            answers: this.formBuilder.array(question.answers.map((answer: any) => this.formBuilder.group({
              answerText: [answer.answerText, Validators.required],
              isCorrect: [answer.isCorrect]
            })), [Validators.required, atLeastOneCheckboxSelected])
          }));
        });
        this.isLoading = false;
      },
      error: err => {
        this.isFailed = true;
        this.isLoading = false;
      }
    }));
  }

  ngOnDestroy(): void {
    this.sub$.unsubscribe();
  }
}