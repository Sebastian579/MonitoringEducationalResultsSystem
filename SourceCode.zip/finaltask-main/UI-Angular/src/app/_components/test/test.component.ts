import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import Question from 'src/app/_models/question.model';
import Test from 'src/app/_models/test.model';
import UserAnswer from 'src/app/_models/userAnswer.model';
import { TestService } from 'src/app/_services/test.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit, OnDestroy {

  sub$: Subscription = new Subscription();
  test: Test | null = null;
  timeLeft: number = 0;
  interval: any;
  isStart = false;
  questions: Array<Question> = [];
  userAnswers: UserAnswer[] = [];
  isTestFinish = false;
  userScore: number = 0;
  isPass = false;
  page: number = 1;

  constructor(private activateRoute: ActivatedRoute, private testService: TestService) { }

  ngOnInit(): void {
    const testId = this.activateRoute.snapshot.params['id'];

    this.sub$.add(this.testService.getTest(testId).subscribe({
      next: data => {
        this.test = data;
        this.timeLeft = this.test.executionTime * 60;
      }
    }));
  }

  startTimer(): void {
    if (this.test) {
      this.sub$.add(this.testService.getQuestionsByTest(this.test.id, true).subscribe({
        next: data => {
          this.questions = data;
          for (let question of this.questions) {
            this.userAnswers.push(new UserAnswer('', '', Array(question.answers.length).fill(false), question.id));
          }
          this.isStart = true;
          this.interval = setInterval(() => {
            if (this.timeLeft > 0)
              this.timeLeft--;
            else
              this.onSubmit()
          }, 1000);
        }
      }));
    }
  }

  onSubmit(): void {
    if (this.test) {
      clearInterval(this.interval);
      this.testService.checkAnswers(this.test.id, this.userAnswers).subscribe({
        next: data => {
          this.userScore = data;
          this.isStart = false;
          this.isTestFinish = true;
          if (this.userScore >= this.test!.passScore)
            this.isPass = true;
        }
      });
    }
  }

  ngOnDestroy(): void {
    this.sub$.unsubscribe();
  }
}
