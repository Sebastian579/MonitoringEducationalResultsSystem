import { AbstractControl, FormArray, ValidationErrors, ValidatorFn } from "@angular/forms";


export class Validation {
    static match(controlName: string, checkControlName: string): ValidatorFn {
        return (controls: AbstractControl) => {
            const control = controls.get(controlName);
            const checkControl = controls.get(checkControlName);

            if (checkControl?.errors && !checkControl.errors['matching']) {
                return null;
            }

            if (control?.value !== checkControl?.value) {
                controls.get(checkControlName)?.setErrors({ matching: true });
                return { matching: true };
            } else {
                return null;
            }
        };
    }
}

export function atLeastOneCheckboxSelected(control: FormArray): { [key: string]: boolean } | null {
    const selectedCheckboxCount = control.controls
        .filter((answerControl) => answerControl.get('isCorrect')?.value === true)
        .length;

    if (selectedCheckboxCount < 1) {
        return { noCheckboxSelected: true };
    }

    return null;
}

export function pointsSumValidator(passScoreControl: AbstractControl): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
        const formArray = control as FormArray;
        const totalPoints = formArray.controls.reduce((sum, ctrl) => sum + (ctrl.get('points')?.value || 0), 0);
        const passScore = passScoreControl.value;
        return totalPoints >= passScore ? null : { pointsSumValidator: true };
    };
}

export function combinedPointsSumValidator(addQuestions: FormArray, editQuestions: FormArray, passScoreControl: AbstractControl): ValidatorFn {
    return (): ValidationErrors | null => {
        const totalPoints = [...addQuestions.controls, ...editQuestions.controls]
            .reduce((sum, ctrl) => sum + (ctrl.get('points')?.value || 0), 0);
        const passScore = passScoreControl.value;
        return totalPoints >= passScore ? null : { combinedPointsSumValidator: true };
    };
}