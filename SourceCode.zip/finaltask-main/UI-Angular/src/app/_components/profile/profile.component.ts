import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import Test from 'src/app/_models/test.model';
import { TestService } from 'src/app/_services/test.service';
import { TokenStorageService } from 'src/app/_services/token-storage.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  isHavePermission = false;
  currentUser: any;
  testsByUserId$: Observable<Test[]> | null = null;

  constructor(private tokenService: TokenStorageService, private testService: TestService) { }

  ngOnInit(): void {
    this.currentUser = this.tokenService.getUser();
    this.isHavePermission = this.currentUser.roles
      .some((role: string) => ['Admin', 'TestModerator', 'Teacher'].includes(role));

    if (this.isHavePermission) {
      this.testsByUserId$ = this.testService.getTestsByUserId(this.currentUser.id);
    }
  }
}
