import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AIService } from 'src/app/_services/ai.service';
import { TestService } from 'src/app/_services/test.service';
import { atLeastOneCheckboxSelected, pointsSumValidator } from '../validators';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-test',
  templateUrl: './add-test.component.html',
  styleUrls: ['./add-test.component.css']
})
export class AddTestComponent implements OnInit, OnDestroy  {

  sub$: Subscription = new Subscription();
  myForm: FormGroup = new FormGroup({});
  newTestId: string = '';
  isFailed = false;
  isLoading = false;

  constructor(
    private testService: TestService,
    private aiService: AIService,
    private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.myForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      executionTime: ['', [
        Validators.required,
        Validators.min(5),
        Validators.max(600)
      ]],
      passScore: ['', [
        Validators.required,
        Validators.min(1)
      ]],
      description: [''],
      questions: this.formBuilder.array([])
    });

    this.questions.setValidators(pointsSumValidator(this.myForm.get('passScore')!));

    this.sub$.add(this.myForm.get('passScore')?.valueChanges.subscribe(() => {
      this.questions.updateValueAndValidity();
    }));
  }

  get f(): { [key: string]: AbstractControl } {
    return this.myForm.controls;
  }

  get questions() {
    return this.myForm.controls['questions'] as FormArray<FormGroup>;
  }

  onSubmit(): void {
    const test = {
      name: this.myForm.value.name,
      executionTime: this.myForm.value.executionTime,
      passScore: this.myForm.value.passScore
    };

    this.testService.addTest(test).subscribe({
      next: data => {
        this.newTestId = data.id;
        if (this.questions.length > 0) {
          this.testService.addQuestions(this.newTestId, this.myForm.value.questions).subscribe({
            next: response => {
              this.isFailed = false;
            },
            error: ex => {
              this.isFailed = true;
            }
          });
        }
      },
      error: err => {
        this.isFailed = true;
      }
    });
  }

  generateTest(): void {
    this.isLoading = true;
    const description = this.myForm.value.description;
    this.sub$.add(this.aiService.generateTest(description).subscribe({
      next: data => {
        this.myForm.patchValue({
          name: data.name,
          executionTime: data.executionTime,
          passScore: data.passScore
        });

        this.questions.clear();
        data.questions.forEach((question: any) => {
          this.questions.push(this.formBuilder.group({
            questionText: [question.questionText, Validators.required],
            points: [question.points, [Validators.required, Validators.min(1)]],
            answers: this.formBuilder.array(question.answers.map((answer: any) => this.formBuilder.group({
              answerText: [answer.answerText, Validators.required],
              isCorrect: [answer.isCorrect]
            })), [Validators.required, atLeastOneCheckboxSelected])
          }));
        });
        this.isLoading = false;
      },
      error: err => {
        this.isFailed = true;
        this.isLoading = false;
      }
    }));
  }

  ngOnDestroy(): void {
    this.sub$.unsubscribe();
  }
}
