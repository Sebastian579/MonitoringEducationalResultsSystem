import { Component, Input, OnInit } from '@angular/core';
import { Observable, map } from 'rxjs';
import Test from 'src/app/_models/test.model';

import { TestService } from 'src/app/_services/test.service';

@Component({
  selector: 'app-tests',
  templateUrl: './tests.component.html',
  styleUrls: ['./tests.component.css']
})
export class TestsComponent implements OnInit {

  searchText: string = '';
  @Input() tests$: Observable<Test[]> | null = null;
  filteredTests$: Observable<Test[]> | null = null;
  tempTests$: Observable<Test[]> | null = null;
  @Input() isForCommonView = true;
  page: number = 1;
  orderCount = 0;
  property = '';

  constructor(private testService: TestService) { }

  ngOnInit(): void {
    if (!this.tests$) {
      this.tests$ = this.testService.getTests().pipe(
        map(tests => tests.filter(test => this.isForCommonView ? test.questionCount > 0 : true))
      );
    }

    this.trigger();
  }

  search(): void {
    if (this.searchText.length > 0 && this.tests$) {
      this.filteredTests$ = this.tests$.pipe(
        map(tests => tests.filter(test => test.name.toLowerCase().includes(this.searchText.toLowerCase()))));
      this.tempTests$ = this.filteredTests$;
      this.orderCount = 0;
      return;
    }

    this.trigger();
  }

  sort(property: string): void {
    if (this.orderCount === 0) {
      if (this.searchText.length > 0) {
        this.filteredTests$ = this.tempTests$;
      }
      else
        this.filteredTests$ = this.tests$;
      return;
    }

    if (this.filteredTests$) {
      this.filteredTests$ = this.filteredTests$.pipe(
        map(tests => {
          const sortedTests = tests.slice();
          sortedTests.sort((a, b) => {
            let comparison = 0;
            if (property === 'executionTime' || property === 'passScore'
              || property === 'passPercentage' || property === 'questionCount') {
              comparison = a[property] - b[property];
            } else if (property === 'name') {
              comparison = a.name.localeCompare(b.name);
            } else if (property === 'creationDate') {
              comparison = new Date(a.creationDate).getTime() - new Date(b.creationDate).getTime();
            }

            return comparison;
          });

          if (this.orderCount === 1) {
            sortedTests.reverse();
          }

          return sortedTests;
        })
      );
    }
  }

  toggleSortOrder(property: string): void {
    if (this.property !== property) {
      this.property = property;
      this.orderCount = 1;
    } else {
      this.orderCount++;
      if (this.orderCount === 2) {
        this.orderCount = -1;
      }
    }

    this.sort(property);
  }


  trigger(): void {
    this.orderCount = 0;
    this.filteredTests$ = this.tests$;
  }
}