import { Component, ViewChild } from '@angular/core';
import { TestsComponent } from '../tests/tests.component';
import { map } from 'rxjs';

@Component({
  selector: 'app-board-moderator',
  templateUrl: './board-moderator.component.html',
  styleUrls: ['./board-moderator.component.css']
})
export class BoardModeratorComponent {

  startDate: Date | string = "";
  endDate: Date | string = "";

  @ViewChild(TestsComponent, { static: false })
  testsComponent: TestsComponent | undefined;

  filter(): void {
    if (this.testsComponent?.tests$) {
      this.testsComponent.tests$ = this.testsComponent.tests$.pipe(
        map(tests => tests.filter(test =>
          new Date(test.creationDate) >= new Date(this.startDate === '' ? test.creationDate : this.startDate)
          && new Date(test.creationDate) <= new Date(this.endDate === '' ? test.creationDate : this.endDate)
        ))
      );
      this.testsComponent.trigger();
    }
  }
}
