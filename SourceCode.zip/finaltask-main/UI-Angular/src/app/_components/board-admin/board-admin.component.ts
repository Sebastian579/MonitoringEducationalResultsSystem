import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';

import Role from 'src/app/_models/role.model';
import User from 'src/app/_models/user.model';
import { RoleService } from 'src/app/_services/role.service';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-board-admin',
  templateUrl: './board-admin.component.html',
  styleUrls: ['./board-admin.component.css']
})
export class BoardAdminComponent implements OnInit, OnDestroy {

  sub$: Subscription = new Subscription();
  users$: Observable<User[]> | null = null;
  roles: Role[] = [];
  roleName: string = '';
  userPage: number = 1;
  rolePage: number = 1;

  constructor(private userService: UserService, private roleService: RoleService) { }

  ngOnInit(): void {
    this.users$ = this.userService.getUsers();

    this.sub$.add(this.roleService.getRoles().subscribe({
      next: data => {
        this.roles = data;
      }
    }));
  }

  addRole(): void {
    if (this.roleName.length > 0) {
      this.roleService.addRole(this.roleName).subscribe({
        next: data => {
          this.roles.push(new Role(this.roleName));
        }
      });
    }
  }

  deleteRole(roleName: string): void {
    if (confirm('Are you sure to delete the role?')) {
      this.roleService.deleteRole(roleName).subscribe({
        next: data => {
          this.roles.splice(this.roles.findIndex(r => r.name === roleName), 1);
        }
      });
    }
  }

  ngOnDestroy(): void {
    this.sub$.unsubscribe();
  }
}
