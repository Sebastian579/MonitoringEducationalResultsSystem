import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import Role from 'src/app/_models/role.model';
import User from 'src/app/_models/user.model';
import { RoleService } from 'src/app/_services/role.service';
import { TokenStorageService } from 'src/app/_services/token-storage.service';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit, OnDestroy {

  sub$: Subscription = new Subscription();
  myForm: FormGroup = new FormGroup({});
  user: User | null = null;
  isFailed = false;
  isSuccessful = false;
  isAdmin = false;
  roleName: string = '';
  errorMessage: string = '';
  isRoleSuccessful = false;
  roles$: Observable<Role[]> | null = null;
  page: number = 1;

  constructor(private activateRoute: ActivatedRoute, private userService: UserService, private roleService: RoleService,
    private formBuilder: FormBuilder, private storageService: TokenStorageService, private router: Router) { }

  ngOnInit(): void {
    this.myForm = this.formBuilder.group({
      id: ['', Validators.required],
      firstName: [''],
      lastName: [''],
      userName: ['', [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(20)
      ]],
      email: ['', [Validators.required, Validators.email]],
    });

    this.roles$ = this.roleService.getRoles();

    const loggedUser = this.storageService.getUser();
    this.isAdmin = loggedUser.roles.includes('Admin');
    const userName = this.activateRoute.snapshot.params['userName'];
    this.sub$.add(this.userService.getuser(userName).subscribe({
      next: data => {
        if (data.id === loggedUser.id || this.isAdmin) {
          this.user = data;
          this.myForm.patchValue({
            id: this.user.id,
            firstName: this.user.firstName,
            lastName: this.user.lastName,
            userName: this.user.userName,
            email: this.user.email
          });
        }
      }
    }));
  }

  get f(): { [key: string]: AbstractControl } {
    return this.myForm.controls;
  }

  onSubmit(): void {
    this.userService.updateUser(this.myForm.value.userName, this.myForm.value).subscribe({
      next: data => {
        this.isSuccessful = true;
        this.isFailed = false;
        if (this.user && this.user.userName == this.storageService.getUser().userName) {
          this.user.firstName = this.myForm.value.firstName;
          this.user.lastName = this.myForm.value.lastName;
          this.user.email = this.myForm.value.email;
          this.storageService.saveUser(this.user);
        }
      },
      error: err => {
        this.isSuccessful = false;
        this.isFailed = true;
      }
    });
  }

  deleteUser(): void {
    if (confirm('Are you sure?')) {
      this.userService.deleteUser(this.myForm.value.userName).subscribe({
        next: data => {
          if (this.user && this.user.userName == this.storageService.getUser().userName) {
            this.storageService.signOut();
            location.reload();
          }
          this.router.navigate(['/admin']);
        },
        error: err => {
          this.isSuccessful = false;
          this.isFailed = true;
        }
      });
    }
  }

  addRole(): void {
    if (this.roleName.length > 0) {
      this.userService.addRoleToUser(this.myForm.value.userName, this.roleName).subscribe({
        next: data => {
          this.errorMessage = '';
          this.isRoleSuccessful = true;
          if (this.user && this.user.userName == this.storageService.getUser().userName) {
            this.user.roles.push(this.roleName);
            this.storageService.saveUser(this.user);
          }
        },
        error: err => {
          this.isRoleSuccessful = false;
          this.errorMessage = err.error;
        }
      });
    }
  }

  removeRole(): void {
    if (this.roleName.length > 0 && confirm("Are you sure?")) {
      this.userService.removeRoleFromUser(this.myForm.value.userName, this.roleName).subscribe({
        next: data => {
          this.errorMessage = '';
          this.isRoleSuccessful = true;
          if (this.user && this.user.userName == this.storageService.getUser().userName) {
            this.user.roles = this.user.roles.filter(role => role !== this.roleName);
            this.storageService.saveUser(this.user);
          }
        },
        error: err => {
          this.isRoleSuccessful = false;
          this.errorMessage = err.error;
        }
      });
    }
  }

  ngOnDestroy(): void {
    this.sub$.unsubscribe();
  }
}
