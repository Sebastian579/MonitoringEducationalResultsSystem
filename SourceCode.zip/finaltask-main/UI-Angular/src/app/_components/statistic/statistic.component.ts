import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable, map } from 'rxjs';
import Question from 'src/app/_models/question.model';
import Test from 'src/app/_models/test.model';
import User from 'src/app/_models/user.model';
import { StatisticService } from 'src/app/_services/statistic.service';
import { TokenStorageService } from 'src/app/_services/token-storage.service';
import { TestsComponent } from '../tests/tests.component';

@Component({
  selector: 'app-statistic',
  templateUrl: './statistic.component.html',
  styleUrls: ['./statistic.component.css']
})
export class StatisticComponent implements OnInit {

  @ViewChild(TestsComponent, { static: false })
  testsComponent: TestsComponent | undefined;

  count?: number;
  isAdmin = false;
  isModerator = false;
  choice: string = '';
  tests$: Observable<Test[]> | null = null;
  questions$: Observable<Question[]> | null = null;
  users$: Observable<User[]> | null = null;
  pagePopularTests: number = 1;
  pageValuableQuestions: number = 1;
  pageUsers: number = 1;

  constructor(private statisticService: StatisticService, private storageService: TokenStorageService) { }

  ngOnInit(): void {
    const loggedUser = this.storageService.getUser();
    this.isAdmin = loggedUser.roles.includes('Admin');
    this.isModerator = loggedUser.roles.includes('TestModerator');
  }

  popularTests(): void {
    this.choice = 'test';
    this.tests$ = this.statisticService.getPopularTests(this.count)
      .pipe(
        map(tests => tests.filter(test => test.questionCount > 0))
      );
    if (this.testsComponent) {
      this.testsComponent.tests$ = this.tests$;
      this.testsComponent.trigger();
    }
  }

  valuableQuestions(): void {
    this.choice = 'question';
    this.questions$ = this.statisticService.getValuableQuestions(this.count);
  }

  testCreators(): void {
    this.choice = 'user';
    this.pageUsers = 1;
    this.users$ = this.statisticService.getTestCreators(this.count);
  }

  activeUsers(): void {
    this.choice = 'user';
    this.pageUsers = 1;
    this.users$ = this.statisticService.getActiveUsers(this.count);
  }

  successfulUsers(): void {
    this.choice = 'user';
    this.pageUsers = 1;
    this.users$ = this.statisticService.getSuccessfulUsers(this.count);
  }
}
