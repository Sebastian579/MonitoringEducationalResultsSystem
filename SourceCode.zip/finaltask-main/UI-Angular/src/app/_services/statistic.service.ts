import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import Question from '../_models/question.model';
import Test from '../_models/test.model';
import User from '../_models/user.model';

const AUTH_API = environment.baseApiUrl + 'statistic/';

@Injectable({
  providedIn: 'root'
})
export class StatisticService {

  constructor(private httpClient: HttpClient) { }

  getTestCreators(count?: number): Observable<User[]> {
    return this.httpClient.get<User[]>(AUTH_API + 'user/creator?userCount=' + (Math.floor(count ?? 0)));
  }

  getActiveUsers(count?: number): Observable<User[]> {
    return this.httpClient.get<User[]>(AUTH_API + 'user/active?userCount=' + (Math.floor(count ?? 0)));
  }

  getSuccessfulUsers(count?: number): Observable<User[]> {
    return this.httpClient.get<User[]>(AUTH_API + 'user/successful?userCount=' + (Math.floor(count ?? 0)));
  }

  getPopularTests(count?: number): Observable<Test[]> {
    return this.httpClient.get<Test[]>(AUTH_API + 'test?testCount=' + (Math.floor(count ?? 0)));
  }

  getValuableQuestions(count?: number): Observable<Question[]> {
    return this.httpClient.get<Question[]>(AUTH_API + 'question?questionCount=' + (Math.floor(count ?? 0)));
  }
}