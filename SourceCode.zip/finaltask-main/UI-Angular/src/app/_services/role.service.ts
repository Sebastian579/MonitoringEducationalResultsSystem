import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { first, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import Role from '../_models/role.model';

const AUTH_API = environment.baseApiUrl + 'role/';

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  constructor(private httpClient: HttpClient) { }

  getRoles(): Observable<Role[]> {
    return this.httpClient.get<Role[]>(AUTH_API);
  }

  deleteRole(roleName: string): Observable<any> {
    return this.httpClient.delete(AUTH_API + roleName).pipe(first());
  }

  addRole(roleName: string): Observable<any> {
    return this.httpClient.post(AUTH_API + roleName, roleName).pipe(first());
  }
}
