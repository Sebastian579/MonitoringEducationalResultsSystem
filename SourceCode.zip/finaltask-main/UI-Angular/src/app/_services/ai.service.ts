import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import Test from '../_models/test.model';

const AUTH_API = environment.baseApiUrl + 'ai/';

@Injectable({
  providedIn: 'root'
})
export class AIService {

  constructor(private http: HttpClient) {}

  generateTest(description: string): Observable<any> {
    return this.http.post<any>(AUTH_API + "generate-test", { description });
  }
}