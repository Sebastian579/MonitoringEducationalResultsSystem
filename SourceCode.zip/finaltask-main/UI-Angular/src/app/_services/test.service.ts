import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { first, Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import FilterTest from '../_models/filter-test.model';
import Question from '../_models/question.model';
import Test from '../_models/test.model';
import Answer from '../_models/answer.model';
import UserAnswer from '../_models/userAnswer.model';

const AUTH_API = environment.baseApiUrl + 'test/';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor(private httpClient: HttpClient) { }

  getTests(): Observable<Test[]> {
    return this.httpClient.get<Test[]>(AUTH_API);
  }

  getTestsByFilter(filter: FilterTest): Observable<Test[]> {
    return this.httpClient.get<Test[]>(AUTH_API + "search?UserName=" + (filter.userName ?? '') + "&MinExecutionTime="
      + (filter.minExecutionTime ? Math.floor(filter.minExecutionTime) : '') + "&MaxExecutionTime="
      + (filter.maxExecutionTime ? Math.floor(filter.maxExecutionTime) : '')
      + "&MinPassScore=" + (filter.minPassScore ? Math.floor(filter.minPassScore) : '')
      + "&MaxPassScore=" + (filter.maxPassScore ? Math.floor(filter.maxPassScore) : ''));
  }

  getTestsByUserId(userId: string): Observable<Test[]> {
    return this.httpClient.get<Test[]>(AUTH_API + 'user/' + userId);
  }

  addTest(test: any): Observable<any> {
    return this.httpClient.post(AUTH_API, test).pipe(first());
  }

  getTest(id: string): Observable<Test> {
    return this.httpClient.get<Test>(AUTH_API + id);
  }

  updateTest(id: string, updatedTest: any): Observable<any> {
    return this.httpClient.put(AUTH_API + id, updatedTest).pipe(first());
  }

  deleteTest(id: string): Observable<any> {
    return this.httpClient.delete(AUTH_API + id).pipe(first());
  }

  addQuestions(testId: string, questions: Array<any>): Observable<any> {
    return this.httpClient.post(AUTH_API + testId + '/questions', questions).pipe(first());
  }

  updateQuestions(testId: string, questions: Array<any>): Observable<any> {
    return this.httpClient.put(AUTH_API + testId + '/questions', questions).pipe(first());
  }

  getQuestionsByTest(testId: string, isForTest = false): Observable<Question[]> {
    return this.httpClient.get<Question[]>(AUTH_API + testId + '/questions?isForTest=' + isForTest);
  }

  checkAnswers(testId: string, answers: Array<UserAnswer>): Observable<any> {
    return this.httpClient.post(AUTH_API + testId + '/check', answers).pipe(first());
  }

  deleteQuestion(testId: string, questionId: string): Observable<any> {
    return this.httpClient.delete(AUTH_API + testId + '/question/' + questionId).pipe(first());
  }

  addAnswers(questionId: string, answers: Array<any>): Observable<any> {
    return this.httpClient.post(AUTH_API + questionId + '/answers', answers).pipe(first());
  }

  updateAnswers(questionId: string, answers: Array<any>): Observable<any> {
    return this.httpClient.put(AUTH_API + questionId + '/answers', answers).pipe(first());
  }

  getAnswersByQuestion(questionId: string): Observable<Answer[]> {
    return this.httpClient.get<Answer[]>(AUTH_API + questionId + '/answers');
  }

  deleteAnswer(questionId: string, answerId: string): Observable<any> {
    return this.httpClient.delete(AUTH_API + questionId + '/answer/' + answerId).pipe(first());
  }
}
