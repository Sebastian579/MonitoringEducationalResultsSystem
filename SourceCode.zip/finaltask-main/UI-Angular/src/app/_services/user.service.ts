import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { first, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import User from '../_models/user.model';

const AUTH_API = environment.baseApiUrl + 'user/';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient) { }

  getUsers(): Observable<User[]> {
    return this.httpClient.get<User[]>(AUTH_API + 'admin');
  }

  deleteUser(userName: string): Observable<any> {
    return this.httpClient.delete(AUTH_API + 'admin/' + userName).pipe(first());
  }

  getuser(userName: string): Observable<User> {
    return this.httpClient.get<User>(AUTH_API + userName);
  }

  updateUser(userName: string, user: any): Observable<any> {
    return this.httpClient.put(AUTH_API + userName, user).pipe(first());
  }

  addRoleToUser(userName: string, roleName: string): Observable<any> {
    return this.httpClient.put(AUTH_API + 'admin/' + userName + '/role?roleName=' + roleName, {}).pipe(first());
  }

  removeRoleFromUser(userName: string, roleName: string): Observable<any> {
    return this.httpClient.delete(AUTH_API + 'admin/' + userName + '/role?roleName=' + roleName).pipe(first());
  }
}
