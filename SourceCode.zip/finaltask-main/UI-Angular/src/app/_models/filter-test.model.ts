export default class FilterTest {
    constructor(public userName?: string,
        public minExecutionTime?: number,
        public maxExecutionTime?: number,
        public minPassScore?: number,
        public maxPassScore?: number) { }
}