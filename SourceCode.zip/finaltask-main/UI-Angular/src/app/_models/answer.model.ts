export default class Answer {
    constructor(public id: string,
        public answerText: string,
        public isCorrect: boolean,
        public questionId: string) { }
}