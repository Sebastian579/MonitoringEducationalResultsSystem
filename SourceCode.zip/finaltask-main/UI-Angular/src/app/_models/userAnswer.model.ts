export default class UserAnswer {
    constructor(public answerText: string,
        public singleChoiceId: string,
        public multipleChoice: boolean[],
        public questionId: string) { }
}