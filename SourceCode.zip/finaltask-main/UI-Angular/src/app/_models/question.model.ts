import Answer from "./answer.model";

export default class Question {
    constructor(public id: string,
        public questionText: string,
        public type: number,
        public answers: Answer[],
        public points: number,
        public testId: string) { }
}