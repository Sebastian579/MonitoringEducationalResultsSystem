export default class Test {
    constructor(public id: string,
        public name: string,
        public executionTime: number,
        public questionCount: number,
        public passScore: number,
        public passPercentage: number,
        public creationDate: Date,
        public userId: string) { }
}