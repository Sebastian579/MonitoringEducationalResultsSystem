export default class User {
    constructor(public id: string,
        public firstName: string,
        public lastName: string,
        public userName: string,
        public email: string,
        public roles: string[]) { }
}