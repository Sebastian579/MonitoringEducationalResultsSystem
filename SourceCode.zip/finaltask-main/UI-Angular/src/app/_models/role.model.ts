export default class Role {
    constructor(public name: string) { }
}