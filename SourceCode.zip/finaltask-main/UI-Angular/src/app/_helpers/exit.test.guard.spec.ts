import { TestBed } from '@angular/core/testing';

import { ExitTestGuard } from './exit.test.guard';

describe('ExitTestGuard', () => {
  let guard: ExitTestGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(ExitTestGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
