import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddTestComponent } from './_components/add-test/add-test.component';
import { BoardAdminComponent } from './_components/board-admin/board-admin.component';
import { BoardModeratorComponent } from './_components/board-moderator/board-moderator.component';
import { BoardUserComponent } from './_components/board-user/board-user.component';
import { EditTestComponent } from './_components/edit-test/edit-test.component';
import { EditUserComponent } from './_components/edit-user/edit-user.component';
import { LoginComponent } from './_components/login/login.component';
import { ProfileComponent } from './_components/profile/profile.component';
import { RegisterComponent } from './_components/register/register.component';
import { StatisticComponent } from './_components/statistic/statistic.component';
import { TestComponent } from './_components/test/test.component';
import { TestsComponent } from './_components/tests/tests.component';
import { AuthGuard } from './_helpers/auth.guard';
import { ExitTestGuard } from './_helpers/exit.test.guard';


const routes: Routes = [
  { path: 'tests', component: TestsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },
  { path: 'user', component: BoardUserComponent, canActivate: [AuthGuard] },
  {
    path: 'mod', component: BoardModeratorComponent, canActivate: [AuthGuard],
    data: { roles: ['TestModerator', 'Admin'] }
  },
  {
    path: 'admin', component: BoardAdminComponent, canActivate: [AuthGuard],
    data: { roles: ['Admin'] }
  },
  { path: 'statistic', component: StatisticComponent, canActivate: [AuthGuard] },
  { path: 'user/edit/:userName', component: EditUserComponent, canActivate: [AuthGuard] },
  {
    path: 'test/add', component: AddTestComponent, canActivate: [AuthGuard],
    data: { roles: ['Teacher', 'TestModerator', 'Admin'] }
  },
  {
    path: 'test/edit/:id', component: EditTestComponent, canActivate: [AuthGuard],
    data: { roles: ['Teacher', 'TestModerator', 'Admin'] }
  },
  { path: 'test/:id', component: TestComponent, canActivate: [AuthGuard], canDeactivate: [ExitTestGuard] },
  { path: '**', redirectTo: 'tests' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
