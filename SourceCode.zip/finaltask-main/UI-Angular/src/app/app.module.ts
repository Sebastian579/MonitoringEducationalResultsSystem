import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './_components/login/login.component';
import { RegisterComponent } from './_components/register/register.component';
import { ProfileComponent } from './_components/profile/profile.component';
import { BoardAdminComponent } from './_components/board-admin/board-admin.component';
import { BoardModeratorComponent } from './_components/board-moderator/board-moderator.component';
import { BoardUserComponent } from './_components/board-user/board-user.component';
import { authInterceptorProviders } from './_helpers/auth.interceptor';
import { TestsComponent } from './_components/tests/tests.component';
import { TestComponent } from './_components/test/test.component';
import { AddTestComponent } from './_components/add-test/add-test.component';
import { EditTestComponent } from './_components/edit-test/edit-test.component';
import { AddQuestionsComponent } from './_components/add-questions/add-questions.component';
import { EditUserComponent } from './_components/edit-user/edit-user.component';
import { StatisticComponent } from './_components/statistic/statistic.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormatTimePipe } from './pipes/format-time.pipe';
import { FloorPipe } from './pipes/floor-number.pipe';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ProfileComponent,
    BoardAdminComponent,
    BoardModeratorComponent,
    BoardUserComponent,
    TestsComponent,
    TestComponent,
    AddTestComponent,
    EditTestComponent,
    AddQuestionsComponent,
    EditUserComponent,
    StatisticComponent,
    FormatTimePipe,
    FloorPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ],
  providers: [authInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
