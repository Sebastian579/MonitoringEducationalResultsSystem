export const environment = {
  production: true,
  baseApiUrl: 'https://webapi20241105162637.azurewebsites.net/api/'
};
