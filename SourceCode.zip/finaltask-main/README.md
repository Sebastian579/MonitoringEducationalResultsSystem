swa build

To deploy on Azure from VS Code:
swa deploy -d <token> --env production