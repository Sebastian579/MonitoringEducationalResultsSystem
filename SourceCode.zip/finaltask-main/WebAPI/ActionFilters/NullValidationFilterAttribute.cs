﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace WebAPI.ActionFilters
{
	/// <summary>
	/// Filter for checking input arguments on null
	/// </summary>
	public class NullValidationFilterAttribute : IActionFilter
	{
		public void OnActionExecuted(ActionExecutedContext context)
		{
			// NullValidationFilter needn't execute after controlles
		}

		public void OnActionExecuting(ActionExecutingContext context)
		{
			foreach (var item in context.ActionArguments)
			{
				if (item.Value == null)
				{
					context.Result = new BadRequestObjectResult("Object is null");
					return;
				}
			}
		}
	}
}
