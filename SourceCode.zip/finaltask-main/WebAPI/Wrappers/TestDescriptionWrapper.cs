﻿namespace WebAPI.Wrappers
{
	public class TestDescriptionWrapper
	{
		public string Description { get; set; }
	}
}
