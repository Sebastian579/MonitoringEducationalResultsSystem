﻿using AutoMapper;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Mappings;
using BusinessLogicLayer.Services;
using DataAccessLayer.Data;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

namespace WebAPI.Extensions
{
	/// <summary>
	/// Extensions for service collection
	/// </summary>
	public static class ServiceExtension
	{
		public static void RegisterDependencies(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddScoped<IUnitOfWork, UnitOfWork>();
			services.AddScoped<IUserService, UserService>();
			services.AddScoped<IRoleService, RoleService>();
			services.AddScoped<ITestService, TestService>();
			services.AddScoped<IQuestionService, QuestionService>();
			services.AddScoped<IAnswerService, AnswerService>();
			services.AddScoped<ITestStatisticsService, TestStatisticsService>();
			services.AddScoped<IUserStatisticsService, UserStatisticsService>();
			services.AddScoped<IStatisticService, StatisticService>();
			services.AddSingleton(new AzureOpenAIService(
				configuration["OpenAI:Endpoint"],
				configuration["OpenAI:ApiKey"]
				));
		}

		public static void ConfigureSqlContext(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddDbContext<IDbContext, TestingSystemContext>(opt =>
			   opt.UseSqlServer(configuration.GetConnectionString("AzureKnowledgeTestingSystem")));
		}

		public static void ConfigureIdentity(this IServiceCollection services)
		{
			services.AddIdentity<User, IdentityRole>(o =>
			{
				o.Password.RequireDigit = false;
				o.Password.RequireLowercase = false;
				o.Password.RequireUppercase = false;
				o.Password.RequireNonAlphanumeric = false;
				o.User.RequireUniqueEmail = true;
			})
			.AddEntityFrameworkStores<TestingSystemContext>();
		}

		public static void ConfigureMapping(this IServiceCollection services)
		{
			var mapperConfig = new MapperConfiguration(map =>
			{
				map.AddProfile<UserMappingProfile>();
				map.AddProfile<TestMappingProfile>();
				map.AddProfile<QuestionMappingProfile>();
				map.AddProfile<AnswerMappingProfile>();
				map.AddProfile<TestStatisticsMappingProfile>();
				map.AddProfile<UserStatisticsMappingProfile>();
			});
			services.AddSingleton(mapperConfig.CreateMapper());
		}

		public static void ConfigureJWT(this IServiceCollection services, IConfiguration configuration)
		{
			var jwtConfig = configuration.GetSection("JWT");
			var secretKey = jwtConfig["Secret"];
			services.AddAuthentication(opt =>
			{
				opt.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
				opt.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
			})
			.AddJwtBearer(options =>
			{
				options.TokenValidationParameters = new TokenValidationParameters
				{
					ValidateIssuer = true,
					ValidateAudience = true,
					ValidateLifetime = true,
					ValidateIssuerSigningKey = true,
					ValidIssuer = jwtConfig["ValidIssuer"],
					ValidAudience = jwtConfig["ValidAudience"],
					IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey))
				};
			});
		}

		public static void ConfigureSwagger(this IServiceCollection services)
		{
			services.AddSwaggerGen(opt =>
			{
				opt.SwaggerDoc("v1", new OpenApiInfo { Title = "Knowledge Testing System", Version = "v1" });
				opt.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
				{
					Name = "Authorization",
					Type = SecuritySchemeType.ApiKey,
					Scheme = "Bearer",
					BearerFormat = "JWT",
					In = ParameterLocation.Header,
					Description = "JWT Authorization header using the Bearer scheme."
				});
				opt.AddSecurityRequirement(new OpenApiSecurityRequirement
			   {
			   {
				  new OpenApiSecurityScheme
				  {
					 Reference = new OpenApiReference
					 {
						Type = ReferenceType.SecurityScheme,
						Id = "Bearer"
					 }
				  },
				  Array.Empty<string>()
			   }
			   });
			});
		}
	}
}
