﻿using Microsoft.AspNetCore.Diagnostics;
using System.Text.Json;

namespace WebAPI.Extensions
{
	/// <summary>
	/// Extension for application builder
	/// </summary>
	public static class ExceptionMiddlewareExtension
	{
		public static void ConfigureExceptionHandler(this IApplicationBuilder app)
		{
			app.UseExceptionHandler(
				appError =>
				{
					appError.Run(async context =>
					{
						context.Response.StatusCode = StatusCodes.Status500InternalServerError;
						context.Response.ContentType = "application/json";

						var contextFeature = context.Features.Get<IExceptionHandlerFeature>();

						await context.Response.WriteAsync(JsonSerializer.Serialize(
							new
							{
								context.Response.StatusCode,
								contextFeature.Error.Message
							}));
					});
				});
		}
	}
}
