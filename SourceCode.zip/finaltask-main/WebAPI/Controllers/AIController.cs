﻿using BusinessLogicLayer.Roles;
using BusinessLogicLayer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Wrappers;

namespace WebAPI.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class AIController : ControllerBase
	{
		private readonly AzureOpenAIService _openAIService;

		public AIController(AzureOpenAIService openAIService)
		{
			_openAIService = openAIService;
		}

		[HttpPost("generate-test")]
		[Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
		public async Task<IActionResult> GenerateQuestion([FromBody] TestDescriptionWrapper description)
		{
			var test = await _openAIService.GenerateTestAsync(description.Description);

			return Ok(test);
		}
	}
}
