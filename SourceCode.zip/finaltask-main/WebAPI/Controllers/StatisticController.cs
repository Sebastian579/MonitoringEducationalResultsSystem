﻿using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Roles;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
	/// <summary>
	/// Controller for getting statistics
	/// </summary>
	[Authorize]
	[ApiController]
	[Route("api/[controller]")]
	public class StatisticController : ControllerBase
	{
		private readonly IStatisticService _statisticService;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="statisticService">Statistic Service</param>
		public StatisticController(IStatisticService statisticService)
		{
			_statisticService = statisticService;
		}

		/// <summary>
		/// Gets the most valuable questions by point value
		/// </summary>
		/// <param name="questionCount">Count of questions for getting</param>
		/// <returns></returns>
		[HttpGet("question")]
		[Authorize(Roles = UserRoles.Admin)]
		public async Task<IActionResult> GetMostValuableQuestions([FromQuery] int questionCount)
		{
			return Ok(await _statisticService.GetMostValuableQuestionsAsync(questionCount));
		}

		/// <summary>
		/// Gets the most active user by count of tests creating
		/// </summary>
		/// <param name="userCount">Count of users for getting</param>
		/// <returns>Users</returns>
		[HttpGet("user/creator")]
		[Authorize(Roles = UserRoles.Admin)]
		public async Task<IActionResult> GetMostActiveTestCreatorsUser([FromQuery] int userCount)
		{
			return Ok(await _statisticService.GetMostActiveTestCreatorsAsync(userCount));
		}

      /// <summary>
      /// Gets the most active user by count of attempt tests passing
      /// </summary>
      /// <param name="userCount">Count of users for getting</param>
      /// <returns>Users</returns>
      [HttpGet("user/active")]
      public async Task<IActionResult> GetMostActiveUser([FromQuery] int userCount)
      {
         return Ok(await _statisticService.GetMostActiveUsersAsync(userCount));
      }

      /// <summary>
      /// Gets the most active user by count of success tests passing
      /// </summary>
      /// <param name="userCount">Count of users for getting</param>
      /// <returns>Users</returns>
      [HttpGet("user/successful")]
      public async Task<IActionResult> GetMostSuccessfulUsers([FromQuery] int userCount)
      {
         return Ok(await _statisticService.GetMostSuccessfulUsersAsync(userCount));
      }

      /// <summary>
      /// Gets the most popular tests by attempt count
      /// </summary>
      /// <param name="testCount">Count of tests for getting</param>
      /// <returns>Tests</returns>
      [HttpGet("test")]
		public async Task<IActionResult> GetMostPopularTests([FromQuery] int testCount)
		{
			return Ok(await _statisticService.GetMostPopularTestsAsync(testCount));
		}
	}
}