﻿using BusinessLogicLayer.Dtos.User;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Roles;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace WebAPI.Controllers
{
	/// <summary>
	/// Controller for interaction with User
	/// </summary>
	[Authorize]
	[ApiController]
	[Route("api/[controller]")]
	public class UserController : ControllerBase
	{
		private readonly IUserService _userService;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="userService">User Service</param>
		public UserController(IUserService userService)
		{
			_userService = userService;
		}

		/// <summary>
		/// Register User with default role
		/// </summary>
		/// <param name="userRegistration">User parameters</param>
		/// <returns>Success or validation errors</returns>
		[HttpPost]
		[AllowAnonymous]
		public async Task<IActionResult> RegisterUser([FromBody] UserRegistrationDto userRegistration)
		{
			var result = await _userService.RegisterWithRoleAsync(userRegistration);

			if (!result.Succeeded)
				return BadRequest(result);

			return StatusCode(201);
		}

		/// <summary>
		/// Register User with role
		/// </summary>
		/// <param name="userRegistration">User parameters</param>
		/// <param name="role">Role</param>
		/// <returns>Success or validation errors</returns>
		[HttpPost("admin")]
		[Authorize(Roles = UserRoles.Admin)]
		public async Task<IActionResult> RegisterWithRole([FromBody] UserRegistrationDto userRegistration,
			[FromQuery][Required] string role)
		{
			var result = await _userService.RegisterWithRoleAsync(userRegistration, role);

			if (!result.Succeeded)
				return BadRequest(result);

			return StatusCode(201);
		}

		/// <summary>
		/// Authenticate User
		/// </summary>
		/// <param name="user">User for authentication</param>
		/// <returns>Success or Not Found</returns>
		[AllowAnonymous]
		[HttpPost("login")]
		public async Task<IActionResult> Authenticate([FromBody] UserLoginDto user)
		{
			var result = await _userService.ValidateUserAsync(user);

			if (!result)
				return NotFound();

			return Ok(new
			{
				Token = await _userService.CreateTokenAsync(),
				User = await _userService.GetUserAsync(user.UserName)
			});
		}

		/// <summary>
		/// Delete User
		/// </summary>
		/// <param name="userName">User name</param>
		/// <returns>Success or Not Found</returns>
		[HttpDelete("admin/{userName}")]
		[Authorize(Roles = UserRoles.Admin)]
		public async Task<IActionResult> DeleteUser(string userName)
		{
			if (!await _userService.DeleteUserAsync(userName))
				return NotFound();

			return NoContent();
		}

		/// <summary>
		/// Gets Users with roles
		/// </summary>
		/// <returns>Users</returns>
		[HttpGet("admin")]
		[Authorize(Roles = UserRoles.Admin)]
		public async Task<IActionResult> GetUsers()
		{
			return Ok(await _userService.GetUsersAsync());
		}

		/// <summary>
		/// Gets User with roles
		/// </summary>
		/// <param name="userName">User name</param>
		/// <returns>User or Not Found</returns>
		[HttpGet("{userName}")]
		public async Task<IActionResult> GetUserByName(string userName)
		{
			var user = await _userService.GetUserAsync(userName);

			if (user == null)
				return NotFound();

			if (User.Identity.Name != userName && !User.IsInRole(UserRoles.Admin))
				return Unauthorized();

			return Ok(user);
		}

		/// <summary>
		/// Update User
		/// </summary>
		/// <param name="userName">User name</param>
		/// <param name="userDto">User parameters</param>
		/// <returns>Result</returns>
		[HttpPut("{userName}")]
		public async Task<IActionResult> UpdateUser(string userName, [FromBody] UserUpdateDto userDto)
		{
			var user = await _userService.GetUserAsync(userName);

			if (user == null)
				return NotFound();

			userDto.UserName = userName;

			if (User.Identity.Name != userName && !User.IsInRole(UserRoles.Admin))
				return Unauthorized();

			var result = await _userService.UpdateUserAsync(userDto);

			if (!result.Succeeded)
				return BadRequest(result);

			return NoContent();
		}

		/// <summary>
		/// Add role to User
		/// </summary>
		/// <param name="userName">User name</param>
		/// <param name="roleName">Role</param>
		/// <returns>Success or Not Found</returns>
		[HttpPut("admin/{userName}/role")]
		[Authorize(Roles = UserRoles.Admin)]
		public async Task<IActionResult> AddRoleToUser(string userName,
			[FromQuery][Required] string roleName)
		{
			if (!await _userService.AddRoleToUserAsync(userName, roleName))
				return NotFound("User or role not found");

			return NoContent();
		}

		/// <summary>
		/// Remove role from User
		/// </summary>
		/// <param name="userName">User name</param>
		/// <param name="roleName">Role</param>
		/// <returns>Success or Not Found</returns>
		[HttpDelete("admin/{userName}/role")]
		[Authorize(Roles = UserRoles.Admin)]
		public async Task<IActionResult> RemoveRoleFromUser(string userName,
			[FromQuery][Required] string roleName)
		{
			if (!await _userService.RemoveRoleFromUserAsync(userName, roleName))
				return NotFound("User or role not found");

			return NoContent();
		}
	}
}
