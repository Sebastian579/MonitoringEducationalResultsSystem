﻿using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Roles;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
   /// <summary>
   /// Controller for interaction with RoleIdentity
   /// </summary>
   [ApiController]
   [Authorize(Roles = UserRoles.Admin)]
   [Route("api/[controller]")]
   public class RoleController : ControllerBase
   {
      private readonly IRoleService _roleService;

      /// <summary>
      /// Constructor
      /// </summary>
      /// <param name="roleService">Role Service</param>
      public RoleController(IRoleService roleService)
      {
         _roleService = roleService;
      }

      /// <summary>
      /// Adds new role
      /// </summary>
      /// <param name="roleName">Role</param>
      /// <returns>Success or validation errors</returns>
      [HttpPost("{roleName}")]
      public async Task<IActionResult> AddRole(string roleName)
      {
         var roleResult = await _roleService.AddRoleAsync(roleName);

         if (!roleResult.Succeeded)
            return BadRequest(roleResult);

         return StatusCode(201);
      }

      /// <summary>
      /// Gets Roles
      /// </summary>
      /// <returns>Roles</returns>
      [HttpGet]
      public async Task<IActionResult> GetRoles()
      {
         return Ok(await _roleService.GetRolesAsync());
      }

      /// <summary>
      /// Delete role
      /// </summary>
      /// <param name="roleName">Role</param>
      /// <returns>Success or Not Found</returns>
      [HttpDelete("{roleName}")]
      public async Task<IActionResult> DeleteRole(string roleName)
      {
         if (!await _roleService.DeleteRoleAsync(roleName))
            return NotFound();

         return NoContent();
      }
   }
}
