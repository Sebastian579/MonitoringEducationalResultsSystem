﻿using BusinessLogicLayer.Dtos.Answers;
using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Dtos.TestStatistics;
using BusinessLogicLayer.Dtos.UserStatistics;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Models;
using BusinessLogicLayer.Roles;
using BusinessLogicLayer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace WebAPI.Controllers
{
   /// <summary>
   /// Controller for interaction with Test and test Questions
   /// </summary>
   [Authorize]
   [ApiController]
   [Route("api/[controller]")]
   public class TestController : ControllerBase
   {
      private readonly ITestService _testService;
      private readonly IQuestionService _questionService;
      private readonly IAnswerService _answerService;
      private readonly ITestStatisticsService _testStatisticsService;
      private readonly IUserStatisticsService _userStatisticsService;

      /// <summary>
      /// Constructor
      /// </summary>
      /// <param name="testService">Test Service</param>
      /// <param name="questionService">Question Service</param>
      /// <param name="testStatisticsService">TestStatistics Service</param>
      public TestController(ITestService testService, IQuestionService questionService,
         ITestStatisticsService testStatisticsService, IUserStatisticsService userStatisticsService,
         IAnswerService answerService)
      {
         _testService = testService;
         _questionService = questionService;
         _testStatisticsService = testStatisticsService;
         _userStatisticsService = userStatisticsService;
         _answerService = answerService;
      }

      /// <summary>
      /// Gets all tests include additional information from other entities
      /// </summary>
      /// <returns>Tests</returns>
      [HttpGet]
      [AllowAnonymous]
      public async Task<IActionResult> GetAllTests()
      {
         return Ok(await _testService.GetAllTestsWithIncludeAsync());
      }

      /// <summary>
      /// Gets all tests include additional information from other entities by filtering
      /// </summary>
      /// <param name="filterModel">Filter parameters</param>
      /// <returns>Tests</returns>
      [HttpGet("search")]
      public async Task<IActionResult> FilterTests([FromQuery] FilterSearchTestModel filterModel)
      {
         return Ok(await _testService.GetTestsByFilterAsync(filterModel));
      }

      /// <summary>
      /// Gets all tests include additional information from other entities by name
      /// </summary>
      /// <param name="name">Test name</param>
      /// <returns>Tests</returns>
      [HttpGet("search/{name}")]
      public async Task<IActionResult> SearchTestsByName(string name)
      {
         return Ok(await _testService.GetTestsByNameSearchAsync(name));
      }

      /// <summary>
      /// Gets all tests include additional information from other entities by user id
      /// </summary>
      /// <param name="userId">User id</param>
      /// <returns>Tests</returns>
      [HttpGet("user/{userId}")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> GetTestsByUserId(string userId)
      {
         return Ok(await _testService.GetTestsByUserIdAsync(userId));
      }

      /// <summary>
      /// Gets test include additional information from other entities
      /// </summary>
      /// <param name="id">Test id</param>
      /// <returns>Test or Not Found</returns>
      [HttpGet("{id}")]
      public async Task<IActionResult> GetTest(string id)
      {
         var test = await _testService.GetTestByIdWithIncludeAsync(id);

         if (test == null)
            return NotFound();

         return Ok(test);
      }

      /// <summary>
      /// Create new Test
      /// </summary>
      /// <param name="testDto">Test parameters for creating</param>
      /// <returns>URL for getting</returns>
      [HttpPost]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> CreateTest([FromBody] TestCreateUpdateDto testDto)
      {
         testDto.Id = Guid.NewGuid().ToString();
         testDto.UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);

         await _testService.CreateAsync(testDto);

         TestStatisticsCreateUpdateDto testStatisticCreateDto = new()
         {
            Id = Guid.NewGuid().ToString(),
            TestId = testDto.Id
         };
         await _testStatisticsService.CreateAsync(testStatisticCreateDto);

         return CreatedAtAction(nameof(GetTest), new { id = testDto.Id }, testDto);
      }

      /// <summary>
      /// Update Test
      /// </summary>
      /// <param name="id">Test id</param>
      /// <param name="testDto">Test parameters for updating</param>
      /// <returns>Success or Not Found</returns>
      [HttpPut("{id}")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> UpdateTest(string id, [FromBody] TestCreateUpdateDto testDto)
      {
         var test = await _testService.GetByIdAsync(id);

         if (test == null)
            return NotFound();

         testDto.Id = id;
         testDto.UserId = test.UserId;
         testDto.CreationDate = test.CreationDate;

         await _testService.UpdateAsync(testDto);

         return NoContent();
      }

      /// <summary>
      /// Delete Test
      /// </summary>
      /// <param name="id">Test id</param>
      /// <returns>Success or Not Found</returns>
      [HttpDelete("{id}")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> DeleteTest(string id)
      {
         var test = await _testService.GetByIdAsync(id);

         if (test == null)
            return NotFound();

         await _testService.DeleteAsync(test);

         return NoContent();
      }

      /// <summary>
      /// Gets all questions by test id
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <returns>Questions</returns>
      [HttpGet("{testId}/questions")]
      public async Task<IActionResult> GetAllTestQuestions(string testId, [FromQuery] bool isForTest)
      {
         if (isForTest)
         {
            return Ok(await _questionService.GetQuestionsByTestIdForTestAsync(testId));
         }

         return Ok(await _questionService.GetQuestionsByTestIdAsync(testId));
      }

      /// <summary>
      /// Gets test question by id 
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="questionId">Question id</param>
      /// <returns>Question or Not Found</returns>
      [HttpGet("{testId}/question/{questionId}")]
      public async Task<IActionResult> GetTestQuestionById(string testId, string questionId)
      {
         var question = await _questionService.GetQuestionByIdAsync(testId, questionId);

         if (question == null)
            return NotFound();

         return Ok(question);
      }

      /// <summary>
      /// Check user answers and update TestStatistics
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="answers">User answers</param>
      /// <returns>Points or Not Found</returns>
      [HttpPost("{testId}/check")]
      public async Task<IActionResult> CheckUserAnswers(string testId,
         [FromBody] ICollection<UserAnswerModel> answers)
      {
         var test = await _testService.GetByIdAsync(testId);

         if (test == null)
            return NotFound();

         var result = await _questionService.CheckUserAnswersAsync(testId, answers);
         bool isPass = result >= test.PassScore;

         var testStatistic = await _testStatisticsService.GetByTestIdAsync(testId);
         if (testStatistic != null)
         {
            await _testStatisticsService.IncrementCountAsync(testStatistic, isPass);
         }

         var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
         var userStatistic = await _userStatisticsService.GetByUserIdAsync(userId);
         if (userStatistic == null)
         {
            UserStatisticsCreateUpdateDto userStatisticCreateDto = new()
            {
               Id = Guid.NewGuid().ToString(),
               UserId = userId
            };
            await _userStatisticsService.CreateAsync(userStatisticCreateDto);
         }
         await _userStatisticsService.IncrementCountAsync(userStatistic, isPass);

         return Ok(result);
      }

      /// <summary>
      /// Adds new question to test
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="questionDto">Question parameters for adding</param>
      /// <returns>URL for getting or Not Found</returns>
      [HttpPost("{testId}/question")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> AddQuestionToTest(string testId,
         [FromBody] QuestionCreateUpdateDto questionDto)
      {
         var test = await _testService.GetByIdAsync(testId);

         if (test == null)
            return NotFound();

         questionDto.Id = Guid.NewGuid().ToString();
         questionDto.TestId = testId;

         await _questionService.CreateAsync(questionDto);

         return CreatedAtAction(nameof(GetTestQuestionById), new
         {
            testId = questionDto.TestId,
            questionId = questionDto.Id
         }, questionDto);
      }

      /// <summary>
      /// Adds new questions to test
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="questionDtos">Questions parameters for adding</param>
      /// <returns>URL for getting or Not Found</returns>
      [HttpPost("{testId}/questions")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> AddQuestionsToTest(string testId,
         [FromBody] IEnumerable<QuestionCreateUpdateDto> questionDtos)
      {
         if (!questionDtos.Any())
            return BadRequest("Object is empty");

         var test = await _testService.GetByIdAsync(testId);

         if (test == null)
            return NotFound();

         foreach (var questionDto in questionDtos)
         {
            questionDto.Id = Guid.NewGuid().ToString();
            questionDto.TestId = testId;
            QuestionService.SetQuestionType(questionDto);

            foreach (var answer in questionDto.Answers)
            {
               answer.Id = Guid.NewGuid().ToString();
               answer.QuestionId = questionDto.Id;
            }
         }

         await _questionService.CreateRangeAsync(questionDtos);

         return CreatedAtAction(nameof(GetAllTestQuestions), new
         {
            testId = test.Id,
         }, questionDtos);
      }

      /// <summary>
      /// Update test question
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="questionId">Question id</param>
      /// <param name="questionDto">Question parameters for updating</param>
      /// <returns>Success or Not Found</returns>
      [HttpPut("{testId}/question/{questionId}")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> UpdateTestQuestion(string testId, string questionId,
         [FromBody] QuestionCreateUpdateDto questionDto)
      {
         var question = await _questionService.GetQuestionByIdAsync(testId, questionId);

         if (question == null)
            return NotFound();

         questionDto.Id = questionId;
         questionDto.TestId = testId;

         await _questionService.UpdateAsync(questionDto);

         return NoContent();
      }

      /// <summary>
      /// Update test questions
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="questionDtos">Questions parameters for updating</param>
      /// <returns>Success or Not Found</returns>
      [HttpPut("{testId}/questions")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> UpdateTestQuestions(string testId,
         [FromBody] IEnumerable<QuestionCreateUpdateDto> questionDtos)
      {
         if (!questionDtos.Any())
            return BadRequest("Object is empty");

         var test = await _testService.GetByIdAsync(testId);

         if (test == null || !await _questionService.IsQuestionsExistAsync(testId, questionDtos))
            return NotFound();

         foreach (var questionDto in questionDtos)
         {
            questionDto.TestId = testId;
            QuestionService.SetQuestionType(questionDto);

            foreach (var answer in questionDto.Answers)
            {
               answer.QuestionId = questionDto.Id;
            }

            var newAnswerDtos = questionDto.Answers.Where(a => a.Id == null).ToList();
            questionDto.Answers = questionDto.Answers.Where(a => a.Id != null).ToList();
            if (newAnswerDtos.Any())
            {
               newAnswerDtos.ForEach(na => na.Id = Guid.NewGuid().ToString());
               await _answerService.CreateRangeAsync(newAnswerDtos);
            }
         }

         await _questionService.UpdateRangeAsync(questionDtos);

         return NoContent();
      }

      /// <summary>
      /// Delete test question
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="questionId">Question id</param>
      /// <returns>Success or Not Found</returns>
      [HttpDelete("{testId}/question/{questionId}")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> RemoveQuestionFromTest(string testId, string questionId)
      {
         var question = await _questionService.GetQuestionByIdAsync(testId, questionId);

         if (question == null)
            return NotFound();

         await _questionService.DeleteAsync(question);

         return NoContent();
      }

      /// <summary>
      /// Gets all answers by question id
      /// </summary>
      /// <param name="questionId">Question id</param>
      /// <returns>Answers</returns>
      [HttpGet("{questionId}/answers")]
      public async Task<IActionResult> GetAllQuestionAnswers(string questionId)
      {
         return Ok(await _answerService.GetAnswersByQuestionIdAsync(questionId));
      }

      /// <summary>
      /// Adds new answers to question
      /// </summary>
      /// <param name="questionId">Question id</param>
      /// <param name="answerDtos">Answers parameters for adding</param>
      /// <returns>URL for getting or Not Found</returns>
      [HttpPost("{questionId}/answers")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> AddAnswersToQuestion(string questionId,
         [FromBody] IEnumerable<AnswerCreateUpdateDto> answerDtos)
      {
         if (!answerDtos.Any())
            return BadRequest("Object is empty");

         var question = await _questionService.GetByIdAsync(questionId);

         if (question == null)
            return NotFound();

         foreach (var answerDto in answerDtos)
         {
            answerDto.Id = Guid.NewGuid().ToString();
            answerDto.QuestionId = questionId;
         }

         await _answerService.CreateRangeAsync(answerDtos);
         await _questionService.SetQuestionTypeAsync(questionId);

         return CreatedAtAction(nameof(GetAllQuestionAnswers), new
         {
            questionId = question.Id,
         }, answerDtos);
      }

      /// <summary>
      /// Update question answers
      /// </summary>
      /// <param name="questionId">Question id</param>
      /// <param name="answersDtos">Answers parameters for updating</param>
      /// <returns>Success or Not Found</returns>
      [HttpPut("{questionId}/answers")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> UpdateQuestionAnswers(string questionId,
         [FromBody] IEnumerable<AnswerCreateUpdateDto> answersDtos)
      {
         if (!answersDtos.Any())
            return BadRequest("Object is empty");

         var question = await _questionService.GetByIdAsync(questionId);

         if (question == null || !await _answerService.IsAnswersExistAsync(questionId, answersDtos))
            return NotFound();

         foreach (var answerDto in answersDtos)
         {
            answerDto.QuestionId = questionId;
         }

         await _answerService.UpdateRangeAsync(answersDtos);
         await _questionService.SetQuestionTypeAsync(questionId);

         return NoContent();
      }

      /// <summary>
      /// Delete question answer
      /// </summary>
      /// <param name="questionId">Question id</param>
      /// <param name="answerId">Answer id</param>
      /// <returns>Success or Not Found</returns>
      [HttpDelete("{questionId}/answer/{answerId}")]
      [Authorize(Roles = $"{UserRoles.Admin},{UserRoles.TestModerator},{UserRoles.Teacher}")]
      public async Task<IActionResult> RemoveAnswerFromQuestion(string questionId, string answerId)
      {
         var answer = await _answerService.GetAnswerByIdAsync(questionId, answerId);

         if (answer == null)
            return NotFound();

         await _answerService.DeleteAsync(answer);
         await _questionService.SetQuestionTypeAsync(questionId);

         return NoContent();
      }
   }
}