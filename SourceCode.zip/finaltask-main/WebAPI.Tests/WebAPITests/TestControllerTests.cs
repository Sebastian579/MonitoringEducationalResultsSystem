﻿using BusinessLogicLayer.Dtos.Answers;
using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Dtos.TestStatistics;
using BusinessLogicLayer.Dtos.UserStatistics;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Models;
using DataAccessLayer.Entities;
using DataAccessLayer.Enums;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Security.Claims;
using WebAPI.Controllers;

namespace WebAPI.Tests.WebAPITests
{
   [TestFixture]
   public class TestControllerTests
   {
      private TestController _testController;
      private Mock<ITestService> _testServiceMock;
      private Mock<IQuestionService> _questionServiceMock;
      private Mock<IAnswerService> _answerServiceMock;
      private Mock<ITestStatisticsService> _testStatisticsServiceMock;
      private Mock<IUserStatisticsService> _userStatisticsServiceMock;
      private Mock<HttpContext> _contextMock;

      [SetUp]
      public void SetUp()
      {
         _testServiceMock = new();
         _questionServiceMock = new();
         _answerServiceMock = new();
         _testStatisticsServiceMock = new();
         _userStatisticsServiceMock = new();
         _contextMock = new();

         _testController = new TestController(_testServiceMock.Object, _questionServiceMock.Object,
            _testStatisticsServiceMock.Object, _userStatisticsServiceMock.Object, _answerServiceMock.Object);

         _testController.ControllerContext = new ControllerContext()
         {
            HttpContext = _contextMock.Object
         };
      }

      [Test]
      public async Task TestController_GetAllTests_ReturnsAll()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetAllTestsWithIncludeAsync())
            .ReturnsAsync(TestData.GetTestsDto);

         //Act
         var result = await _testController.GetAllTests();
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(TestData.GetTestsDto);
      }

      [Test]
      public async Task TestController_FilterTests_ReturnsAll()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetTestsByFilterAsync(It.IsAny<FilterSearchTestModel>()))
            .ReturnsAsync(TestData.GetTestsDto);

         //Act
         var result = await _testController.FilterTests(new FilterSearchTestModel());
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(TestData.GetTestsDto);
      }

      [Test]
      public async Task TestController_SearchTestsByName_ReturnsAll()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetTestsByNameSearchAsync(It.IsAny<string>()))
            .ReturnsAsync(TestData.GetTestsDto);

         //Act
         var result = await _testController.SearchTestsByName("name");
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(TestData.GetTestsDto);
      }

      [Test]
      [TestCase("1", new[] { "1", "4" })]
      [TestCase("2", new[] { "2", "5" })]
      [TestCase("3", new[] { "3" })]
      public async Task TestController_GetTestsByUserId_ReturnsById(string userId,
         IEnumerable<string> expectedId)
      {
         //Arrange
         var expected = TestData.GetTestsDto.Concat(AdditionalTestDtos).Where(x => expectedId.Contains(x.Id));

         _testServiceMock.Setup(x => x.GetTestsByUserIdAsync(It.IsAny<string>()))
            .ReturnsAsync(expected);

         //Act
         var result = await _testController.GetTestsByUserId(userId);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase("1")]
      [TestCase("2")]
      [TestCase("3")]
      public async Task TestController_GetTest_ReturnsTest(string id)
      {
         //Arrange
         var expected = TestData.GetTestsDto.First(x => x.Id == id);

         _testServiceMock.Setup(x => x.GetTestByIdWithIncludeAsync(It.IsAny<string>()))
            .ReturnsAsync(expected);

         //Act
         var result = await _testController.GetTest(id);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(expected);
      }

      [Test]
      public async Task TestController_GetTest_NotFound()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetTestByIdWithIncludeAsync(It.IsAny<string>()));

         //Act
         var result = await _testController.GetTest("1");
         var notFoundResult = result as NotFoundResult;

         //Assert
         notFoundResult.Should().NotBeNull();
      }

      [Test]
      [TestCase("4", "1")]
      [TestCase("5", "2")]
      [TestCase("6", "3")]
      public async Task TestController_CreateTest_Success(string id, string userId)
      {
         //Arrange
         _testServiceMock.Setup(x => x.CreateAsync(It.IsAny<TestCreateUpdateDto>()));

         var model = TestData.TestsCreateUpdateDto.First(x => x.Id == id);

         _contextMock.Setup(x => x.User.FindFirst(It.IsAny<string>()))
            .Returns(new Claim(ClaimTypes.NameIdentifier, userId));

         //Act
         var result = await _testController.CreateTest(model);
         var createdAtActionResult = result as CreatedAtActionResult;

         //Assert
         _testServiceMock.Verify(x => x.CreateAsync(It.Is<TestCreateUpdateDto>(y => y.Id == model.Id
         && y.Name == model.Name && y.ExecutionTime == model.ExecutionTime && y.UserId == model.UserId)),
         Times.Once);

         _testStatisticsServiceMock.Verify(x => x.CreateAsync(It.Is<TestStatisticsCreateUpdateDto>(y =>
         y.TestId == model.Id && y.Id != null)), Times.Once);

         createdAtActionResult.Should().NotBeNull();
         createdAtActionResult.Value.Should().BeEquivalentTo(model);
      }

      [Test]
      [TestCase("4", "1")]
      [TestCase("5", "2")]
      [TestCase("6", "3")]
      public async Task TestController_UpdateTest_Success(string id, string getId)
      {
         //Arrange
         var getTest = TestData.GetTestsDto.First(x => x.Id == getId);

         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getTest);

         var model = TestData.TestsCreateUpdateDto.First(x => x.Id != id);

         //Act
         var result = await _testController.UpdateTest(getId, model);
         var noContentResult = result as NoContentResult;

         //Assert
         _testServiceMock.Verify(x => x.UpdateAsync(It.Is<TestCreateUpdateDto>(y => y.Id == getId
         && y.UserId == getTest.UserId)), Times.Once);
         noContentResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_UpdateTest_NotFound()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()));

         var model = TestData.TestsCreateUpdateDto.First();

         //Act
         var result = await _testController.UpdateTest("1", model);
         var notFoundResult = result as NotFoundResult;

         //Assert
         _testServiceMock.Verify(x => x.UpdateAsync(It.IsAny<TestCreateUpdateDto>()), Times.Never);
         notFoundResult.Should().NotBeNull();
      }

      [Test]
      [TestCase("1")]
      [TestCase("2")]
      [TestCase("3")]
      public async Task TestController_DeleteTest_Success(string testId)
      {
         //Arrange
         var getTest = TestData.GetTestsDto.First(x => x.Id == testId);

         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getTest);

         //Act
         var result = await _testController.DeleteTest(testId);
         var noContentResult = result as NoContentResult;

         //Assert
         _testServiceMock.Verify(x => x.DeleteAsync(It.Is<TestGetDto>(y => y.Id == testId
         && y.UserId == getTest.UserId && y.ExecutionTime == getTest.ExecutionTime
         && y.PassScore == getTest.PassScore)), Times.Once);
         noContentResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_DeleteTest_NotFound()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()));

         //Act
         var result = await _testController.DeleteTest("1");
         var notFoundResult = result as NotFoundResult;

         //Assert
         _testServiceMock.Verify(x => x.DeleteAsync(It.IsAny<TestGetDto>()), Times.Never);
         notFoundResult.Should().NotBeNull();
      }

      [Test]
      [TestCase("1", new[] { "1", "4" })]
      [TestCase("2", new[] { "2", "5" })]
      [TestCase("3", new[] { "3" })]
      public async Task TestController_GetAllTestQuestionsIsNotForTest_ReturnsAll(string testId,
         IEnumerable<string> expectedId)
      {
         //Arrange
         var expected = TestData.GetQuestionsDto.Concat(AdditionalQuestionDtos)
            .Where(x => expectedId.Contains(x.Id));

         _questionServiceMock.Setup(x => x.GetQuestionsByTestIdAsync(It.IsAny<string>()))
            .ReturnsAsync(expected);

         //Act // TODO
         var result = await _testController.GetAllTestQuestions(testId, false);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(expected);
      }

      [Test]
      public async Task TestController_GetAllTestQuestionsIsForTest_ReturnsAll()
      {
         //Arrange
         var testId = "1";
         var expected = new List<QuestionForTestModel>
         {
             new QuestionForTestModel
             {
                 Id = "1",
                 QuestionText = "Question 1",
                 Type = QuestionType.SingleChoice,
                 Points = 10,
                 TestId = testId,
                 Answers = new List<AnswerForTestModel>
                 {
                     new AnswerForTestModel
                     {
                         Id = "1",
                         QuestionId = "1",
                         AnswerText = "Answer 1"
                     },
                     new AnswerForTestModel
                     {
                         Id = "2",
                         QuestionId = "1",
                         AnswerText = "Answer 2"
                     }
                 }
             },
         };

         _questionServiceMock.Setup(x => x.GetQuestionsByTestIdForTestAsync(It.IsAny<string>()))
            .ReturnsAsync(expected);

         //Act
         var result = await _testController.GetAllTestQuestions(testId, true);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase("1", "4")]
      [TestCase("2", "5")]
      [TestCase("3", "3")]
      public async Task TestController_GetTestQuestionById_ReturnsById(string testId, string questionId)
      {
         //Arrange
         var expected = TestData.GetQuestionsDto.Concat(AdditionalQuestionDtos)
            .First(x => x.Id == questionId);

         _questionServiceMock.Setup(x => x.GetQuestionByIdAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(expected);

         //Act
         var result = await _testController.GetTestQuestionById(testId, questionId);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(expected);
      }

      [Test]
      public async Task TestController_GetTestQuestionById_NotFound()
      {
         //Arrange
         _questionServiceMock.Setup(x => x.GetQuestionByIdAsync(It.IsAny<string>(), It.IsAny<string>()));

         //Act
         var result = await _testController.GetTestQuestionById("1", "3");
         var notFoundResult = result as NotFoundResult;

         //Assert
         notFoundResult.Should().NotBeNull();
      }

      [Test]
      [TestCase("1", "1", 30, true)]
      [TestCase("2", "2", 5, false)]
      [TestCase("3", "3", 100, true)]
      public async Task TestController_CheckUserAnswers_Success(string id, string userId, int points,
         bool expectedIsPass)
      {
         //Arrange
         var getTest = TestData.GetTestsDto.First(x => x.Id == id);
         var getTestStatistic = TestData.GetTestStatisticsDto.First(x => x.Id == id);
         var getUserStatistic = TestData.GetUserStatisticsDto.First(x => x.Id == id);

         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getTest);

         _questionServiceMock.Setup(x => x.CheckUserAnswersAsync(It.IsAny<string>(),
            It.IsAny<ICollection<UserAnswerModel>>())).ReturnsAsync(points);

         _testStatisticsServiceMock.Setup(x => x.GetByTestIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getTestStatistic);

         _userStatisticsServiceMock.Setup(x => x.GetByUserIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getUserStatistic);

         _contextMock.Setup(x => x.User.FindFirst(It.IsAny<string>()))
            .Returns(new Claim(ClaimTypes.NameIdentifier, userId));

         var userAnswers = Array.Empty<UserAnswerModel>();

         //Act
         var result = await _testController.CheckUserAnswers(id, userAnswers);
         var okResult = result as OkObjectResult;

         //Assert
         _questionServiceMock.Verify(x => x.CheckUserAnswersAsync(It.Is<string>(y => y == id),
            It.Is<ICollection<UserAnswerModel>>(y => y != null)), Times.Once);

         _testStatisticsServiceMock.Verify(x => x.IncrementCountAsync(It.Is<TestStatisticsGetDto>(y =>
         y.Id == getTestStatistic.Id), It.Is<bool>(y => y == expectedIsPass)), Times.Once);

         _userStatisticsServiceMock.Verify(x => x.IncrementCountAsync(It.Is<UserStatisticsGetDto>(y =>
         y.Id == getUserStatistic.Id), It.Is<bool>(y => y == expectedIsPass)), Times.Once);

         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(points);
      }

      [Test]
      public async Task TestController_CheckUserAnswers_NotFound()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()));

         var userAnswers = Array.Empty<UserAnswerModel>();

         //Act
         var result = await _testController.CheckUserAnswers("1", userAnswers);
         var notFoundResult = result as NotFoundResult;

         //Assert
         _questionServiceMock.Verify(x => x.CheckUserAnswersAsync(It.IsAny<string>(),
            It.IsAny<ICollection<UserAnswerModel>>()), Times.Never);

         _testStatisticsServiceMock.Verify(x => x.GetByTestIdAsync(It.IsAny<string>()), Times.Never);
         _testStatisticsServiceMock.Verify(x => x.IncrementCountAsync(It.IsAny<TestStatisticsGetDto>(),
            It.IsAny<bool>()), Times.Never);
         notFoundResult.Should().NotBeNull();
      }

      [Test]
      [TestCase("4", "1")]
      [TestCase("5", "2")]
      [TestCase("6", "3")]
      public async Task TestController_AddQuestionToTest_Success(string id, string testId)
      {
         //Arrange
         var getTest = TestData.GetTestsDto.First(x => x.Id == testId);

         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getTest);

         var model = TestData.QuestionsCreateUpdateDto.First(x => x.Id == id);

         //Act
         var result = await _testController.AddQuestionToTest(testId, model);
         var createdAtActionResult = result as CreatedAtActionResult;

         //Assert
         _questionServiceMock.Verify(x => x.CreateAsync(It.Is<QuestionCreateUpdateDto>(y => y.Id != null
         && y.TestId == testId)), Times.Once);

         createdAtActionResult.Should().NotBeNull();
         createdAtActionResult.Value.Should().BeEquivalentTo(model);
      }

      [Test]
      public async Task TestController_AddQuestionToTest_NotFound()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()));

         var model = TestData.QuestionsCreateUpdateDto.First();

         //Act
         var result = await _testController.AddQuestionToTest("1", model);
         var notFoundResult = result as NotFoundResult;

         //Assert
         _questionServiceMock.Verify(x => x.CreateAsync(It.IsAny<QuestionCreateUpdateDto>()), Times.Never);

         notFoundResult.Should().NotBeNull();
      }

      [Test]
      [TestCase("1")]
      [TestCase("2")]
      [TestCase("3")]
      public async Task TestController_AddQuestionsToTest_Success(string testId)
      {
         //Arrange
         var getTest = TestData.GetTestsDto.First(x => x.Id == testId);

         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getTest);

         var models = TestData.QuestionsCreateUpdateDto;
         models.ForEach(m => m.Answers = Array.Empty<AnswerCreateUpdateDto>());

         //Act
         var result = await _testController.AddQuestionsToTest(testId, models);
         var createdAtActionResult = result as CreatedAtActionResult;

         //Assert
         _questionServiceMock.Verify(x => x.CreateRangeAsync(It.Is<IEnumerable<QuestionCreateUpdateDto>>(
            y => y.All(q => q.Id != null && q.TestId == testId))), Times.Once);

         createdAtActionResult.Should().NotBeNull();
         createdAtActionResult.Value.Should().BeEquivalentTo(models);
      }

      [Test]
      public async Task TestController_AddQuestionsToTest_NotFound()
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()));

         var models = TestData.QuestionsCreateUpdateDto;

         //Act
         var result = await _testController.AddQuestionsToTest("1", models);
         var notFoundResult = result as NotFoundResult;

         //Assert
         _questionServiceMock.Verify(x => x.CreateRangeAsync(It.IsAny<IEnumerable<QuestionCreateUpdateDto>>()),
            Times.Never);

         notFoundResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_AddQuestionsToTest_BadRequest()
      {
         //Arrange
         var models = Array.Empty<QuestionCreateUpdateDto>();

         //Act
         var result = await _testController.AddQuestionsToTest("1", models);
         var badRequestResult = result as BadRequestObjectResult;

         //Assert
         _questionServiceMock.Verify(x => x.CreateRangeAsync(It.IsAny<IEnumerable<QuestionCreateUpdateDto>>()),
            Times.Never);

         _testServiceMock.Verify(x => x.GetByIdAsync(It.IsAny<string>()), Times.Never);

         badRequestResult.Should().NotBeNull();
         badRequestResult.Value.Should().Be("Object is empty");
      }

      [Test]
      [TestCase("1", "4")]
      [TestCase("2", "5")]
      [TestCase("3", "3")]
      public async Task TestController_UpdateTestQuestion_Success(string testId, string questionId)
      {
         //Arrange
         var getQuestion = TestData.GetQuestionsDto.Concat(AdditionalQuestionDtos)
            .First(x => x.Id == questionId);

         _questionServiceMock.Setup(x => x.GetQuestionByIdAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(getQuestion);

         var model = TestData.QuestionsCreateUpdateDto.First(x => x.Id != questionId);

         //Act
         var result = await _testController.UpdateTestQuestion(testId, questionId, model);
         var noContentResult = result as NoContentResult;

         //Assert
         _questionServiceMock.Verify(x => x.UpdateAsync(It.Is<QuestionCreateUpdateDto>(y =>
         y.Id == questionId && y.TestId == testId)), Times.Once);

         noContentResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_UpdateTestQuestion_NotFound()
      {
         //Arrange
         _questionServiceMock.Setup(x => x.GetQuestionByIdAsync(It.IsAny<string>(), It.IsAny<string>()));

         var model = TestData.QuestionsCreateUpdateDto.First();

         //Act
         var result = await _testController.UpdateTestQuestion("1", "3", model);
         var notFoundResult = result as NotFoundResult;

         //Assert
         _questionServiceMock.Verify(x => x.UpdateAsync(It.IsAny<QuestionCreateUpdateDto>()), Times.Never);
         notFoundResult.Should().NotBeNull();
      }

      [Test]
      [TestCase("1")]
      [TestCase("2")]
      [TestCase("3")]
      public async Task TestController_UpdateTestQuestions_Success(string testId)
      {
         //Arrange
         var getTest = TestData.GetTestsDto.First(x => x.Id == testId);

         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getTest);

         _questionServiceMock.Setup(x => x.IsQuestionsExistAsync(It.IsAny<string>(),
            It.IsAny<IEnumerable<QuestionCreateUpdateDto>>())).ReturnsAsync(true);

         var models = TestData.QuestionsCreateUpdateDto;
         models.ForEach(m => m.Answers = Array.Empty<AnswerCreateUpdateDto>());

         //Act
         var result = await _testController.UpdateTestQuestions(testId, models);
         var noContentResult = result as NoContentResult;

         //Assert
         _questionServiceMock.Verify(x => x.UpdateRangeAsync(It.Is<IEnumerable<QuestionCreateUpdateDto>>(
            y => y.All(q => q.TestId == testId))), Times.Once);

         noContentResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_UpdateTestQuestionsAndNewAnswer_Success()
      {
         // Arrange
         var testId = "1";
         var questionDtos = new List<QuestionCreateUpdateDto>
         {
             new QuestionCreateUpdateDto
             {
                 Id = "1",
                 TestId = testId,
                 Answers = new List<AnswerCreateUpdateDto>
                 {
                     new AnswerCreateUpdateDto { Id = "1", AnswerText = "Answer 1" },
                     new AnswerCreateUpdateDto { Id = null, AnswerText = "Answer 2" }
                 }
             },
         };

         var test = new TestGetDto { Id = testId };
         _testServiceMock.Setup(x => x.GetByIdAsync(testId)).ReturnsAsync(test);
         _questionServiceMock.Setup(x => x.IsQuestionsExistAsync(testId, questionDtos)).ReturnsAsync(true);

         // Act
         var result = await _testController.UpdateTestQuestions(testId, questionDtos);
         var noContentResult = result as NoContentResult;

         // Assert
         _answerServiceMock.Verify(x => x.CreateRangeAsync
            (It.Is<ICollection<AnswerCreateUpdateDto>>(a => a.Count == 1)), Times.Once);
         noContentResult.Should().NotBeNull();
      }


      [Test]
      [TestCase(true)]
      [TestCase(false)]
      public async Task TestController_UpdateTestQuestions_NotFound(bool isQuestionsExist)
      {
         //Arrange
         _testServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()));

         _questionServiceMock.Setup(x => x.IsQuestionsExistAsync(It.IsAny<string>(),
            It.IsAny<IEnumerable<QuestionCreateUpdateDto>>())).ReturnsAsync(isQuestionsExist);

         var models = TestData.QuestionsCreateUpdateDto;

         //Act
         var result = await _testController.UpdateTestQuestions("1", models);
         var notFoundResult = result as NotFoundResult;

         //Assert
         _questionServiceMock.Verify(x => x.UpdateRangeAsync(It.IsAny<IEnumerable<QuestionCreateUpdateDto>>()),
            Times.Never);

         notFoundResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_UpdateTestQuestions_BadRequest()
      {
         //Arrange
         var models = Array.Empty<QuestionCreateUpdateDto>();

         //Act
         var result = await _testController.UpdateTestQuestions("1", models);
         var badRequestResult = result as BadRequestObjectResult;

         //Assert
         _questionServiceMock.Verify(x => x.UpdateRangeAsync(It.IsAny<IEnumerable<QuestionCreateUpdateDto>>()),
            Times.Never);

         _testServiceMock.Verify(x => x.GetByIdAsync(It.IsAny<string>()), Times.Never);

         badRequestResult.Should().NotBeNull();
         badRequestResult.Value.Should().Be("Object is empty");
      }

      [Test]
      [TestCase("1", "4")]
      [TestCase("2", "5")]
      [TestCase("3", "3")]
      public async Task TestController_RemoveQuestionFromTest_Success(string testId, string questionId)
      {
         //Arrange
         var getQuestion = TestData.GetQuestionsDto.Concat(AdditionalQuestionDtos)
            .First(x => x.Id == questionId);

         _questionServiceMock.Setup(x => x.GetQuestionByIdAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(getQuestion);

         //Act
         var result = await _testController.RemoveQuestionFromTest(testId, questionId);
         var noContentResult = result as NoContentResult;

         //Assert
         _questionServiceMock.Verify(x => x.DeleteAsync(It.Is<QuestionGetDto>(y =>
         y.Id == questionId && y.TestId == testId)), Times.Once);

         noContentResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_RemoveQuestionFromTest_NotFound()
      {
         //Arrange
         _questionServiceMock.Setup(x => x.GetQuestionByIdAsync(It.IsAny<string>(), It.IsAny<string>()));

         //Act
         var result = await _testController.RemoveQuestionFromTest("1", "3");
         var notFoundResult = result as NotFoundResult;

         //Assert
         _questionServiceMock.Verify(x => x.DeleteAsync(It.IsAny<QuestionGetDto>()), Times.Never);
         notFoundResult.Should().NotBeNull();
      }

      [Test]
      [TestCase("1")]
      [TestCase("2")]
      [TestCase("3")]
      public async Task TestController_AddAnswersToQuestion_Success(string questionId)
      {
         //Arrange
         var getQuestion = TestData.GetQuestionsDto.First(x => x.Id == questionId);

         _questionServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getQuestion);

         var models = TestData.AnswersCreateUpdateDto;

         //Act
         var result = await _testController.AddAnswersToQuestion(questionId, models);
         var createdAtActionResult = result as CreatedAtActionResult;

         //Assert
         _answerServiceMock.Verify(x => x.CreateRangeAsync(It.Is<IEnumerable<AnswerCreateUpdateDto>>(
            y => y.All(a => a.Id != null && a.QuestionId == questionId))), Times.Once);
         _questionServiceMock.Verify(x => x.SetQuestionTypeAsync(questionId), Times.Once);

         createdAtActionResult.Should().NotBeNull();
         createdAtActionResult.Value.Should().BeEquivalentTo(models);
      }

      [Test]
      public async Task TestController_AddAnswersToQuestion_NotFound()
      {
         //Arrange
         _questionServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()));

         var models = TestData.AnswersCreateUpdateDto;

         //Act
         var result = await _testController.AddAnswersToQuestion("1", models);
         var notFoundResult = result as NotFoundResult;

         //Assert
         _answerServiceMock.Verify(x => x.CreateRangeAsync(It.IsAny<IEnumerable<AnswerCreateUpdateDto>>()),
            Times.Never);

         notFoundResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_AddAnswersToQuestion_BadRequest()
      {
         //Arrange
         var models = Array.Empty<AnswerCreateUpdateDto>();

         //Act
         var result = await _testController.AddAnswersToQuestion("1", models);
         var badRequestResult = result as BadRequestObjectResult;

         //Assert
         _answerServiceMock.Verify(x => x.CreateRangeAsync(It.IsAny<IEnumerable<AnswerCreateUpdateDto>>()),
            Times.Never);

         _testServiceMock.Verify(x => x.GetByIdAsync(It.IsAny<string>()), Times.Never);

         badRequestResult.Should().NotBeNull();
         badRequestResult.Value.Should().Be("Object is empty");
      }

      [Test]
      [TestCase("1")]
      [TestCase("2")]
      [TestCase("3")]
      public async Task TestController_UpdateQuestionAnswers_Success(string questionId)
      {
         //Arrange
         var getQuestion = TestData.GetQuestionsDto.First(x => x.Id == questionId);

         _questionServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(getQuestion);

         _answerServiceMock.Setup(x => x.IsAnswersExistAsync(It.IsAny<string>(),
            It.IsAny<IEnumerable<AnswerCreateUpdateDto>>())).ReturnsAsync(true);

         var models = TestData.AnswersCreateUpdateDto;

         //Act
         var result = await _testController.UpdateQuestionAnswers(questionId, models);
         var noContentResult = result as NoContentResult;

         //Assert
         _answerServiceMock.Verify(x => x.UpdateRangeAsync(It.Is<IEnumerable<AnswerCreateUpdateDto>>(
            y => y.All(a => a.QuestionId == questionId))), Times.Once);
         _questionServiceMock.Verify(x => x.SetQuestionTypeAsync(questionId), Times.Once);

         noContentResult.Should().NotBeNull();
      }

      [Test]
      [TestCase(true)]
      [TestCase(false)]
      public async Task TestController_UpdateQuestionAnswers_NotFound(bool isQuestionsExist)
      {
         //Arrange
         _questionServiceMock.Setup(x => x.GetByIdAsync(It.IsAny<string>()));

         _answerServiceMock.Setup(x => x.IsAnswersExistAsync(It.IsAny<string>(),
            It.IsAny<IEnumerable<AnswerCreateUpdateDto>>())).ReturnsAsync(isQuestionsExist);

         var models = TestData.AnswersCreateUpdateDto;

         //Act
         var result = await _testController.UpdateQuestionAnswers("1", models);
         var notFoundResult = result as NotFoundResult;

         //Assert
         _answerServiceMock.Verify(x => x.UpdateRangeAsync(It.IsAny<IEnumerable<AnswerCreateUpdateDto>>()),
            Times.Never);

         notFoundResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_UpdateQuestionAnswers_BadRequest()
      {
         //Arrange
         var models = Array.Empty<AnswerCreateUpdateDto>();

         //Act
         var result = await _testController.UpdateQuestionAnswers("1", models);
         var badRequestResult = result as BadRequestObjectResult;

         //Assert
         _answerServiceMock.Verify(x => x.UpdateRangeAsync(It.IsAny<IEnumerable<AnswerCreateUpdateDto>>()),
            Times.Never);

         _questionServiceMock.Verify(x => x.GetByIdAsync(It.IsAny<string>()), Times.Never);

         badRequestResult.Should().NotBeNull();
         badRequestResult.Value.Should().Be("Object is empty");
      }

      [Test]
      [TestCase("1", "4")]
      [TestCase("2", "5")]
      [TestCase("3", "3")]
      public async Task TestController_RemoveAnswerFromQuestion_Success(string questionId, string answerId)
      {
         //Arrange
         var getAnswer = TestData.GetAnswersDto.Concat(AdditionalAnswerDtos)
            .First(x => x.Id == answerId);

         _answerServiceMock.Setup(x => x.GetAnswerByIdAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(getAnswer);

         //Act
         var result = await _testController.RemoveAnswerFromQuestion(questionId, answerId);
         var noContentResult = result as NoContentResult;

         //Assert
         _answerServiceMock.Verify(x => x.DeleteAsync(It.Is<AnswerGetDto>(y =>
         y.Id == answerId && y.QuestionId == questionId)), Times.Once);

         noContentResult.Should().NotBeNull();
      }

      [Test]
      public async Task TestController_RemoveAnswerFromQuestion_NotFound()
      {
         //Arrange
         _answerServiceMock.Setup(x => x.GetAnswerByIdAsync(It.IsAny<string>(), It.IsAny<string>()));

         //Act
         var result = await _testController.RemoveAnswerFromQuestion("1", "3");
         var notFoundResult = result as NotFoundResult;

         //Assert
         _answerServiceMock.Verify(x => x.DeleteAsync(It.IsAny<AnswerGetDto>()), Times.Never);
         notFoundResult.Should().NotBeNull();
      }

      private static List<TestGetDto> AdditionalTestDtos =>
         new()
         {
            new TestGetDto{Id = "4", UserId = "1"},
            new TestGetDto{Id = "5", UserId = "2"}
         };

      private static List<QuestionGetDto> AdditionalQuestionDtos =>
      new()
      {
            new QuestionGetDto{Id = "4", TestId = "1"},
            new QuestionGetDto{Id = "5", TestId = "2"}
      };

      private static List<AnswerGetDto> AdditionalAnswerDtos =>
      new()
      {
            new AnswerGetDto{Id = "4", QuestionId = "1"},
            new AnswerGetDto{Id = "5", QuestionId = "2"}
      };
   }
}