﻿using BusinessLogicLayer.Interfaces;
using FluentAssertions;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Moq;
using WebAPI.Controllers;

namespace WebAPI.Tests.WebAPITests
{
	[TestFixture]
	public class RoleControllerTests
	{
		private RoleController _roleController;
		private Mock<IRoleService> _roleServiceMock;

		[SetUp]
		public void SetUp()
		{
			_roleServiceMock = new();
			_roleController = new RoleController(_roleServiceMock.Object);
		}

		[Test]
		[TestCase("role1")]
		[TestCase("role2")]
		[TestCase("role3")]
		public async Task RoleController_AddRole_Success(string roleName)
		{
			//Arrange
			_roleServiceMock.Setup(x => x.AddRoleAsync(It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Success);

			//Act
			var result = await _roleController.AddRole(roleName);
			var statusCodeResult = result as StatusCodeResult;

			//Assert
			_roleServiceMock.Verify(x => x.AddRoleAsync(It.Is<string>(y => y == roleName)), Times.Once);

			statusCodeResult.Should().NotBeNull();
			statusCodeResult.StatusCode.Should().Be(201);
		}

		[Test]
		public async Task RoleController_AddRole_BadRequest()
		{
			//Arrange
			_roleServiceMock.Setup(x => x.AddRoleAsync(It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Failed());

			//Act
			var result = await _roleController.AddRole("role");
			var badRequestResult = result as BadRequestObjectResult;

			//Assert
			_roleServiceMock.Verify(x => x.AddRoleAsync(It.Is<string>(y => y == "role")), Times.Once);

			badRequestResult.Should().NotBeNull();
			badRequestResult.Value.Should().NotBeNull();
		}

		[Test]
		public async Task RoleController_GetRoles_ReturnsAll()
		{
			//Arrange
			_roleServiceMock.Setup(x => x.GetRolesAsync())
				.ReturnsAsync(TestData.GetRoles);

			//Act
			var result = await _roleController.GetRoles();
			var okResult = result as OkObjectResult;

			//Assert
			okResult.Should().NotBeNull();
			okResult.Value.Should().BeEquivalentTo(TestData.GetRoles);
		}

		[Test]
		[TestCase("role1")]
		[TestCase("role2")]
		[TestCase("role3")]
		public async Task RoleController_DeleteRole_Success(string roleName)
		{
			//Arrange
			_roleServiceMock.Setup(x => x.DeleteRoleAsync(It.IsAny<string>()))
				.ReturnsAsync(true);

			//Act
			var result = await _roleController.DeleteRole(roleName);
			var noContentResult = result as NoContentResult;

			//Assert
			_roleServiceMock.Verify(x => x.DeleteRoleAsync(It.Is<string>(y => y == roleName)), Times.Once);

			noContentResult.Should().NotBeNull();
		}

		[Test]
		public async Task RoleController_DeleteRole_NotFound()
		{
			//Arrange
			_roleServiceMock.Setup(x => x.DeleteRoleAsync(It.IsAny<string>()))
				.ReturnsAsync(false);

			//Act
			var result = await _roleController.DeleteRole("role");
			var notFoundResult = result as NotFoundResult;

			//Assert
			_roleServiceMock.Verify(x => x.DeleteRoleAsync(It.Is<string>(y => y == "role")), Times.Once);

			notFoundResult.Should().NotBeNull();
		}
	}
}
