﻿using BusinessLogicLayer.Dtos.User;
using BusinessLogicLayer.Interfaces;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Moq;
using WebAPI.Controllers;

namespace WebAPI.Tests.WebAPITests
{
	[TestFixture]
	public class UserControllerTests
	{
		private UserController _userController;
		private Mock<IUserService> _userServiceMock;

		[SetUp]
		public void SetUp()
		{
			_userServiceMock = new();
			_userController = new UserController(_userServiceMock.Object);
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserController_RegisterUser_Success(string userName)
		{
			//Arrange
			_userServiceMock.Setup(x => x.RegisterWithRoleAsync(It.IsAny<UserRegistrationDto>(),
				It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Success);

			var model = TestData.UserRegistrationDtos.First(x => x.UserName == userName);

			//Act
			var result = await _userController.RegisterUser(model);
			var statusCodeResult = result as StatusCodeResult;

			//Assert
			_userServiceMock.Verify(x => x.RegisterWithRoleAsync(It.Is<UserRegistrationDto>(y =>
			y.UserName == userName), It.IsAny<string>()), Times.Once);

			statusCodeResult.Should().NotBeNull();
			statusCodeResult.StatusCode.Should().Be(201);
		}

		[Test]
		public async Task UserController_RegisterUser_BadRequest()
		{
			//Arrange
			_userServiceMock.Setup(x => x.RegisterWithRoleAsync(It.IsAny<UserRegistrationDto>(),
				It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Failed());

			var model = TestData.UserRegistrationDtos.First();

			//Act
			var result = await _userController.RegisterUser(model);
			var badRequestResult = result as BadRequestObjectResult;

			//Assert
			_userServiceMock.Verify(x => x.RegisterWithRoleAsync(It.Is<UserRegistrationDto>(y =>
			y.UserName == model.UserName), It.IsAny<string>()), Times.Once);

			badRequestResult.Should().NotBeNull();
			badRequestResult.Value.Should().NotBeNull();
		}

		[Test]
		[TestCase("name1", "role1")]
		[TestCase("name2", "role2")]
		[TestCase("name3", "role3")]
		public async Task UserController_RegisterWithRole_Success(string userName, string role)
		{
			//Arrange
			_userServiceMock.Setup(x => x.RegisterWithRoleAsync(It.IsAny<UserRegistrationDto>(),
				It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Success);

			var model = TestData.UserRegistrationDtos.First(x => x.UserName == userName);

			//Act
			var result = await _userController.RegisterWithRole(model, role);
			var statusCodeResult = result as StatusCodeResult;

			//Assert
			_userServiceMock.Verify(x => x.RegisterWithRoleAsync(It.Is<UserRegistrationDto>(y =>
			y.UserName == userName), It.Is<string>(y => y == role)), Times.Once);

			statusCodeResult.Should().NotBeNull();
			statusCodeResult.StatusCode.Should().Be(201);
		}

		[Test]
		public async Task UserController_RegisterWithRole_BadRequest()
		{
			//Arrange
			_userServiceMock.Setup(x => x.RegisterWithRoleAsync(It.IsAny<UserRegistrationDto>(),
				It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Failed());

			var model = TestData.UserRegistrationDtos.First();

			//Act
			var result = await _userController.RegisterWithRole(model, "role");
			var badRequestResult = result as BadRequestObjectResult;

			//Assert
			_userServiceMock.Verify(x => x.RegisterWithRoleAsync(It.Is<UserRegistrationDto>(y =>
			y.UserName == "name1"), It.Is<string>(y => y == "role")), Times.Once);

			badRequestResult.Should().NotBeNull();
			badRequestResult.Value.Should().NotBeNull();
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserController_Authenticate_Success(string userName)
		{
			//Arrange
			var getUser = TestData.UserGetDtos.First(x => x.UserName == userName);

			_userServiceMock.Setup(x => x.ValidateUserAsync(It.IsAny<UserLoginDto>()))
				.ReturnsAsync(true);

			_userServiceMock.Setup(x => x.CreateTokenAsync()).ReturnsAsync("token");
			_userServiceMock.Setup(x => x.GetUserAsync(userName)).ReturnsAsync(getUser);

			var model = TestData.UserLoginDtos.First(x => x.UserName == userName);

			//Act
			var result = await _userController.Authenticate(model);
			var okResult = result as OkObjectResult;

			//Assert
			_userServiceMock.Verify(x => x.ValidateUserAsync(It.Is<UserLoginDto>(y =>
			y.UserName == userName)), Times.Once);

			okResult.Should().NotBeNull();
			okResult.Value.Should().NotBeNull();
		}

		[Test]
		public async Task UserController_Authenticate_NotFound()
		{
			//Arrange
			_userServiceMock.Setup(x => x.ValidateUserAsync(It.IsAny<UserLoginDto>()))
				.ReturnsAsync(false);

			var model = TestData.UserLoginDtos.First();

			//Act
			var result = await _userController.Authenticate(model);
			var notFoundResult = result as NotFoundResult;

			//Assert
			_userServiceMock.Verify(x => x.GetUserAsync(It.IsAny<string>()), Times.Never);
			_userServiceMock.Verify(x => x.CreateTokenAsync(), Times.Never);

			notFoundResult.Should().NotBeNull();
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserController_DeleteUser_Success(string userName)
		{
			//Arrange
			_userServiceMock.Setup(x => x.DeleteUserAsync(It.IsAny<string>()))
				.ReturnsAsync(true);

			//Act
			var result = await _userController.DeleteUser(userName);
			var noContentResult = result as NoContentResult;

			//Assert
			_userServiceMock.Verify(x => x.DeleteUserAsync(It.Is<string>(y => y == userName)), Times.Once);

			noContentResult.Should().NotBeNull();
		}

		[Test]
		public async Task UserController_DeleteUser_NotFound()
		{
			//Arrange
			_userServiceMock.Setup(x => x.DeleteUserAsync(It.IsAny<string>()))
				.ReturnsAsync(false);

			//Act
			var result = await _userController.DeleteUser("name");
			var notFoundResult = result as NotFoundResult;

			//Assert
			_userServiceMock.Verify(x => x.DeleteUserAsync(It.Is<string>(y => y == "name")), Times.Once);

			notFoundResult.Should().NotBeNull();
		}

		[Test]
		public async Task UserController_GetUsers_ReturnsAll()
		{
			//Arrange
			_userServiceMock.Setup(x => x.GetUsersAsync())
				.ReturnsAsync(TestData.UserGetDtos);

			//Act
			var result = await _userController.GetUsers();
			var okResult = result as OkObjectResult;

			//Assert
			okResult.Should().NotBeNull();
			okResult.Value.Should().BeEquivalentTo(TestData.UserGetDtos);
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserController_GetUserByName_ReturnsByname(string userName)
		{
			//Arrange
			var expected = TestData.UserGetDtos.First(x => x.UserName == userName);

			_userServiceMock.Setup(x => x.GetUserAsync(It.IsAny<string>()))
				.ReturnsAsync(expected);

			Mock<HttpContext> _contextMock = new();

			_userController.ControllerContext = new ControllerContext()
			{
				HttpContext = _contextMock.Object
			};

			_contextMock.Setup(x => x.User.Identity.Name).Returns(userName);
			_contextMock.Setup(x => x.User.IsInRole(It.IsAny<string>())).Returns(true);

			//Act
			var result = await _userController.GetUserByName(userName);
			var okResult = result as OkObjectResult;

			//Assert
			okResult.Should().NotBeNull();
			okResult.Value.Should().BeEquivalentTo(expected);
		}

		[Test]
		public async Task UserController_GetUserByName_NotFound()
		{
			//Arrange
			_userServiceMock.Setup(x => x.GetUserAsync(It.IsAny<string>()));

			//Act
			var result = await _userController.GetUserByName("1");
			var notFoundResult = result as NotFoundResult;

			//Assert
			notFoundResult.Should().NotBeNull();
		}

		[Test]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserController_GetUserByName_Unauthorized(string userName)
		{
			//Arrange
			var getUser = TestData.UserGetDtos.First();

			_userServiceMock.Setup(x => x.GetUserAsync(It.IsAny<string>()))
				.ReturnsAsync(getUser);

			Mock<HttpContext> _contextMock = new();

			_userController.ControllerContext = new ControllerContext()
			{
				HttpContext = _contextMock.Object
			};

			_contextMock.Setup(x => x.User.Identity.Name).Returns(userName);
			_contextMock.Setup(x => x.User.IsInRole(It.IsAny<string>())).Returns(false);

			//Act
			var result = await _userController.GetUserByName("name1");
			var unauthorizedResult = result as UnauthorizedResult;

			//Assert
			unauthorizedResult.Should().NotBeNull();
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserController_UpdateUser_Success(string userName)
		{
			//Arrange
			var getUser = TestData.UserGetDtos.First(x => x.UserName == userName);

			_userServiceMock.Setup(x => x.GetUserAsync(It.IsAny<string>()))
				.ReturnsAsync(getUser);

			_userServiceMock.Setup(x => x.UpdateUserAsync(It.IsAny<UserUpdateDto>()))
				.ReturnsAsync(IdentityResult.Success);

			Mock<HttpContext> _contextMock = new();

			_userController.ControllerContext = new ControllerContext()
			{
				HttpContext = _contextMock.Object
			};

			_contextMock.Setup(x => x.User.Identity.Name).Returns(userName);
			_contextMock.Setup(x => x.User.IsInRole(It.IsAny<string>())).Returns(true);

			var model = TestData.UserUpdateDtos.First(x => x.UserName != userName);

			//Act
			var result = await _userController.UpdateUser(userName, model);
			var noContentResult = result as NoContentResult;

			//Assert
			_userServiceMock.Verify(x => x.UpdateUserAsync(It.Is<UserUpdateDto>(y => y.UserName == userName)),
				Times.Once);

			noContentResult.Should().NotBeNull();
		}

		[Test]
		public async Task UserController_UpdateUser_NotFound()
		{
			//Arrange
			_userServiceMock.Setup(x => x.GetUserAsync(It.IsAny<string>()));

			var model = TestData.UserUpdateDtos.First();

			//Act
			var result = await _userController.UpdateUser("name", model);
			var notFoundResult = result as NotFoundResult;

			//Assert
			_userServiceMock.Verify(x => x.UpdateUserAsync(It.IsAny<UserUpdateDto>()), Times.Never);
			notFoundResult.Should().NotBeNull();
		}

		[Test]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserController_UpdateUser_Unauthorized(string userName)
		{
			//Arrange
			var getUser = TestData.UserGetDtos.First();

			_userServiceMock.Setup(x => x.GetUserAsync(It.IsAny<string>()))
				.ReturnsAsync(getUser);

			Mock<HttpContext> _contextMock = new();

			_userController.ControllerContext = new ControllerContext()
			{
				HttpContext = _contextMock.Object
			};

			_contextMock.Setup(x => x.User.Identity.Name).Returns(userName);
			_contextMock.Setup(x => x.User.IsInRole(It.IsAny<string>())).Returns(false);

			var model = TestData.UserUpdateDtos.First();

			//Act
			var result = await _userController.UpdateUser("name", model);
			var unauthorizedResult = result as UnauthorizedResult;

			//Assert
			_userServiceMock.Verify(x => x.UpdateUserAsync(It.IsAny<UserUpdateDto>()), Times.Never);
			unauthorizedResult.Should().NotBeNull();
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserController_UpdateUser_BadRequest(string userName)
		{
			//Arrange
			var getUser = TestData.UserGetDtos.First(x => x.UserName == userName);

			_userServiceMock.Setup(x => x.GetUserAsync(It.IsAny<string>()))
				.ReturnsAsync(getUser);

			_userServiceMock.Setup(x => x.UpdateUserAsync(It.IsAny<UserUpdateDto>()))
				.ReturnsAsync(IdentityResult.Failed());

			Mock<HttpContext> _contextMock = new();

			_userController.ControllerContext = new ControllerContext()
			{
				HttpContext = _contextMock.Object
			};

			_contextMock.Setup(x => x.User.Identity.Name).Returns(userName);
			_contextMock.Setup(x => x.User.IsInRole(It.IsAny<string>())).Returns(true);

			var model = TestData.UserUpdateDtos.First(x => x.UserName != userName);

			//Act
			var result = await _userController.UpdateUser(userName, model);
			var badRequestResult = result as BadRequestObjectResult;

			//Assert
			_userServiceMock.Verify(x => x.UpdateUserAsync(It.Is<UserUpdateDto>(y => y.UserName == userName)),
				Times.Once);

			badRequestResult.Should().NotBeNull();
			badRequestResult.Value.Should().NotBeNull();
		}

		[Test]
		[TestCase("name1", "role1")]
		[TestCase("name2", "role2")]
		[TestCase("name3", "role3")]
		public async Task UserController_AddRoleToUser_Success(string userName, string role)
		{
			//Arrange
			_userServiceMock.Setup(x => x.AddRoleToUserAsync(It.IsAny<string>(), It.IsAny<string>()))
				.ReturnsAsync(true);

			//Act
			var result = await _userController.AddRoleToUser(userName, role);
			var noContentResult = result as NoContentResult;

			//Assert
			_userServiceMock.Verify(x => x.AddRoleToUserAsync(It.Is<string>(y => y == userName),
				It.Is<string>(y => y == role)), Times.Once);

			noContentResult.Should().NotBeNull();
		}

		[Test]
		public async Task UserController_AddRoleToUser_NotFound()
		{
			//Arrange
			_userServiceMock.Setup(x => x.AddRoleToUserAsync(It.IsAny<string>(), It.IsAny<string>()))
				.ReturnsAsync(false);

			//Act
			var result = await _userController.AddRoleToUser("name", "role");
			var notFoundResult = result as NotFoundObjectResult;

			//Assert
			_userServiceMock.Verify(x => x.AddRoleToUserAsync(It.Is<string>(y => y == "name"), It.Is<string>(
				y => y == "role")), Times.Once);

			notFoundResult.Should().NotBeNull();
			notFoundResult.Value.Should().Be("User or role not found");
		}

		[Test]
		[TestCase("name1", "role1")]
		[TestCase("name2", "role2")]
		[TestCase("name3", "role3")]
		public async Task UserController_RemoveRoleFromUser_Success(string userName, string role)
		{
			//Arrange
			_userServiceMock.Setup(x => x.RemoveRoleFromUserAsync(It.IsAny<string>(), It.IsAny<string>()))
				.ReturnsAsync(true);

			//Act
			var result = await _userController.RemoveRoleFromUser(userName, role);
			var noContentResult = result as NoContentResult;

			//Assert
			_userServiceMock.Verify(x => x.RemoveRoleFromUserAsync(It.Is<string>(y => y == userName),
				It.Is<string>(y => y == role)), Times.Once);

			noContentResult.Should().NotBeNull();
		}

		[Test]
		public async Task UserController_RemoveRoleFromUser_NotFound()
		{
			//Arrange
			_userServiceMock.Setup(x => x.RemoveRoleFromUserAsync(It.IsAny<string>(), It.IsAny<string>()))
				.ReturnsAsync(false);

			//Act
			var result = await _userController.RemoveRoleFromUser("name", "role");
			var notFoundResult = result as NotFoundObjectResult;

			//Assert
			_userServiceMock.Verify(x => x.RemoveRoleFromUserAsync(It.Is<string>(y => y == "name"),
				It.Is<string>(y => y == "role")), Times.Once);

			notFoundResult.Should().NotBeNull();
			notFoundResult.Value.Should().Be("User or role not found");
		}
	}
}
