﻿using BusinessLogicLayer.Interfaces;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using WebAPI.Controllers;

namespace WebAPI.Tests.WebAPITests
{
   [TestFixture]
   public class StatisticControllerTests
   {
      private StatisticController _statisticController;
      private Mock<IStatisticService> _statisticServiceMock;

      [SetUp]
      public void SetUp()
      {
         _statisticServiceMock = new();
         _statisticController = new StatisticController(_statisticServiceMock.Object);
      }

      [Test]
      [TestCase(-2)]
      [TestCase(0)]
      [TestCase(5)]
      public async Task StatisticController_GetMostValuableQuestions_ReturnsAll(int count)
      {
         //Arrange
         _statisticServiceMock.Setup(x => x.GetMostValuableQuestionsAsync(count))
            .ReturnsAsync(TestData.GetQuestionsDto.Take(count));

         //Act
         var result = await _statisticController.GetMostValuableQuestions(count);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(TestData.GetQuestionsDto.Take(count));
      }

      [Test]
      [TestCase(-2)]
      [TestCase(0)]
      [TestCase(5)]
      public async Task StatisticController_GetMostActiveTestCreatorsUser_ReturnsAll(int count)
      {
         //Arrange
         _statisticServiceMock.Setup(x => x.GetMostActiveTestCreatorsAsync(count))
            .ReturnsAsync(TestData.UserGetDtos.Take(count));

         //Act
         var result = await _statisticController.GetMostActiveTestCreatorsUser(count);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(TestData.UserGetDtos.Take(count));
      }

      [Test]
      [TestCase(-2)]
      [TestCase(0)]
      [TestCase(5)]
      public async Task StatisticController_GetMostActiveUser_ReturnsAll(int count)
      {
         //Arrange
         _statisticServiceMock.Setup(x => x.GetMostActiveUsersAsync(count))
            .ReturnsAsync(TestData.UserGetDtos.Take(count));

         //Act
         var result = await _statisticController.GetMostActiveUser(count);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(TestData.UserGetDtos.Take(count));
      }

      [Test]
      [TestCase(-2)]
      [TestCase(0)]
      [TestCase(5)]
      public async Task StatisticController_GetMostSuccessfulUsers_ReturnsAll(int count)
      {
         //Arrange
         _statisticServiceMock.Setup(x => x.GetMostSuccessfulUsersAsync(count))
            .ReturnsAsync(TestData.UserGetDtos.Take(count));

         //Act
         var result = await _statisticController.GetMostSuccessfulUsers(count);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(TestData.UserGetDtos.Take(count));
      }

      [Test]
      [TestCase(-2)]
      [TestCase(0)]
      [TestCase(5)]
      public async Task StatisticController_GetMostPopularTests_ReturnsAll(int count)
      {
         //Arrange
         _statisticServiceMock.Setup(x => x.GetMostPopularTestsAsync(count))
            .ReturnsAsync(TestData.GetTestsDto.Take(count));

         //Act
         var result = await _statisticController.GetMostPopularTests(count);
         var okResult = result as OkObjectResult;

         //Assert
         okResult.Should().NotBeNull();
         okResult.Value.Should().BeEquivalentTo(TestData.GetTestsDto.Take(count));
      }
   }
}
