﻿using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Services;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using FluentAssertions;
using MockQueryable.Moq;
using Moq;

namespace WebAPI.Tests.BusinessTests
{
   [TestFixture]
   public class StatisticServiceTests
   {
      private IStatisticService _statisticService;
      private Mock<IUnitOfWork> _unitOfWorkMock;

      [SetUp]
      public void SetUp()
      {
         _unitOfWorkMock = new();
         _statisticService = new StatisticService(_unitOfWorkMock.Object, UnitTestHelper.CreateMapperProfile());
      }

      [Test]
      [TestCase(1)]
      [TestCase(2)]
      [TestCase(3)]
      public async Task StatisticService_GetMostActiveTestCreatorsAsync_ReturnByCount(int count)
      {
         //Arrange
         var expected = TestData.UserGetDtos.Take(count);

         _unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.User))
            .ReturnsAsync(TestData.GetTests.BuildMock());

         //Act
         var actual = await _statisticService.GetMostActiveTestCreatorsAsync(count);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase(1)]
      [TestCase(2)]
      [TestCase(3)]
      public async Task StatisticService_GetMostActiveUsersAsync_ReturnByCount(int count)
      {
         //Arrange
         var expected = TestData.UserGetDtos.Take(count);

         _unitOfWorkMock.Setup(x => x.Repository<UserStatistics>().GetAllWithIncludeAsync(t => t.User))
            .ReturnsAsync(TestData.GetUserStatistics.BuildMock());

         //Act
         var actual = await _statisticService.GetMostActiveUsersAsync(count);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase(1)]
      [TestCase(2)]
      [TestCase(3)]
      public async Task StatisticService_GetMostSuccessfulUsersAsync_ReturnByCount(int count)
      {
         //Arrange
         var expected = TestData.UserGetDtos.Take(count);

         _unitOfWorkMock.Setup(x => x.Repository<UserStatistics>().GetAllWithIncludeAsync(t => t.User))
            .ReturnsAsync(TestData.GetUserStatistics.BuildMock());

         //Act
         var actual = await _statisticService.GetMostSuccessfulUsersAsync(count);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase(1)]
      [TestCase(2)]
      [TestCase(3)]
      public async Task StatisticService_GetMostPopularTests_ReturnByCount(int count)
      {
         //Arrange
         var expected = TestData.GetTestsDto.TakeLast(count);

         _unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
            t => t.TestStatistics))
            .ReturnsAsync(TestData.GetTests.BuildMock());

         //Act
         var actual = await _statisticService.GetMostPopularTestsAsync(count);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase(1)]
      [TestCase(2)]
      [TestCase(3)]
      public async Task StatisticService_GetMostValuableQuestions_ReturnByCount(int count)
      {
         //Arrange
         var expected = TestData.GetQuestionsDto.TakeLast(count);

         _unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions))
            .ReturnsAsync(TestData.GetTests.BuildMock());

         //Act
         var actual = await _statisticService.GetMostValuableQuestionsAsync(count);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }
   }
}
