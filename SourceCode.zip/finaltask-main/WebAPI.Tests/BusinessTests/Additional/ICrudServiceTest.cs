﻿namespace WebAPI.Tests.BusinessTests.Additional
{
   public interface ICrudServiceTest
   {
      Task TestGetAllAsync();

      Task TestGetAllWithExpressionAsync();

      Task TestGetByIdAsync();

      Task TestCreateAsync();

      Task TestCreateRangeAsync();

      Task TestUpdateAsync();

      Task TestUpdateRangeAsync();

      Task TestDeleteAsync();
   }
}