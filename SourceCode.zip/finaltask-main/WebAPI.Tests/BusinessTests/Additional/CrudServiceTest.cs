﻿using BusinessLogicLayer.Dtos.Answers;
using BusinessLogicLayer.Dtos.BaseDto;
using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Dtos.TestStatistics;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Services;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using FluentAssertions;
using MockQueryable.Moq;
using Moq;

namespace WebAPI.Tests.BusinessTests.Additional
{
   public class CrudServiceTest<TGet, TCreateUpdate, Entity> : ICrudServiceTest
      where TGet : BaseGetDto
      where TCreateUpdate : BaseCreateUpdateDto
      where Entity : BaseEntity
   {
      private readonly Mock<IUnitOfWork> _unitOfWorkMock;
      private readonly ICrud<TGet, TCreateUpdate> _crudService;

      public CrudServiceTest()
      {
         _unitOfWorkMock = new();
         _crudService = new CrudService<TGet, TCreateUpdate, Entity>
            (_unitOfWorkMock.Object, UnitTestHelper.CreateMapperProfile());
      }

      public async Task TestCreateAsync()
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Entity>().CreateAsync(It.IsAny<Entity>()));

         var model = CreateUpdateDtos().First();

         //Act
         await _crudService.CreateAsync(model);

         //Assert
         _unitOfWorkMock.Verify(x => x.Repository<Entity>().CreateAsync(It.Is<Entity>(y =>
                     y.Id == model.Id)), Times.Once);
         _unitOfWorkMock.Verify(x => x.SaveAsync(), Times.Once);
      }

      public async Task TestCreateRangeAsync()
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Entity>().CreateRangeAsync(It.IsAny<IEnumerable<Entity>>()));

         var models = CreateUpdateDtos();

         //Act
         await _crudService.CreateRangeAsync(models);

         //Assert
         _unitOfWorkMock.Verify(x => x.Repository<Entity>().CreateRangeAsync(It.Is<IEnumerable<Entity>>(y =>
                     y.Count() == models.Count)), Times.Once);
         _unitOfWorkMock.Verify(x => x.SaveAsync(), Times.Once);
      }

      public async Task TestDeleteAsync()
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Entity>().DeleteAsync(It.IsAny<Entity>()));

         var model = GetDtos().First();

         //Act
         await _crudService.DeleteAsync(model);

         //Assert
         _unitOfWorkMock.Verify(x => x.Repository<Entity>().DeleteAsync(It.Is<Entity>(y =>
                     y.Id == model.Id)), Times.Once);
         _unitOfWorkMock.Verify(x => x.SaveAsync(), Times.Once);
      }

      public async Task TestGetAllAsync()
      {
         //Arrange
         var expected = GetDtos();

         _unitOfWorkMock.Setup(x => x.Repository<Entity>().GetAllAsync())
            .ReturnsAsync(GetEntities().BuildMock());

         //Act
         var actual = await _crudService.GetAllAsync();

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      public async Task TestGetAllWithExpressionAsync()
      {
         //Arrange
         var expected = GetDtos().FirstOrDefault(x => x.Id == "1");

         _unitOfWorkMock.Setup(x => x.Repository<Entity>().GetAllAsync())
            .ReturnsAsync(GetEntities().AsQueryable());

         //Act
         var actual = await _crudService.GetAllAsync(x => x.Id == "1");

         //Assert
         actual.Count().Should().Be(1);
         actual.First().Should().BeEquivalentTo(expected);
      }

      public async Task TestGetByIdAsync()
      {
         //Arrange
         var expected = GetDtos().First();

         _unitOfWorkMock.Setup(x => x.Repository<Entity>().GetByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(GetEntities().First());

         //Act
         var actual = await _crudService.GetByIdAsync("1");

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      public async Task TestUpdateAsync()
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Entity>().UpdateAsync(It.IsAny<Entity>()));

         var model = CreateUpdateDtos().First();

         //Act
         await _crudService.UpdateAsync(model);

         //Assert
         _unitOfWorkMock.Verify(x => x.Repository<Entity>().UpdateAsync(It.Is<Entity>(y =>
                     y.Id == model.Id)), Times.Once);
         _unitOfWorkMock.Verify(x => x.SaveAsync(), Times.Once);
      }

      public async Task TestUpdateRangeAsync()
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Entity>().UpdateRangeAsync(It.IsAny<IEnumerable<Entity>>()));

         var models = CreateUpdateDtos();

         //Act
         await _crudService.UpdateRangeAsync(models);

         //Assert
         _unitOfWorkMock.Verify(x => x.Repository<Entity>().UpdateRangeAsync(It.Is<IEnumerable<Entity>>(y =>
                     y.Count() == models.Count)), Times.Once);
         _unitOfWorkMock.Verify(x => x.SaveAsync(), Times.Once);
      }

      private static List<TGet> GetDtos()
      {
         if (typeof(TGet).Name == typeof(TestGetDto).Name)
            return TestData.GetTestsDto as List<TGet>;

         else if (typeof(TGet).Name == typeof(QuestionGetDto).Name)
            return TestData.GetQuestionsDto as List<TGet>;

         else if (typeof(TGet).Name == typeof(AnswerGetDto).Name)
            return TestData.GetAnswersDto as List<TGet>;

         else if (typeof(TGet).Name == typeof(TestStatisticsGetDto).Name)
            return TestData.GetTestStatisticsDto as List<TGet>;

         else
            return TestData.GetUserStatisticsDto as List<TGet>;
      }

      private static List<Entity> GetEntities()
      {
         if (typeof(Entity).Name == typeof(Test).Name)
            return TestData.GetTests as List<Entity>;

         else if (typeof(Entity).Name == typeof(Question).Name)
            return TestData.GetQuestions as List<Entity>;

         else if (typeof(Entity).Name == typeof(Answer).Name)
            return TestData.GetAnswers as List<Entity>;

         else if (typeof(Entity).Name == typeof(TestStatistics).Name)
            return TestData.GetTestStatistics as List<Entity>;

         else
            return TestData.GetUserStatisticsWithoutInclude as List<Entity>;
      }

      private static List<TCreateUpdate> CreateUpdateDtos()
      {
         if (typeof(TCreateUpdate).Name == typeof(TestCreateUpdateDto).Name)
            return TestData.TestsCreateUpdateDto as List<TCreateUpdate>;

         else if (typeof(TCreateUpdate).Name == typeof(QuestionCreateUpdateDto).Name)
            return TestData.QuestionsCreateUpdateDto as List<TCreateUpdate>;

         else if (typeof(TCreateUpdate).Name == typeof(QuestionCreateUpdateDto).Name)
            return TestData.AnswersCreateUpdateDto as List<TCreateUpdate>;

         else if (typeof(TCreateUpdate).Name == typeof(TestStatisticsCreateUpdateDto).Name)
            return TestData.TestStatisticsCreateUpdateDto as List<TCreateUpdate>;

         else
            return TestData.UserStatisticsCreateUpdateDto as List<TCreateUpdate>;
      }
   }
}