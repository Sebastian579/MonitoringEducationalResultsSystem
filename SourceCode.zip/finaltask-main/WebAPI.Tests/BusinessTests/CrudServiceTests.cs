﻿using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Dtos.TestStatistics;
using BusinessLogicLayer.Dtos.UserStatistics;
using DataAccessLayer.Entities;
using WebAPI.Tests.BusinessTests.Additional;

namespace WebAPI.Tests.BusinessTests
{
   [TestFixture]
   public class CrudServiceTests
   {
      private static IEnumerable<ICrudServiceTest> TestCases()
      {
         yield return new CrudServiceTest<TestGetDto, TestCreateUpdateDto, Test>();
         yield return new CrudServiceTest<QuestionGetDto, QuestionCreateUpdateDto, Question>();
         yield return new CrudServiceTest<TestStatisticsGetDto,
            TestStatisticsCreateUpdateDto, TestStatistics>();
         yield return new CrudServiceTest<UserStatisticsGetDto,
            UserStatisticsCreateUpdateDto, UserStatistics>();
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task CrudService_GetAll_ReturnAll(ICrudServiceTest crudService)
      {
         await crudService.TestGetAllAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task CrudService_GetAllWithExpression_ReturnAllByExpression(ICrudServiceTest crudService)
      {
         await crudService.TestGetAllWithExpressionAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task CrudService_GetById_ReturnModel(ICrudServiceTest crudService)
      {
         await crudService.TestGetByIdAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task CrudService_CreateAsync_AddModel(ICrudServiceTest crudService)
      {
         await crudService.TestCreateAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task CrudService_CreateRangeAsync_AddModels(ICrudServiceTest crudService)
      {
         await crudService.TestCreateRangeAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task CrudService_UpdateAsync_UpdateModel(ICrudServiceTest crudService)
      {
         await crudService.TestUpdateAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task CrudService_UpdateRangeAsync_UpdateModels(ICrudServiceTest crudService)
      {
         await crudService.TestUpdateRangeAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task CrudService_DeleteAsync_DeleteModel(ICrudServiceTest crudService)
      {
         await crudService.TestDeleteAsync();

         Assert.That(true);
      }
   }
}
