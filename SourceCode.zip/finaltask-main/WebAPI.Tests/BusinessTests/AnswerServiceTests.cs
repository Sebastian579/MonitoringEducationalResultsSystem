﻿using AutoMapper.Internal;
using BusinessLogicLayer.Dtos.Answers;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Services;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using FluentAssertions;
using MockQueryable.Moq;
using Moq;

namespace WebAPI.Tests.BusinessTests
{
   [TestFixture]
   public class AnswerServiceTests
   {
      private IAnswerService _answerService;
      private Mock<IUnitOfWork> _unitOfWorkMock;

      [SetUp]
      public void SetUp()
      {
         _unitOfWorkMock = new();
         _answerService = new AnswerService(_unitOfWorkMock.Object, UnitTestHelper.CreateMapperProfile());
      }

      [Test]
      [TestCase("1", "1")]
      [TestCase("2", "5")]
      [TestCase("3", "3")]
      public async Task AnswerService_GetById_ReturnById(string questionId, string answerId)
      {
         //Arrange
         var expected = TestData.GetAnswersDto.Concat(AdditionalAnswerDto).First(x => x.Id == answerId);

         _unitOfWorkMock.Setup(x => x.Repository<Answer>().GetAllAsync())
            .ReturnsAsync(TestData.GetAnswers.Concat(AdditionalAnswer).BuildMock());

         //Act
         var actual = await _answerService.GetAnswerByIdAsync(questionId, answerId);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase("1", new[] { "1", "4" })]
      [TestCase("2", new[] { "2", "5" })]
      [TestCase("3", new[] { "3" })]
      public async Task AnswerService_GetByQuestionId_ReturnAllById(string questionId,
         IEnumerable<string> expectedQuestionId)
      {
         //Arrange
         var expected = TestData.GetAnswersDto.Concat(AdditionalAnswerDto)
            .Where(x => expectedQuestionId.Contains(x.Id));

         _unitOfWorkMock.Setup(x => x.Repository<Answer>().GetAllAsync())
            .ReturnsAsync(TestData.GetAnswers.Concat(AdditionalAnswer).BuildMock());

         //Act
         var actual = await _answerService.GetAnswersByQuestionIdAsync(questionId);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase("1", new[] { "1", "4" })]
      [TestCase("2", new[] { "2", "5" })]
      [TestCase("3", new[] { "3" })]
      public async Task AnswerService_IsAnswersExist_ReturnTrue(string testId, IEnumerable<string> chekedId)
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Answer>().GetAllAsync())
            .ReturnsAsync(TestData.GetAnswers.Concat(AdditionalAnswer).BuildMock());

         var models = TestData.AnswersCreateUpdateDto.Concat(AdditionalAnswerCreateUpdate)
            .Where(x => chekedId.Contains(x.Id));

         //Act
         var actual = await _answerService.IsAnswersExistAsync(testId, models);

         //Assert
         actual.Should().BeTrue();
      }

      [Test]
      [TestCase("1", new[] { "1", "4" })]
      [TestCase("2", new[] { "2", "5" })]
      [TestCase("3", new[] { "3" })]
      public async Task AnswerService_IsAnswersExist_ReturnFalse(string testId, IEnumerable<string> chekedId)
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Answer>().GetAllAsync())
            .ReturnsAsync(TestData.GetAnswers.BuildMock());

         var models = TestData.AnswersCreateUpdateDto.Concat(AdditionalAnswerCreateUpdate)
            .Where(x => !chekedId.Contains(x.Id));

         //Act
         var actual = await _answerService.IsAnswersExistAsync(testId, models);

         //Assert
         actual.Should().BeFalse();
      }

      private static List<Answer> AdditionalAnswer =>
         new()
         {
            new Answer{Id = "4", QuestionId = "1", AnswerText = "10"},
            new Answer{Id = "5", QuestionId = "2", AnswerText = "15"}
         };

      private static List<AnswerGetDto> AdditionalAnswerDto =>
         new()
         {
            new AnswerGetDto{Id = "4", QuestionId = "1", AnswerText = "10"},
            new AnswerGetDto{Id = "5", QuestionId = "2", AnswerText = "15"}
         };

      private static List<AnswerCreateUpdateDto> AdditionalAnswerCreateUpdate =>
         new()
         {
            new AnswerCreateUpdateDto{Id = "4", QuestionId = "1", AnswerText = "10"},
            new AnswerCreateUpdateDto{Id = "5", QuestionId = "2", AnswerText = "15"}
         };
   }
}