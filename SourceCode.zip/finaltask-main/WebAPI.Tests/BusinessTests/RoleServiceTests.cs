﻿using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Services;
using FluentAssertions;
using Microsoft.AspNetCore.Identity;
using MockQueryable.Moq;
using Moq;

namespace WebAPI.Tests.BusinessTests
{
	[TestFixture]
	public class RoleServiceTests
	{
		private IRoleService _roleService;
		private Mock<IRoleStore<IdentityRole>> _roleStoreMock;
		private Mock<RoleManager<IdentityRole>> _roleManagerMock;

		[SetUp]
		public void SetUp()
		{
			_roleStoreMock = new();
			_roleManagerMock = new(_roleStoreMock.Object, null, null, null, null);
			_roleService = new RoleService(_roleManagerMock.Object);
		}

		[Test]
		[TestCase("role1  ", "role1")]
		[TestCase("  role2  ", "role2")]
		[TestCase("  role3", "role3")]
		public async Task RoleService_AddRole_Success(string roleName, string expectedRoleName)
		{
			//Arrange
			_roleManagerMock.Setup(x => x.CreateAsync(It.IsAny<IdentityRole>()))
				.ReturnsAsync(IdentityResult.Success);

			//Act
			var result = await _roleService.AddRoleAsync(roleName);

			//Assert
			_roleManagerMock.Verify(x => x.CreateAsync(It.Is<IdentityRole>(y =>
			y.Name == expectedRoleName)), Times.Once);
			result.Succeeded.Should().BeTrue();
		}

		[Test]
		[TestCase("role1")]
		[TestCase("role2")]
		[TestCase("role3")]
		public async Task RoleService_DeleteRole_ReturnTrue(string roleName)
		{
			//Arrange
			var role = TestData.GetRoles.First(x => x.Name == roleName);

			_roleManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()))
				.ReturnsAsync(role);
			_roleManagerMock.Setup(x => x.DeleteAsync(It.IsAny<IdentityRole>()));

			//Act
			var result = await _roleService.DeleteRoleAsync(roleName);

			//Assert
			_roleManagerMock.Verify(x => x.DeleteAsync(It.Is<IdentityRole>(y =>
			y.Name == roleName)), Times.Once);
			result.Should().BeTrue();
		}

		[Test]
		public async Task RoleService_DeleteRole_ReturnFalse()
		{
			//Arrange
			_roleManagerMock.Setup(x => x.DeleteAsync(It.IsAny<IdentityRole>()));
			_roleManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()));

			//Act
			var result = await _roleService.DeleteRoleAsync("role1");

			//Assert
			_roleManagerMock.Verify(x => x.DeleteAsync(It.IsAny<IdentityRole>()), Times.Never);
			result.Should().BeFalse();
		}

		[Test]
		public async Task RoleService_GetRoles_ReturnFalse()
		{
			//Arrange
			var expected = TestData.GetRoles;

			_roleManagerMock.Setup(x => x.Roles).Returns(TestData.GetRoles.BuildMock());

			//Act
			var actual = await _roleService.GetRolesAsync();

			//Assert
			actual.Should().BeEquivalentTo(expected);
		}
	}
}
