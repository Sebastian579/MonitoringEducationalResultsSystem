﻿using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Services;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using FluentAssertions;
using MockQueryable.Moq;
using Moq;

namespace WebAPI.Tests.BusinessTests
{
   [TestFixture]
   public class TestStatisticsServiceTests
   {
      private ITestStatisticsService _testStatisticService;
      private Mock<IUnitOfWork> _unitOfWorkMock;

      [SetUp]
      public void SetUp()
      {
         _unitOfWorkMock = new();
         _testStatisticService = new TestStatisticsService(_unitOfWorkMock.Object,
            UnitTestHelper.CreateMapperProfile());
      }

      [Test]
      [TestCase("1", "1")]
      [TestCase("2", "2")]
      [TestCase("3", "3")]
      public async Task TestStatisticsService_GetByTestId_ReturnById(string testId, string expectedId)
      {
         //Arrange
         var expected = TestData.GetTestStatisticsDto.First(x => x.Id == expectedId);

         _unitOfWorkMock.Setup(x => x.Repository<TestStatistics>().GetAllAsync())
            .ReturnsAsync(TestData.GetTestStatistics.BuildMock());

         //Act
         var actual = await _testStatisticService.GetByTestIdAsync(testId);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase("1", true)]
      [TestCase("2", false)]
      [TestCase("3", true)]
      public async Task TestStatisticsService_IncrementCount_Increment(string Id, bool isPass)
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<TestStatistics>().UpdateAsync(It.IsAny<TestStatistics>()));

         var model = TestData.GetTestStatisticsDto.First(x => x.Id == Id);
         int expectedAttemptCount = model.AttemptCount + 1;
         int expectedPassCount = isPass ? model.PassCount + 1 : model.PassCount;

         //Act
         await _testStatisticService.IncrementCountAsync(model, isPass);

         //Assert
         _unitOfWorkMock.Verify(x => x.Repository<TestStatistics>().UpdateAsync(It.Is<TestStatistics>(y =>
                     y.Id == model.Id && y.AttemptCount == expectedAttemptCount
                     && y.PassCount == expectedPassCount)), Times.Once);
         _unitOfWorkMock.Verify(x => x.SaveAsync(), Times.Once);
      }
   }
}