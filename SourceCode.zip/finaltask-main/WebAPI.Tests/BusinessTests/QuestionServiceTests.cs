﻿using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Models;
using BusinessLogicLayer.Services;
using DataAccessLayer.Entities;
using DataAccessLayer.Enums;
using DataAccessLayer.Interfaces;
using FluentAssertions;
using MockQueryable.Moq;
using Moq;
using NUnit.Framework.Internal;
using System.Linq.Expressions;

namespace WebAPI.Tests.BusinessTests
{
   [TestFixture]
   public class QuestionServiceTests
   {
      private IQuestionService _questionService;
      private Mock<IUnitOfWork> _unitOfWorkMock;

      [SetUp]
      public void SetUp()
      {
         _unitOfWorkMock = new();
         _questionService = new QuestionService(_unitOfWorkMock.Object, UnitTestHelper.CreateMapperProfile());
      }

      [Test]
      public async Task QuestionService_GetByTestIdForTest_ReturnAllById()
      {
         // Arrange
         var testId = "1";

         // Create a test question
         var question = new List<Question>
         {
            new Question
            {
               Id = "q1",
               TestId = testId,
               Type = QuestionType.FreeText,
               Points = 10,
               QuestionText = "Question 1",
               Answers = new List<Answer>
               {
                  new Answer
                  {
                      Id = "a1",
                      AnswerText = "Answer 1",
                      QuestionId = "q1",
                      IsCorrect = true
                  }
               }
            }
         };

         _unitOfWorkMock.Setup(x => x.Repository<Question>().GetAllWithIncludeAsync(q => q.Answers))
            .ReturnsAsync(question.BuildMock());

         var expected = new List<QuestionForTestModel>
         {
            new QuestionForTestModel
            {
               Id = "q1",
               QuestionText = "Question 1",
               Type = QuestionType.FreeText,
               Points = 10,
               TestId = testId,
               Answers = new List<AnswerForTestModel>
               {
                  new AnswerForTestModel
                  {
                      Id = "a1",
                      QuestionId = "q1",
                      AnswerText = ""
                  }
               }
            }
         };

         //Act
         var actual = await _questionService.GetQuestionsByTestIdForTestAsync(testId);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      public async Task QuestionService_SetQuestionType_UpdatesQuestionType()
      {
         // Arrange
         var questionId = "1";
         var answers = new List<Answer>
         {
             new Answer { IsCorrect = true },
             new Answer { IsCorrect = false },
             new Answer { IsCorrect = false }
         };
         var question = new Question
         {
            Id = questionId,
            Type = QuestionType.None,
            Answers = answers
         };

         _unitOfWorkMock.Setup(x => x.Repository<Question>().GetByIdWithIncludeAsync(questionId, q => q.Answers))
             .ReturnsAsync(question);

         var expectedType = QuestionType.SingleChoice;

         // Act
         await _questionService.SetQuestionTypeAsync(questionId);

         // Assert
         question.Type.Should().Be(expectedType);
         _unitOfWorkMock.Verify(x => x.Repository<Question>().UpdateAsync(question), Times.Once);
         _unitOfWorkMock.Verify(x => x.SaveAsync(), Times.Once);
      }

      [Test]
      [TestCase("1", "1")]
      [TestCase("2", "5")]
      [TestCase("3", "3")]
      public async Task QuestionService_GetById_ReturnById(string testId, string questionId)
      {
         //Arrange
         var expected = TestData.GetQuestionsDto.Concat(AdditionalQuestionDto).First(x => x.Id == questionId);

         _unitOfWorkMock.Setup(x => x.Repository<Question>().GetAllAsync())
            .ReturnsAsync(TestData.GetQuestions.Concat(AdditionalQuestion).BuildMock());

         //Act
         var actual = await _questionService.GetQuestionByIdAsync(testId, questionId);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase("1", new[] { "1", "4" })]
      [TestCase("2", new[] { "2", "5" })]
      [TestCase("3", new[] { "3" })]
      public async Task QuestionService_GetByTestId_ReturnAllById(string testId,
         IEnumerable<string> expectedQuestionId)
      {
         //Arrange
         var expected = TestData.GetQuestionsDto.Concat(AdditionalQuestionDto)
            .Where(x => expectedQuestionId.Contains(x.Id));

         _unitOfWorkMock.Setup(x => x.Repository<Question>().GetAllAsync())
            .ReturnsAsync(TestData.GetQuestions.Concat(AdditionalQuestion).BuildMock());

         //Act
         var actual = await _questionService.GetQuestionsByTestIdAsync(testId);

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      [Test]
      [TestCase("1", new[] { "1", "4" })]
      [TestCase("2", new[] { "2", "5" })]
      [TestCase("3", new[] { "3" })]
      public async Task QuestionService_IsQuestionsExist_ReturnTrue(string testId, IEnumerable<string> chekedId)
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Question>().GetAllAsync())
            .ReturnsAsync(TestData.GetQuestions.Concat(AdditionalQuestion).BuildMock());

         var models = TestData.QuestionsCreateUpdateDto.Concat(AdditionalQuestionCreateUpdate)
            .Where(x => chekedId.Contains(x.Id));

         //Act
         var actual = await _questionService.IsQuestionsExistAsync(testId, models);

         //Assert
         actual.Should().BeTrue();
      }

      [Test]
      [TestCase("1", new[] { "1", "4" })]
      [TestCase("2", new[] { "2", "5" })]
      [TestCase("3", new[] { "3" })]
      public async Task QuestionService_IsQuestionsExist_ReturnFalse(string testId, IEnumerable<string> chekedId)
      {
         //Arrange
         _unitOfWorkMock.Setup(x => x.Repository<Question>().GetAllAsync())
            .ReturnsAsync(TestData.GetQuestions.BuildMock());

         var models = TestData.QuestionsCreateUpdateDto.Concat(AdditionalQuestionCreateUpdate)
            .Where(x => !chekedId.Contains(x.Id));

         //Act
         var actual = await _questionService.IsQuestionsExistAsync(testId, models);

         //Assert
         actual.Should().BeFalse();
      }

      [Test]
      public async Task QuestionService_CheckUserAnswers_ReturnPoints()
      {
         // Arrange
         var questions = QuestionsForCkeckAnswer;

         _unitOfWorkMock.Setup(x => x.Repository<Question>().GetAllWithIncludeAsync(q => q.Answers))
             .ReturnsAsync(questions.BuildMock());

         var userAnswers = UserAnswersModel;
         var expectedPoints = 23;

         // Act
         var actualPoints = await _questionService.CheckUserAnswersAsync("1", userAnswers);

         // Assert
         actualPoints.Should().Be(expectedPoints);
      }

      private static List<Question> AdditionalQuestion =>
         new()
         {
            new Question{Id = "4", TestId = "1", Points = 10},
            new Question{Id = "5", TestId = "2", Points = 15}
         };

      private static List<QuestionGetDto> AdditionalQuestionDto =>
         new()
         {
            new QuestionGetDto{Id = "4", TestId = "1", Points = 10},
            new QuestionGetDto{Id = "5", TestId = "2", Points = 15}
         };

      private static List<QuestionCreateUpdateDto> AdditionalQuestionCreateUpdate =>
         new()
         {
            new QuestionCreateUpdateDto{Id = "4", TestId = "1", Points = 10},
            new QuestionCreateUpdateDto{Id = "5", TestId = "2", Points = 15}
         };

      private static List<UserAnswerModel> UserAnswersModel => new()
      {
          new UserAnswerModel
          {
              QuestionId = "q1",
              AnswerText = "answer1"
          },
          new UserAnswerModel
          {
              QuestionId = "q2",
              SingleChoiceId = "a3"
          },
          new UserAnswerModel
          {
              QuestionId = "q3",
              MultipleChoice = new List<bool> { true, false, true, true }
          }
      };

      private static List<Question> QuestionsForCkeckAnswer => new()
      {
          new Question
          {
              Id = "q1",
              TestId = "1",
              Type = QuestionType.FreeText,
              Points = 10,
              Answers = new List<Answer>
              {
                  new Answer
                  {
                      Id = "a1",
                      AnswerText = "answer1",
                      QuestionId = "q1",
                      IsCorrect = true
                  }
              }
          },
          new Question
          {
              Id = "q2",
              TestId = "1",
              Type = QuestionType.SingleChoice,
              Points = 5,
              Answers = new List<Answer>
              {
                  new Answer
                  {
                      Id = "a2",
                      AnswerText = "answer2",
                      QuestionId = "q2",
                      IsCorrect = false
                  },
                  new Answer
                  {
                      Id = "a3",
                      AnswerText = "answer3",
                      QuestionId = "q2",
                      IsCorrect = true
                  },
                  new Answer
                  {
                      Id = "a4",
                      AnswerText = "answer4",
                      QuestionId = "q2",
                      IsCorrect = false
                  }
              }
          },
          new Question
          {
              Id = "q3",
              TestId = "1",
              Type = QuestionType.MultipleChoice,
              Points = 8,
              Answers = new List<Answer>
              {
                  new Answer
                  {
                      Id = "a5",
                      AnswerText = "answer5",
                      QuestionId = "q3",
                      IsCorrect = true
                  },
                  new Answer
                  {
                      Id = "a6",
                      AnswerText = "answer6",
                      QuestionId = "q3",
                      IsCorrect = false
                  },
                  new Answer
                  {
                      Id = "a7",
                      AnswerText = "answer7",
                      QuestionId = "q3",
                      IsCorrect = true
                  },
                  new Answer
                  {
                      Id = "a8",
                      AnswerText = "answer8",
                      QuestionId = "q3",
                      IsCorrect = true
                  }
              }
          }
      };
   }
}