﻿using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Services;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using FluentAssertions;
using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using MockQueryable.Moq;
using Moq;

namespace WebAPI.Tests.BusinessTests
{
	[TestFixture]
	public class TestServiceTests
	{
		private ITestService _testService;
		private Mock<IUnitOfWork> _unitOfWorkMock;

		[SetUp]
		public void SetUp()
		{
			_unitOfWorkMock = new();
			_testService = new TestService(_unitOfWorkMock.Object, UnitTestHelper.CreateMapperProfile());
		}

		[Test]
		[TestCase("1")]
		[TestCase("2")]
		[TestCase("3")]
		public async Task TestService_SearchByName_ReturnSearched(string id)
		{
			//Arrange
			var expected = TestData.GetTestsDto.First(x => x.Id == id);

			_unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics))
				.ReturnsAsync(TestData.GetTests.BuildMock());

			//Act
			var actual = await _testService.GetTestsByNameSearchAsync(id);

			//Assert
			actual.Count().Should().Be(1);
			actual.First().Should().BeEquivalentTo(expected);
		}

		[Test]
		[TestCase("1")]
		[TestCase("2")]
		[TestCase("3")]
		public async Task TestService_GetByUserId_ReturnAllById(string userId)
		{
			//Arrange
			var expected = TestData.GetTestsDto.First(x => x.Id == userId);

			_unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics))
				.ReturnsAsync(TestData.GetTests.BuildMock());

			//Act
			var actual = await _testService.GetTestsByUserIdAsync(userId);

			//Assert
			actual.Count().Should().Be(1);
			actual.First().Should().BeEquivalentTo(expected);
		}

		[Test]
		public async Task TestService_GetAllWithIncludes_ReturnAll()
		{
			//Arrange
			var expected = TestData.GetTestsDto;

			_unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics))
				.ReturnsAsync(TestData.GetTests.BuildMock());

			//Act
			var actual = await _testService.GetAllTestsWithIncludeAsync();

			//Assert
			actual.Count().Should().Be(3);
			actual.Should().BeEquivalentTo(expected);
		}


		[Test]
		[TestCase("1")]
		[TestCase("2")]
		[TestCase("3")]
		public async Task TestService_GetByIdWithIncludes_ReturnById(string id)
		{
			//Arrange
			var expected = TestData.GetTestsDto.First(x => x.Id == id);

			_unitOfWorkMock.Setup(x => x.Repository<Test>().GetByIdWithIncludeAsync(id, t => t.Questions,
				t => t.TestStatistics))
				.ReturnsAsync(TestData.GetTests.First(x => x.Id == id));

			//Act
			var actual = await _testService.GetTestByIdWithIncludeAsync(id);

			//Assert
			actual.Should().BeEquivalentTo(expected);
		}

		[TestCase("name1", "1")]
		[TestCase("name2", "2")]
		[TestCase("name3", "3")]
		public async Task TestService_GetTestsByFilter_ReturnsByUserName(string userName, string expectedId)
		{
			//Arrange
			var expected = TestData.GetTestsDto.Where(x => x.Id == expectedId);
			var filter = new FilterSearchTestModel { UserName = userName };

			_unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics, t => t.User))
				.ReturnsAsync(TestData.GetTests.BuildMock());

			//Act
			var actual = await _testService.GetTestsByFilterAsync(filter);

			//Assert
			actual.Should().BeEquivalentTo(expected);
		}

		[TestCase(5, 10, new[] { "1", "2" })]
		[TestCase(1, 7, new[] { "1" })]
		[TestCase(0, 20, new[] { "1", "2", "3" })]
		public async Task TestService_GetTestsByFilter_ReturnsByExecutionTime(int minExecutionTime,
			int maxExecutionTime, IEnumerable<string> expectedId)
		{
			//Arrange
			var expected = TestData.GetTestsDto.Where(x => expectedId.Contains(x.Id));
			var filter = new FilterSearchTestModel
			{
				MinExecutionTime = minExecutionTime,
				MaxExecutionTime = maxExecutionTime
			};

			_unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics, t => t.User))
				.ReturnsAsync(TestData.GetTests.BuildMock());

			//Act
			var actual = await _testService.GetTestsByFilterAsync(filter);

			//Assert
			actual.Should().BeEquivalentTo(expected);
		}

		[TestCase(5, 15, new[] { "1" })]
		[TestCase(6, 70, new[] { "1", "2", "3" })]
		[TestCase(25, 49, new[] { "2", "3" })]
		public async Task TestService_GetTestsByFilter_ReturnsByPassScore(int minPassScore,
			int maxPassScore, IEnumerable<string> expectedId)
		{
			//Arrange
			var expected = TestData.GetTestsDto.Where(x => expectedId.Contains(x.Id));
			var filter = new FilterSearchTestModel
			{
				MinPassScore = minPassScore,
				MaxPassScore = maxPassScore
			};

			_unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics, t => t.User))
				.ReturnsAsync(TestData.GetTests.BuildMock());

			//Act
			var actual = await _testService.GetTestsByFilterAsync(filter);

			//Assert
			actual.Should().BeEquivalentTo(expected);
		}

		[TestCase("name1", 1, null, 5, null, new[] { "1" })]
		[TestCase(null, null, 15, null, 30, new[] { "1", "2" })]
		[TestCase(null, 7, null, null, 43, new[] { "2" })]
		[TestCase("name3", null, 25, 25, null, new[] { "3" })]
		[TestCase(null, 4, 8, 3, 18, new[] { "1" })]
		public async Task TestService_GetTestsByFilter_ReturnsByFilter(string userName, int? minExecutionTime,
			int? maxExecutionTime, int? minPassScore, int? maxPassScore, IEnumerable<string> expectedId)
		{
			//Arrange
			var expected = TestData.GetTestsDto.Where(x => expectedId.Contains(x.Id));
			var filter = new FilterSearchTestModel
			{
				UserName = userName,
				MinExecutionTime = minExecutionTime,
				MaxExecutionTime = maxExecutionTime,
				MinPassScore = minPassScore,
				MaxPassScore = maxPassScore
			};

			_unitOfWorkMock.Setup(x => x.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics, t => t.User))
				.ReturnsAsync(TestData.GetTests.BuildMock());

			//Act
			var actual = await _testService.GetTestsByFilterAsync(filter);

			//Assert
			actual.Should().BeEquivalentTo(expected);
		}
	}
}
