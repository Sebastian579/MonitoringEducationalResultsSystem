﻿using BusinessLogicLayer.Dtos.User;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Services;
using DataAccessLayer.Entities;
using FluentAssertions;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using MockQueryable.Moq;
using Moq;

namespace WebAPI.Tests.BusinessTests
{
	[TestFixture]
	public class UserServiceTests
	{
		private Mock<IUserStore<User>> _userStoreMock;
		private Mock<UserManager<User>> _userManagerMock;
		private Mock<IRoleStore<IdentityRole>> _roleStoreMock;
		private Mock<RoleManager<IdentityRole>> _roleManagerMock;
		private Mock<IConfiguration> _configurationMock;
		private IUserService _userService;

		[SetUp]
		public void SetUp()
		{
			_userStoreMock = new();
			_roleStoreMock = new();
			_roleManagerMock = new(_roleStoreMock.Object, null, null, null, null);
			_configurationMock = new();

			_userManagerMock = new(_userStoreMock.Object, null, null, null, null, null, null, null, null);
			_userService = new UserService(_userManagerMock.Object, UnitTestHelper.CreateMapperProfile(),
				_configurationMock.Object, _roleManagerMock.Object);
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserService_DeleteUser_ReturnTrue(string userName)
		{
			//Arrange
			var user = TestData.GetUser.First(x => x.UserName == userName);

			_userManagerMock.Setup(x => x.DeleteAsync(It.IsAny<User>()));
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()))
				.ReturnsAsync(user);

			//Act
			var result = await _userService.DeleteUserAsync(userName);

			//Assert
			_userManagerMock.Verify(x => x.DeleteAsync(It.Is<User>(y => y.Id == user.Id)), Times.Once);
			result.Should().BeTrue();
		}

		[Test]
		public async Task UserService_DeleteUser_ReturnFalse()
		{
			//Arrange
			_userManagerMock.Setup(x => x.DeleteAsync(It.IsAny<User>()));
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()));

			//Act
			var result = await _userService.DeleteUserAsync("name1");

			//Assert
			_userManagerMock.Verify(x => x.DeleteAsync(It.IsAny<User>()), Times.Never);
			result.Should().BeFalse();
		}

		[Test]
		public async Task UserService_GetUsers_ReturnAll()
		{
			//Arrange
			var expected = TestData.UserGetDtos;

			_userManagerMock.Setup(x => x.Users).Returns(TestData.GetUser.BuildMock());
			_userManagerMock.Setup(x => x.GetRolesAsync(It.IsAny<User>()));

			//Act
			var actual = await _userService.GetUsersAsync();

			//Assert
			actual.Should().BeEquivalentTo(expected);
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserService_GetUsers_ReturnByName(string userName)
		{
			//Arrange
			var expected = TestData.UserGetDtos.First(x => x.UserName == userName);

			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()))
				.ReturnsAsync(TestData.GetUser.First(x => x.UserName == userName));

			_userManagerMock.Setup(x => x.GetRolesAsync(It.IsAny<User>()));

			//Act
			var actual = await _userService.GetUserAsync(userName);

			//Assert
			actual.Should().BeEquivalentTo(expected);
		}

		[Test]
		public async Task UserService_GetUsers_ReturnNull()
		{
			//Arrange
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()));

			_userManagerMock.Setup(x => x.GetRolesAsync(It.IsAny<User>()));

			//Act
			var actual = await _userService.GetUserAsync("name1");

			//Assert
			actual.Should().BeNull();
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserService_UpdateUser_UpdateSuccess(string userName)
		{
			//Arrange
			_userManagerMock.Setup(x => x.UpdateAsync(It.IsAny<User>()))
				.ReturnsAsync(IdentityResult.Success);

			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()))
				.ReturnsAsync(TestData.GetUser.First(x => x.UserName == userName));

			var model = TestData.UserUpdateDtos.First(x => x.UserName == userName);

			//Act
			var result = await _userService.UpdateUserAsync(model);

			//Assert
			_userManagerMock.Verify(x => x.UpdateAsync(It.Is<User>(y => y.FirstName == model.FirstName
				&& y.LastName == model.LastName && y.Email == model.Email)), Times.Once);
			result.Succeeded.Should().BeTrue();
		}

		[Test]
		[TestCase("name1", "role1")]
		[TestCase("name2", "role2")]
		[TestCase("name3", "role3")]
		public async Task UserService_AddRoleToUser_ReturnTrue(string userName, string roleName)
		{
			//Arrange
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()))
				.ReturnsAsync(TestData.GetUser.First(x => x.UserName == userName));

			_roleManagerMock.Setup(x => x.RoleExistsAsync(It.IsAny<string>()))
				.ReturnsAsync(true);

			_userManagerMock.Setup(x => x.AddToRoleAsync(It.IsAny<User>(), It.IsAny<string>()));

			//Act
			var result = await _userService.AddRoleToUserAsync(userName, roleName);

			//Assert
			_userManagerMock.Verify(x => x.AddToRoleAsync(It.Is<User>(y => y.UserName == userName),
				It.Is<string>(s => s == roleName)), Times.Once);
			result.Should().BeTrue();
		}

		[Test]
		[TestCase(true)]
		[TestCase(false)]
		public async Task UserService_AddRoleToUser_ReturnFalse(bool isRoleExist)
		{
			//Arrange
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()));

			_roleManagerMock.Setup(x => x.RoleExistsAsync(It.IsAny<string>()))
				.ReturnsAsync(isRoleExist);

			//Act
			var result = await _userService.AddRoleToUserAsync("name1", "role1");

			//Assert
			_userManagerMock.Verify(x => x.AddToRoleAsync(It.IsAny<User>(), It.IsAny<string>()), Times.Never);
			result.Should().BeFalse();
		}

		[Test]
		[TestCase("name1", "role1")]
		[TestCase("name2", "role2")]
		[TestCase("name3", "role3")]
		public async Task UserService_RemoveRoleFromUser_ReturnTrue(string userName, string roleName)
		{
			//Arrange
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()))
				.ReturnsAsync(TestData.GetUser.First(x => x.UserName == userName));

			_roleManagerMock.Setup(x => x.RoleExistsAsync(It.IsAny<string>()))
				.ReturnsAsync(true);

			_userManagerMock.Setup(x => x.RemoveFromRoleAsync(It.IsAny<User>(), It.IsAny<string>()));

			//Act
			var result = await _userService.RemoveRoleFromUserAsync(userName, roleName);

			//Assert
			_userManagerMock.Verify(x => x.RemoveFromRoleAsync(It.Is<User>(y => y.UserName == userName),
				It.Is<string>(s => s == roleName)), Times.Once);
			result.Should().BeTrue();
		}

		[Test]
		[TestCase(true)]
		[TestCase(false)]
		public async Task UserService_RemoveRoleFromUser_ReturnFalse(bool isRoleExist)
		{
			//Arrange
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()));

			_roleManagerMock.Setup(x => x.RoleExistsAsync(It.IsAny<string>()))
				.ReturnsAsync(isRoleExist);

			//Act
			var result = await _userService.RemoveRoleFromUserAsync("name1", "role1");

			//Assert
			_userManagerMock.Verify(x => x.RemoveFromRoleAsync(It.IsAny<User>(),
				It.IsAny<string>()), Times.Never);
			result.Should().BeFalse();
		}

		[Test]
		[TestCase("name1")]
		[TestCase("name2")]
		[TestCase("name3")]
		public async Task UserService_ValidateUser_ReturnTrue(string userName)
		{
			//Arrange
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()))
				.ReturnsAsync(TestData.GetUser.First(x => x.UserName == userName));

			_userManagerMock.Setup(x => x.CheckPasswordAsync(It.IsAny<User>(), It.IsAny<string>()))
				.ReturnsAsync(true);


			var model = TestData.UserLoginDtos.First(x => x.UserName == userName);

			//Act
			var result = await _userService.ValidateUserAsync(model);

			//Assert
			_userManagerMock.Verify(x => x.CheckPasswordAsync(It.Is<User>(y =>
			y.UserName == userName), It.Is<string>(s => s == model.Password)), Times.Once);
			result.Should().BeTrue();
		}

		[Test]
		public async Task UserService_ValidateUser_ReturnFalse()
		{
			//Arrange
			_userManagerMock.Setup(x => x.FindByNameAsync(It.IsAny<string>()));

			var model = TestData.UserLoginDtos.First();

			//Act
			var result = await _userService.ValidateUserAsync(model);

			//Assert
			_userManagerMock.Verify(x => x.CheckPasswordAsync(It.IsAny<User>(), It.IsAny<string>()),
				Times.Never);
			result.Should().BeFalse();
		}

		[Test]
		[TestCase("name1", "role1")]
		[TestCase("name2", "role2")]
		[TestCase("name3", "role3")]
		public async Task UserService_RegisterWithRole_ReturnSuccess(string userName, string roleName)
		{
			//Arrange
			_userManagerMock.Setup(x => x.CreateAsync(It.IsAny<User>(), It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Success);

			_roleManagerMock.Setup(x => x.RoleExistsAsync(It.IsAny<string>()))
				.ReturnsAsync(true);

			_userManagerMock.Setup(x => x.AddToRoleAsync(It.IsAny<User>(), It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Success);

			var model = TestData.UserRegistrationDtos.First(x => x.UserName == userName);

			//Act
			var result = await _userService.RegisterWithRoleAsync(model, roleName);

			//Assert
			_userManagerMock.Verify(x => x.CreateAsync(It.Is<User>(y =>
			y.UserName == userName), It.Is<string>(s => s == model.Password)), Times.Once);

			_userManagerMock.Verify(x => x.AddToRoleAsync(It.Is<User>(y => y.UserName == userName),
				It.Is<string>(s => s == roleName)), Times.Once);
			result.Succeeded.Should().BeTrue();
		}

		[Test]
		[TestCase(true)]
		[TestCase(false)]
		public async Task UserService_RegisterWithRole_ReturnFailed(bool isRoleExist)
		{
			//Arrange
			_userManagerMock.Setup(x => x.CreateAsync(It.IsAny<User>(), It.IsAny<string>()))
				.ReturnsAsync(IdentityResult.Failed());

			_roleManagerMock.Setup(x => x.RoleExistsAsync(It.IsAny<string>()))
				.ReturnsAsync(isRoleExist);

			var model = TestData.UserRegistrationDtos.First();

			//Act
			var result = await _userService.RegisterWithRoleAsync(model);

			//Assert
			_userManagerMock.Verify(x => x.CreateAsync(It.Is<User>(y =>
			y.UserName == model.UserName), It.Is<string>(s => s == model.Password)), Times.Once);

			_userManagerMock.Verify(x => x.AddToRoleAsync(It.IsAny<User>(), It.IsAny<string>()), Times.Never);
			result.Succeeded.Should().BeFalse();
		}
	}
}
