﻿using AutoMapper;
using BusinessLogicLayer.Mappings;
using DataAccessLayer.Data;
using Microsoft.EntityFrameworkCore;

namespace WebAPI.Tests
{
	internal static class UnitTestHelper
	{
		public static IMapper CreateMapperProfile()
		{
			var configuration = new MapperConfiguration(map =>
			{
				map.AddProfile<UserMappingProfile>();
				map.AddProfile<TestMappingProfile>();
				map.AddProfile<QuestionMappingProfile>();
				map.AddProfile<AnswerMappingProfile>();
				map.AddProfile<TestStatisticsMappingProfile>();
				map.AddProfile<UserStatisticsMappingProfile>();
			});

			return configuration.CreateMapper();
		}

		public static DbContextOptions<TestingSystemContext> GetUnitTestDbOptions()
		{
			var options = new DbContextOptionsBuilder<TestingSystemContext>()
				.UseInMemoryDatabase(Guid.NewGuid().ToString())
				.Options;

			using (var context = new TestingSystemContext(options))
			{
				SeedData(context);
			}

			return options;
		}

		public static void SeedData(TestingSystemContext db)
		{
			db.Tests.AddRange(TestData.GetTestsWithoutInclude);
			db.Questions.AddRange(TestData.GetQuestions);
			db.Answers.AddRange(TestData.GetAnswers);
			db.TestStatistics.AddRange(TestData.GetTestStatistics);
			db.UserStatistics.AddRange(TestData.GetUserStatisticsWithoutInclude);
			db.Users.AddRange(TestData.GetUser);
			db.SaveChanges();
		}
	}
}