﻿using BusinessLogicLayer.Dtos.Answers;
using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Dtos.TestStatistics;
using BusinessLogicLayer.Dtos.User;
using BusinessLogicLayer.Dtos.UserStatistics;
using DataAccessLayer.Entities;
using Microsoft.AspNetCore.Identity;

namespace WebAPI.Tests
{
   public static class TestData
   {
      public static List<TestGetDto> GetTestsDto =>
         new()
         {
            new TestGetDto { Id = "1", Name = "test1", UserId = "1", ExecutionTime = 5,
               PassPercentage = 100, QuestionCount = 1, PassScore = 15,
               CreationDate = new DateTime(2014, 5, 20)},
            new TestGetDto { Id = "2", Name = "test2", UserId = "2", ExecutionTime = 10,
               PassPercentage = 60, QuestionCount = 1, PassScore = 30,
               CreationDate = new DateTime(2012, 5, 20),},
            new TestGetDto { Id = "3", Name = "test3", UserId = "3", ExecutionTime = 15,
               PassPercentage = 50, QuestionCount = 1, PassScore = 45,
               CreationDate = new DateTime(2010, 5, 20)}
         };

      public static List<QuestionGetDto> GetQuestionsDto =>
         new()
         {
            new QuestionGetDto {Id = "1", TestId = "1", QuestionText = "question1", Points = 1},
            new QuestionGetDto {Id = "2", TestId = "2", QuestionText = "question2", Points = 3},
            new QuestionGetDto {Id = "3", TestId = "3", QuestionText = "question3", Points = 5}
         };

      public static List<AnswerGetDto> GetAnswersDto =>
         new()
         {
            new AnswerGetDto {Id = "1", QuestionId = "1", AnswerText = "answer1", IsCorrect = true},
            new AnswerGetDto {Id = "2", QuestionId = "2", AnswerText = "answer2", IsCorrect = false},
            new AnswerGetDto {Id = "3", QuestionId = "3", AnswerText = "answer3", IsCorrect = true}
         };

      public static List<TestStatisticsGetDto> GetTestStatisticsDto =>
         new()
         {
            new TestStatisticsGetDto {Id = "1", AttemptCount = 1, PassCount = 1, TestId = "1"},
            new TestStatisticsGetDto {Id = "2", AttemptCount = 5, PassCount = 3, TestId = "2"},
            new TestStatisticsGetDto {Id = "3", AttemptCount = 10, PassCount = 5, TestId = "3"}
         };

      public static List<UserStatisticsGetDto> GetUserStatisticsDto =>
         new()
         {
            new UserStatisticsGetDto {Id = "1", AttemptCount = 1, PassCount = 1, UserId = "1"},
            new UserStatisticsGetDto {Id = "2", AttemptCount = 5, PassCount = 3, UserId = "2"},
            new UserStatisticsGetDto {Id = "3", AttemptCount = 10, PassCount = 5, UserId = "3"}
         };

      public static List<TestCreateUpdateDto> TestsCreateUpdateDto =>
         new()
         {
            new TestCreateUpdateDto { Id = "4", Name = "test4", UserId = "1", ExecutionTime = 15},
            new TestCreateUpdateDto { Id = "5", Name = "test5", UserId = "2", ExecutionTime = 20},
            new TestCreateUpdateDto { Id = "6", Name = "test6", UserId = "3", ExecutionTime = 25}
         };

      public static List<QuestionCreateUpdateDto> QuestionsCreateUpdateDto =>
         new()
         {
            new QuestionCreateUpdateDto {Id = "4", TestId = "1", QuestionText = "question4"},
            new QuestionCreateUpdateDto {Id = "5", TestId = "2", QuestionText = "question5"},
            new QuestionCreateUpdateDto {Id = "6", TestId = "3", QuestionText = "question6"}
         };

      public static List<AnswerCreateUpdateDto> AnswersCreateUpdateDto =>
         new()
         {
            new AnswerCreateUpdateDto {Id = "4", QuestionId = "1", AnswerText = "answer4", IsCorrect = false},
            new AnswerCreateUpdateDto {Id = "5", QuestionId = "2", AnswerText = "answer5", IsCorrect = true},
            new AnswerCreateUpdateDto {Id = "6", QuestionId = "3", AnswerText = "answer6", IsCorrect = false}
         };

      public static List<TestStatisticsCreateUpdateDto> TestStatisticsCreateUpdateDto =>
         new()
         {
            new TestStatisticsCreateUpdateDto {Id = "4", AttemptCount = 10, PassCount = 10, TestId = "1"},
            new TestStatisticsCreateUpdateDto {Id = "5", AttemptCount = 50, PassCount = 30, TestId = "2"},
            new TestStatisticsCreateUpdateDto {Id = "6", AttemptCount = 100, PassCount = 50, TestId = "3"}
         };

      public static List<UserStatisticsCreateUpdateDto> UserStatisticsCreateUpdateDto =>
         new()
         {
            new UserStatisticsCreateUpdateDto {Id = "4", AttemptCount = 10, PassCount = 10, UserId = "1"},
            new UserStatisticsCreateUpdateDto {Id = "5", AttemptCount = 50, PassCount = 30, UserId = "2"},
            new UserStatisticsCreateUpdateDto {Id = "6", AttemptCount = 100, PassCount = 50, UserId = "3"}
         };

      public static List<Test> GetTests =>
         new()
         {
            new Test {Id = "1", Name = "test1", UserId = "1", ExecutionTime = 5,PassScore = 15,
               CreationDate = new DateTime(2014, 5, 20),
               Questions = GetQuestions.Where(x => x.TestId == "1").ToList(),
               TestStatistics = GetTestStatistics.First(x => x.TestId == "1"),
               User = GetUser.First(x => x.Id == "1")},
            new Test {Id = "2", Name = "test2", UserId = "2", ExecutionTime = 10,PassScore = 30,
               CreationDate = new DateTime(2012, 5, 20),
               Questions = GetQuestions.Where(x => x.TestId == "2").ToList(),
               TestStatistics = GetTestStatistics.First(x => x.TestId == "2"),
               User = GetUser.First(x => x.Id == "2")},
            new Test {Id = "3", Name = "test3", UserId = "3", ExecutionTime = 15,PassScore = 45,
               CreationDate = new DateTime(2010, 5, 20),
               Questions = GetQuestions.Where(x => x.TestId == "3").ToList(),
               TestStatistics = GetTestStatistics.First(x => x.TestId == "3"),
               User = GetUser.First(x => x.Id == "3")}
         };

      public static List<User> GetUser =>
         new()
         {
            new User{Id = "1", UserName = "name1", FirstName = "firsname1", LastName = "lastname1",
               Email = "email1"},
            new User{Id = "2", UserName = "name2", FirstName = "firsname2", LastName = "lastname2",
               Email = "email2"},
            new User{Id = "3", UserName = "name3", FirstName = "firsname3", LastName = "lastname3",
               Email = "email3"}
         };

      public static List<UserGetDto> UserGetDtos =>
         new()
         {
            new UserGetDto{Id = "1", UserName = "name1", FirstName = "firsname1", LastName = "lastname1",
               Email = "email1"},
            new UserGetDto{Id = "2", UserName = "name2", FirstName = "firsname2", LastName = "lastname2",
               Email = "email2"},
            new UserGetDto{Id = "3", UserName = "name3", FirstName = "firsname3", LastName = "lastname3",
               Email = "email3"}
         };

      public static List<UserLoginDto> UserLoginDtos =>
         new()
         {
            new UserLoginDto{UserName = "name1", Password = "password1"},
            new UserLoginDto{UserName = "name2", Password = "password2"},
            new UserLoginDto{UserName = "name3", Password = "password3"}
         };

      public static List<UserRegistrationDto> UserRegistrationDtos =>
         new()
         {
            new UserRegistrationDto{UserName = "name1", Password = "password1", Email = "email1"},
            new UserRegistrationDto{UserName = "name2", Password = "password2", Email = "email2"},
            new UserRegistrationDto{UserName = "name3", Password = "password3", Email = "email3"}
         };

      public static List<UserUpdateDto> UserUpdateDtos =>
         new()
         {
            new UserUpdateDto() {Id = "1", UserName = "name1", FirstName = "1", LastName = "1", Email = "1"},
            new UserUpdateDto() {Id = "2", UserName = "name2", FirstName = "2", LastName = "2", Email = "2"},
            new UserUpdateDto() {Id = "3", UserName = "name3", FirstName = "3", LastName = "3", Email = "3"},
         };

      public static List<IdentityRole> GetRoles =>
         new()
         {
            new IdentityRole{Id = "1", Name = "role1", ConcurrencyStamp = "1"},
            new IdentityRole{Id = "2", Name = "role2", ConcurrencyStamp = "2"},
            new IdentityRole{Id = "3", Name = "role3", ConcurrencyStamp = "3"}
         };

      public static List<Question> GetQuestions =>
         new()
         {
            new Question {Id = "1", TestId = "1", QuestionText = "question1", Points = 1},
            new Question {Id = "2", TestId = "2", QuestionText = "question2", Points = 3},
            new Question {Id = "3", TestId = "3", QuestionText = "question3", Points = 5}
         };

      public static List<Answer> GetAnswers =>
         new()
         {
            new Answer {Id = "1", QuestionId = "1", AnswerText = "answer1", IsCorrect = true},
            new Answer {Id = "2", QuestionId = "2", AnswerText = "answer2", IsCorrect = false},
            new Answer {Id = "3", QuestionId = "3", AnswerText = "answer3", IsCorrect =true}
         };

      public static List<TestStatistics> GetTestStatistics =>
         new()
         {
            new TestStatistics {Id = "1", AttemptCount = 1, PassCount = 1, TestId = "1"},
            new TestStatistics {Id = "2", AttemptCount = 5, PassCount = 3, TestId = "2"},
            new TestStatistics {Id = "3", AttemptCount = 10, PassCount = 5, TestId = "3"}
         };

      public static List<UserStatistics> GetUserStatistics =>
         new()
         {
            new UserStatistics {Id = "1", AttemptCount = 1, PassCount = 1, UserId = "1",
               User = GetUser.First(x => x.Id == "3")},
            new UserStatistics {Id = "2", AttemptCount = 5, PassCount = 3, UserId = "2",
               User = GetUser.First(x => x.Id == "2")},
            new UserStatistics {Id = "3", AttemptCount = 10, PassCount = 5, UserId = "3",
               User = GetUser.First(x => x.Id == "1")}
         };

      public static List<UserStatistics> GetUserStatisticsWithoutInclude =>
         new()
         {
            new UserStatistics {Id = "1", AttemptCount = 1, PassCount = 1, UserId = "1"},
            new UserStatistics {Id = "2", AttemptCount = 5, PassCount = 3, UserId = "2"},
            new UserStatistics {Id = "3", AttemptCount = 10, PassCount = 5, UserId = "3"}
         };

      public static List<Test> GetTestsWithoutInclude =>
         new()
         {
            new Test {Id = "1", Name = "test1", UserId = "1", ExecutionTime = 5,
            CreationDate = new DateTime(2014, 5, 20)},
            new Test {Id = "2", Name = "test2", UserId = "2", ExecutionTime = 10,
            CreationDate = new DateTime(2012, 5, 20)},
            new Test {Id = "3", Name = "test3", UserId = "3", ExecutionTime = 15,
            CreationDate = new DateTime(2010, 5, 20)}
         };

      public static List<Question> GetQuestionsUpdate =>
         new()
         {
            new Question {Id = "1", TestId = "1", QuestionText = "question4"},
            new Question {Id = "2", TestId = "2", QuestionText = "question5"},
            new Question {Id = "3", TestId = "3", QuestionText = "question6"}
         };

      public static List<Answer> GetAnswersUpdate =>
         new()
         {
            new Answer {Id = "1", QuestionId = "1", AnswerText = "answer4", IsCorrect = false},
            new Answer {Id = "2", QuestionId = "2", AnswerText = "answer5", IsCorrect = true},
            new Answer {Id = "3", QuestionId = "3", AnswerText = "answer6", IsCorrect = false}
         };

      public static List<TestStatistics> GetTestStatisticsUpdate =>
         new()
         {
            new TestStatistics {Id = "1", AttemptCount = 10, PassCount = 10, TestId = "1"},
            new TestStatistics {Id = "2", AttemptCount = 50, PassCount = 30, TestId = "2"},
            new TestStatistics {Id = "3", AttemptCount = 100, PassCount = 50, TestId = "3"}
         };

      public static List<UserStatistics> GetUserStatisticsUpdate =>
         new()
         {
            new UserStatistics {Id = "1", AttemptCount = 10, PassCount = 10, UserId = "1"},
            new UserStatistics {Id = "2", AttemptCount = 50, PassCount = 30, UserId = "2"},
            new UserStatistics {Id = "3", AttemptCount = 100, PassCount = 50, UserId = "3"}
         };

      public static List<Test> GetTestsUpdateWithoutInclude =>
         new()
         {
            new Test {Id = "1", Name = "test1", UserId = "1", ExecutionTime = 50,
            CreationDate = new DateTime(2013, 3, 5)},
            new Test {Id = "2", Name = "test2", UserId = "2", ExecutionTime = 100,
            CreationDate = new DateTime(2011, 7, 15)},
            new Test {Id = "3", Name = "test3", UserId = "3", ExecutionTime = 150,
            CreationDate = new DateTime(209, 10, 25)}
         };
   }
}