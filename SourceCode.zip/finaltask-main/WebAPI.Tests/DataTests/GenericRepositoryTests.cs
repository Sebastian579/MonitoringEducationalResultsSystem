﻿using DataAccessLayer.Entities;
using WebAPI.Tests.DataTests.Additional;

namespace WebAPI.Tests.DataTests
{
   [TestFixture]
   public class GenericRepositoryTests
   {
      private static IEnumerable<IGenericRepositoryTest> TestCases()
      {
         yield return new GenericRepositoryTest<Test>();
         yield return new GenericRepositoryTest<Question>();
         yield return new GenericRepositoryTest<Answer>();
         yield return new GenericRepositoryTest<TestStatistics>();
         yield return new GenericRepositoryTest<UserStatistics>();
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task GenericRepository_GetAll_ReturnAll(IGenericRepositoryTest genericRepository)
      {
         await genericRepository.TestGetAllAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task GenericRepository_GetById_ReturnEntity(IGenericRepositoryTest genericRepository)
      {
         await genericRepository.TestGetByIdAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task GenericRepository_CreateAsync_AddEntity(IGenericRepositoryTest genericRepository)
      {
         await genericRepository.TestCreateAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task GenericRepository_CreateRangeAsync_AddEntities(IGenericRepositoryTest genericRepository)
      {
         await genericRepository.TestCreateRangeAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task GenericRepository_UpdateAsync_UpdateEntity(IGenericRepositoryTest genericRepository)
      {
         await genericRepository.TestUpdateAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task GenericRepository_UpdateRangeAsync_UpdateEntities(IGenericRepositoryTest genericRepository)
      {
         await genericRepository.TestUpdateRangeAsync();

         Assert.That(true);
      }

      [Test]
      [TestCaseSource(nameof(TestCases))]
      public async Task GenericRepository_DeleteAsync_DeleteEntity(IGenericRepositoryTest genericRepository)
      {
         await genericRepository.TestDeleteAsync();

         Assert.That(true);
      }
   }
}
