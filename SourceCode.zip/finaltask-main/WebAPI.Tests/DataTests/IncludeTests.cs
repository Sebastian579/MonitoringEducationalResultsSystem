﻿using DataAccessLayer.Data;
using DataAccessLayer.Entities;
using DataAccessLayer.Repository;
using FluentAssertions;

namespace WebAPI.Tests.DataTests
{
	// TODO Make Tests
	[TestFixture]
	public class IncludeTests
	{
		[Test]
		public async Task GenericRepository_GetAllWithIncludes_ReturnTestsWithInclude()
		{
			//Arrange
			using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

			var genericRepository = new GenericRepository<Test>(db);

			//Act
			var actual = await genericRepository.GetAllWithIncludeAsync(x => x.Questions, y => y.TestStatistics);

			//Assert
			actual.First().Questions.Should().HaveCount(1);
			actual.First().TestStatistics.Should().NotBeNull();
		}

		[Test]
		public async Task GenericRepository_GetByIdWithIncludes_ReturnTestWithInclude()
		{
			//Arrange
			using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

			var genericRepository = new GenericRepository<Test>(db);

			//Act
			var actual = await genericRepository.GetByIdWithIncludeAsync("1",
				x => x.Questions, y => y.TestStatistics);

			//Assert
			actual.Questions.Should().HaveCount(1);
			actual.TestStatistics.Should().NotBeNull();
		}

		[Test]
		public async Task GenericRepository_GetAllWithIncludes_ReturnQuestionsWithInclude()
		{
			//Arrange
			using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

			var genericRepository = new GenericRepository<Question>(db);

			//Act
			var actual = await genericRepository.GetAllWithIncludeAsync(x => x.Test);

			//Assert
			actual.First().Test.Should().NotBeNull();
		}

		[Test]
		public async Task GenericRepository_GetByIdWithIncludes_ReturnQuestionWithInclude()
		{
			//Arrange
			using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

			var genericRepository = new GenericRepository<Question>(db);

			//Act
			var actual = await genericRepository.GetByIdWithIncludeAsync("1", x => x.Test);

			//Assert
			actual.Test.Should().NotBeNull();
		}

      [Test]
      public async Task GenericRepository_GetAllWithIncludes_ReturnAnswersWithInclude()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         var genericRepository = new GenericRepository<Answer>(db);

         //Act
         var actual = await genericRepository.GetAllWithIncludeAsync(x => x.Question);

         //Assert
         actual.First().Question.Should().NotBeNull();
      }

      [Test]
      public async Task GenericRepository_GetByIdWithIncludes_ReturnAnswerWithInclude()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         var genericRepository = new GenericRepository<Answer>(db);

         //Act
         var actual = await genericRepository.GetByIdWithIncludeAsync("1", x => x.Question);

         //Assert
         actual.Question.Should().NotBeNull();
      }

      [Test]
		public async Task GenericRepository_GetAllWithIncludes_ReturnTestStatisticsWithInclude()
		{
			//Arrange
			using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

			var genericRepository = new GenericRepository<TestStatistics>(db);

			//Act
			var actual = await genericRepository.GetAllWithIncludeAsync(x => x.Test);

			//Assert
			actual.First().Test.Should().NotBeNull();
		}

		[Test]
		public async Task GenericRepository_GetByIdWithIncludes_ReturnTestStatisticWithInclude()
		{
			//Arrange
			using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

			var genericRepository = new GenericRepository<TestStatistics>(db);

			//Act
			var actual = await genericRepository.GetByIdWithIncludeAsync("1", x => x.Test);

			//Assert
			actual.Test.Should().NotBeNull();
		}

      [Test]
      public async Task GenericRepository_GetAllWithIncludes_ReturnUserStatisticsWithInclude()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         var genericRepository = new GenericRepository<UserStatistics>(db);

         //Act
         var actual = await genericRepository.GetAllWithIncludeAsync(x => x.User);

         //Assert
         actual.First().User.Should().NotBeNull();
      }

      [Test]
      public async Task GenericRepository_GetByIdWithIncludes_ReturnUserStatisticWithInclude()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         var genericRepository = new GenericRepository<UserStatistics>(db);

         //Act
         var actual = await genericRepository.GetByIdWithIncludeAsync("1", x => x.User);

         //Assert
         actual.User.Should().NotBeNull();
      }
   }
}