﻿namespace WebAPI.Tests.DataTests.Additional
{
	public interface IGenericRepositoryTest
	{
		Task TestGetAllAsync();

		Task TestGetByIdAsync();

		Task TestCreateAsync();

		Task TestCreateRangeAsync();

		Task TestUpdateAsync();

		Task TestUpdateRangeAsync();

		Task TestDeleteAsync();
	}
}
