﻿using DataAccessLayer.Data;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using DataAccessLayer.Repository;
using FluentAssertions;

namespace WebAPI.Tests.DataTests.Additional
{
   public class GenericRepositoryTest<TEntity> : IGenericRepositoryTest where TEntity : BaseEntity
   {
      private IRepository<TEntity> _genericRepository;

      public async Task TestCreateAsync()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         _genericRepository = new GenericRepository<TEntity>(db);

         var entity = GetEntities().First();
         entity.Id = "4";

         //Act
         await _genericRepository.CreateAsync(entity);
         await db.SaveChangesAsync();

         //Assert
         db.Set<TEntity>().Count().Should().Be(4);
      }

      public async Task TestCreateRangeAsync()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         _genericRepository = new GenericRepository<TEntity>(db);

         var entities = GetEntities();
         entities[0].Id = "4";
         entities[1].Id = "5";
         entities[2].Id = "6";

         //Act
         await _genericRepository.CreateRangeAsync(entities);
         await db.SaveChangesAsync();

         //Assert
         db.Set<TEntity>().Count().Should().Be(6);
      }

      public async Task TestDeleteAsync()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         _genericRepository = new GenericRepository<TEntity>(db);

         var entity = GetEntities().First();

         //Act
         await _genericRepository.DeleteAsync(entity);
         await db.SaveChangesAsync();

         //Assert
         db.Set<TEntity>().Count().Should().Be(2);
      }

      public async Task TestGetAllAsync()
      {
         //Arrange
         var expected = GetEntities();

         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         _genericRepository = new GenericRepository<TEntity>(db);

         //Act
         var actual = await _genericRepository.GetAllAsync();

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      public async Task TestGetByIdAsync()
      {
         //Arrange
         var expected = GetEntities().First();

         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         _genericRepository = new GenericRepository<TEntity>(db);

         //Act
         var actual = await _genericRepository.GetByIdAsync("1");

         //Assert
         actual.Should().BeEquivalentTo(expected);
      }

      public async Task TestUpdateAsync()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         _genericRepository = new GenericRepository<TEntity>(db);

         var entity = GetUpdateEntities().First();

         //Act
         await _genericRepository.UpdateAsync(entity);
         await db.SaveChangesAsync();

         //Assert
         db.Set<TEntity>().First(x => x.Id == entity.Id).Should().BeEquivalentTo(entity);
      }

      public async Task TestUpdateRangeAsync()
      {
         //Arrange
         using var db = new TestingSystemContext(UnitTestHelper.GetUnitTestDbOptions());

         _genericRepository = new GenericRepository<TEntity>(db);

         var entities = GetUpdateEntities();

         //Act
         await _genericRepository.UpdateRangeAsync(entities);
         await db.SaveChangesAsync();

         //Assert
         db.Set<TEntity>().First(x => x.Id == entities[0].Id).Should().BeEquivalentTo(entities[0]);
         db.Set<TEntity>().First(x => x.Id == entities[1].Id).Should().BeEquivalentTo(entities[1]);
         db.Set<TEntity>().First(x => x.Id == entities[2].Id).Should().BeEquivalentTo(entities[2]);
      }

      private static List<TEntity> GetEntities()
      {
         if (typeof(TEntity).Name == typeof(Test).Name)
            return TestData.GetTestsWithoutInclude as List<TEntity>;

         else if (typeof(TEntity).Name == typeof(Question).Name)
            return TestData.GetQuestions as List<TEntity>;

         else if (typeof(TEntity).Name == typeof(Answer).Name)
            return TestData.GetAnswers as List<TEntity>;

         else if (typeof(TEntity).Name == typeof(TestStatistics).Name)
            return TestData.GetTestStatistics as List<TEntity>;

         else
            return TestData.GetUserStatisticsWithoutInclude as List<TEntity>;
      }

      private static List<TEntity> GetUpdateEntities()
      {
         if (typeof(TEntity).Name == typeof(Test).Name)
            return TestData.GetTestsUpdateWithoutInclude as List<TEntity>;

         else if (typeof(TEntity).Name == typeof(Question).Name)
            return TestData.GetQuestionsUpdate as List<TEntity>;

         else if (typeof(TEntity).Name == typeof(Answer).Name)
            return TestData.GetAnswersUpdate as List<TEntity>;

         else if (typeof(TEntity).Name == typeof(TestStatistics).Name)
            return TestData.GetTestStatisticsUpdate as List<TEntity>;

         else
            return TestData.GetUserStatisticsUpdate as List<TEntity>;
      }
   }
}
