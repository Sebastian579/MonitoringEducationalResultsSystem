﻿using BusinessLogicLayer.Dtos.Test;

namespace BusinessLogicLayer.Interfaces
{
	/// <summary>
	/// Interface for interaction with Test dtos
	/// </summary>
	public interface ITestService : ICrud<TestGetDto, TestCreateUpdateDto>
	{
		/// <summary>
		/// Gets Tests by test name
		/// </summary>
		/// <param name="name">Test name</param>
		/// <returns>Tests</returns>
		Task<IEnumerable<TestGetDto>> GetTestsByNameSearchAsync(string name);

		/// <summary>
		/// Gets Tests by user id
		/// </summary>
		/// <param name="userId">User id</param>
		/// <returns>Tests</returns>
		Task<IEnumerable<TestGetDto>> GetTestsByUserIdAsync(string userId);

		/// <summary>
		/// Gets Tests include other entities
		/// </summary>
		/// <returns>Tests</returns>
		Task<IEnumerable<TestGetDto>> GetAllTestsWithIncludeAsync();

		/// <summary>
		/// Gets Test include other entities
		/// </summary>
		/// <param name="id">Test id</param>
		/// <returns>Tests</returns>
		Task<TestGetDto> GetTestByIdWithIncludeAsync(string id);

		/// <summary>
		/// Gets Tests by filtering with different parameters
		/// </summary>
		/// <param name="filterModel">class with filter parameters</param>
		/// <returns>Result of filtering</returns>
		Task<IEnumerable<TestGetDto>> GetTestsByFilterAsync(FilterSearchTestModel filterModel);
	}
}
