﻿using BusinessLogicLayer.Dtos.TestStatistics;

namespace BusinessLogicLayer.Interfaces
{
	/// <summary>
	/// Interface for interaction with TestStatistics dtos
	/// </summary>
	public interface ITestStatisticsService : ICrud<TestStatisticsGetDto, TestStatisticsCreateUpdateDto>
	{
		/// <summary>
		/// Get TestStatistics by test id
		/// </summary>
		/// <param name="testId">Test id</param>
		/// <returns>TestStatistics</returns>
		Task<TestStatisticsGetDto> GetByTestIdAsync(string testId);

		/// <summary>
		/// Increment count of attempt and in depend on isPass parameter increment count of pass
		/// </summary>
		/// <param name="statisticsGetDto">TestStatistics for updating</param>
		/// <param name="isPass">Define whether test pass</param>
		/// <returns></returns>
		Task IncrementCountAsync(TestStatisticsGetDto statisticsGetDto, bool isPass);
	}
}