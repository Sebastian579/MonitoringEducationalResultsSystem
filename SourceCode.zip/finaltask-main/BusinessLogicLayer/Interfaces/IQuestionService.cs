﻿using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Models;

namespace BusinessLogicLayer.Interfaces
{
   /// <summary>
   /// Interface for interaction with Question dtos
   /// </summary>
   public interface IQuestionService : ICrud<QuestionGetDto, QuestionCreateUpdateDto>
   {
      /// <summary>
      /// Gets Questions by Test id
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <returns>Filtered Questions</returns>
      Task<IEnumerable<QuestionGetDto>> GetQuestionsByTestIdAsync(string testId);

      /// <summary>
      /// Gets Questions by Test id with included answers
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <returns>Filtered Questions with included answers</returns>
      Task<IEnumerable<QuestionForTestModel>> GetQuestionsByTestIdForTestAsync(string testId);

      /// <summary>
      /// Gets Question by id
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="questionId">Question id</param>
      /// <returns>Question</returns>
      Task<QuestionGetDto> GetQuestionByIdAsync(string testId, string questionId);

      /// <summary>
      /// Check user answers on test questions
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="answers">User answers</param>
      /// <returns>Points for correct answers</returns>
      Task<int> CheckUserAnswersAsync(string testId, ICollection<UserAnswerModel> answers);

      /// <summary>
      /// Check whether test questions exist
      /// </summary>
      /// <param name="testId">Test id</param>
      /// <param name="models">Questions for checking</param>
      /// <returns>True if all exist</returns>
      Task<bool> IsQuestionsExistAsync(string testId, IEnumerable<QuestionCreateUpdateDto> models);

      /// <summary>
      /// Set type of question
      /// </summary>
      /// <param name="questionId">Question id</param>
      Task SetQuestionTypeAsync(string questionId);
   }
}