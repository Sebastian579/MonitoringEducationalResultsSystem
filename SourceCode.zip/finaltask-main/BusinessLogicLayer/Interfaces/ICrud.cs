﻿using BusinessLogicLayer.Dtos.BaseDto;
using System.Linq.Expressions;

namespace BusinessLogicLayer.Interfaces
{
	/// <summary>
	/// General interface for interaction with all repositories
	/// </summary>
	/// <typeparam name="TGetDto">Dto for getting</typeparam>
	/// <typeparam name="TCreateUpdateDto">Dto for creating or updating</typeparam>
	public interface ICrud<TGetDto, TCreateUpdateDto>
		where TGetDto : BaseGetDto
		where TCreateUpdateDto : BaseCreateUpdateDto
	{
		/// <summary>
		/// Gets all dtos
		/// </summary>
		/// <returns></returns>
		Task<IEnumerable<TGetDto>> GetAllAsync();

		/// <summary>
		/// Gets all dtos by expression
		/// </summary>
		/// <param name="expression">Expression for filtering query</param>
		/// <returns>All dtos</returns>
		Task<IQueryable<TGetDto>> GetAllAsync(Expression<Func<TGetDto, bool>> expression);

		/// <summary>
		/// Gets dto
		/// </summary>
		/// <param name="id">Dto id</param>
		/// <returns>Dto</returns>
		Task<TGetDto> GetByIdAsync(string id);

		/// <summary>
		/// Adds new Dto
		/// </summary>
		/// <param name="model">Dto for adding</param>
		/// <returns></returns>
		Task CreateAsync(TCreateUpdateDto model);

		/// <summary>
		/// Adds new Dtos
		/// </summary>
		/// <param name="models">Dtos for adding</param>
		/// <returns></returns>
		Task CreateRangeAsync(IEnumerable<TCreateUpdateDto> models);

		/// <summary>
		/// Update Dto
		/// </summary>
		/// <param name="model">Dto for updating</param>
		/// <returns></returns>
		Task UpdateAsync(TCreateUpdateDto model);

		/// <summary>
		/// Update Dtos
		/// </summary>
		/// <param name="models">Dtos for updating</param>
		/// <returns></returns>
		Task UpdateRangeAsync(IEnumerable<TCreateUpdateDto> models);

		/// <summary>
		/// Delete Dto
		/// </summary>
		/// <param name="model">Dto for deleting</param>
		/// <returns></returns>
		Task DeleteAsync(TGetDto model);
	}
}
