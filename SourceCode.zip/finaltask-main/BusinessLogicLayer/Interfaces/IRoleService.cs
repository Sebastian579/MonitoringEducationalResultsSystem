﻿using Microsoft.AspNetCore.Identity;

namespace BusinessLogicLayer.Interfaces
{
	/// <summary>
	/// Interface for interaction with IdentityRole
	/// </summary>
	public interface IRoleService
    {
        /// <summary>
        /// Adds new Role
        /// </summary>
        /// <param name="roleName">Role name</param>
        /// <returns>Result</returns>
        Task<IdentityResult> AddRoleAsync(string roleName);

        /// <summary>
        /// Gets all roles
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<IdentityRole>> GetRolesAsync();

        /// <summary>
        /// Delete role if exist
        /// </summary>
        /// <param name="roleName">Role name</param>
        /// <returns>True if success deleting</returns>
        Task<bool> DeleteRoleAsync(string roleName);
    }
}
