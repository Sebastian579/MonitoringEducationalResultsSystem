﻿using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Dtos.User;

namespace BusinessLogicLayer.Interfaces
{
	/// <summary>
	/// Interface for getting different statistic
	/// </summary>
	public interface IStatisticService
	{
		/// <summary>
		/// Gets the most popular tests by attempt count
		/// </summary>
		/// <param name="testsCount">Count of tests for getting</param>
		/// <returns>Tests</returns>
		public Task<IEnumerable<TestGetDto>> GetMostPopularTestsAsync(int testsCount);

		/// <summary>
		/// Gets the most active user by count of tests creating
		/// </summary>
		/// <param name="userCount">Count of users for getting</param>
		/// <returns>Users</returns>
		public Task<IEnumerable<UserGetDto>> GetMostActiveTestCreatorsAsync(int userCount);

      /// <summary>
      /// Gets the most active user by count of attempt tests passing
      /// </summary>
      /// <param name="userCount">Count of users for getting</param>
      /// <returns>Users</returns>
      public Task<IEnumerable<UserGetDto>> GetMostActiveUsersAsync(int userCount);

      /// <summary>
      /// Gets the most active user by count of success tests passing
      /// </summary>
      /// <param name="userCount">Count of users for getting</param>
      /// <returns>Users</returns>
      public Task<IEnumerable<UserGetDto>> GetMostSuccessfulUsersAsync(int userCount);

      /// <summary>
      /// Gets the most valuable questions by point value
      /// </summary>
      /// <param name="questionCount">Count of questions for getting</param>
      /// <returns>Questions</returns>
      public Task<IEnumerable<QuestionGetDto>> GetMostValuableQuestionsAsync(int questionCount);
	}
}
