﻿using BusinessLogicLayer.Dtos.User;
using Microsoft.AspNetCore.Identity;

namespace BusinessLogicLayer.Interfaces
{
	/// <summary>
	/// Interface for interaction with User dtos
	/// </summary>
	public interface IUserService
	{
		/// <summary>
		/// Register User
		/// </summary>
		/// <param name="userRegistration">User parameters</param>
		/// <param name="roleName">User role</param>
		/// <returns>Result</returns>
		Task<IdentityResult> RegisterWithRoleAsync(UserRegistrationDto userRegistration,
			string roleName = "User");

		/// <summary>
		/// Gets all users
		/// </summary>
		/// <returns></returns>
		Task<IEnumerable<UserGetDto>> GetUsersAsync();

		/// <summary>
		/// Validates user login and password
		/// </summary>
		/// <param name="userLogin">Contains user login and password</param>
		/// <returns>True if valid</returns>
		Task<bool> ValidateUserAsync(UserLoginDto userLogin);

		/// <summary>
		/// Delete user if exist
		/// </summary>
		/// <param name="userName">User name</param>
		/// <returns>True if success</returns>
		Task<bool> DeleteUserAsync(string userName);

		/// <summary>
		/// Generates token by different options
		/// </summary>
		/// <returns></returns>
		Task<string> CreateTokenAsync();

		/// <summary>
		/// Gets user
		/// </summary>
		/// <param name="userName">User name</param>
		/// <returns>User</returns>
		Task<UserGetDto> GetUserAsync(string userName);

		/// <summary>
		/// Update user
		/// </summary>
		/// <param name="userDto">User for updating</param>
		/// <returns>Result</returns>
		Task<IdentityResult> UpdateUserAsync(UserUpdateDto userDto);

		/// <summary>
		/// Adds new role to User
		/// </summary>
		/// <param name="userName">User name</param>
		/// <param name="roleName">Role</param>
		/// <returns>True if success</returns>
		Task<bool> AddRoleToUserAsync(string userName, string roleName);

		/// <summary>
		/// Delete role from user if exist
		/// </summary>
		/// <param name="userName">User name</param>
		/// <param name="roleName">Role</param>
		/// <returns>True if success</returns>
		Task<bool> RemoveRoleFromUserAsync(string userName, string roleName);
	}
}
