﻿using BusinessLogicLayer.Dtos.Answers;

namespace BusinessLogicLayer.Interfaces
{
   public interface IAnswerService : ICrud<AnswerGetDto, AnswerCreateUpdateDto>
   {
      /// <summary>
      /// Gets Answers by Question id
      /// </summary>
      /// <param name="questionId">Question id</param>
      /// <returns>Filtered Answers</returns>
      Task<IEnumerable<AnswerGetDto>> GetAnswersByQuestionIdAsync(string questionId);

      /// <summary>
      /// Gets Answer by id
      /// </summary>
      /// <param name="questionId">Question id</param>
      /// <param name="answerId">Answer id</param>
      /// <returns>Answer</returns>
      Task<AnswerGetDto> GetAnswerByIdAsync(string questionId, string answerId);

      /// <summary>
      /// Check whether question answers exist
      /// </summary>
      /// <param name="questionId">Question id</param>
      /// <param name="models">Answers for checking</param>
      /// <returns>True if all exist</returns>
      Task<bool> IsAnswersExistAsync(string questionId, IEnumerable<AnswerCreateUpdateDto> models);
   }
}