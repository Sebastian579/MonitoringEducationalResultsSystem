﻿using BusinessLogicLayer.Dtos.UserStatistics;

namespace BusinessLogicLayer.Interfaces
{
   public interface IUserStatisticsService : ICrud<UserStatisticsGetDto, UserStatisticsCreateUpdateDto>
   {
      /// <summary>
      /// Get UserStatistics by user id
      /// </summary>
      /// <param name="userId">User id</param>
      /// <returns>UserStatistics</returns>
      Task<UserStatisticsGetDto> GetByUserIdAsync(string userId);

      /// <summary>
      /// Increment count of attempt and in depend on isPass parameter increment count of pass
      /// </summary>
      /// <param name="statisticsGetDto">UserStatistics for updating</param>
      /// <param name="isPass">Define whether test pass</param>
      /// <returns></returns>
      Task IncrementCountAsync(UserStatisticsGetDto statisticsGetDto, bool isPass);
   }
}