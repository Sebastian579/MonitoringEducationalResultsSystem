﻿namespace BusinessLogicLayer.Roles
{
    /// <summary>
    /// Contains base roles constants
    /// </summary>
    public static class UserRoles
    {
        public const string Admin = "Admin";

        public const string User = "User";

        public const string TestModerator = "TestModerator";

        public const string Teacher = "Teacher";
    }
}
