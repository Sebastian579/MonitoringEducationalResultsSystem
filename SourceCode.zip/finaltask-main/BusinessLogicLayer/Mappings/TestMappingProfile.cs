﻿using AutoMapper;
using BusinessLogicLayer.Dtos.Test;
using DataAccessLayer.Entities;

namespace BusinessLogicLayer.Mappings
{
	/// <summary>
	/// Mapping profile for Test
	/// </summary>
	public class TestMappingProfile : Profile
	{
		public TestMappingProfile()
		{
			CreateMap<Test, TestGetDto>()
				.ForMember(td => td.QuestionCount, t => t.MapFrom(x => x.Questions.Count))
				.ForMember(td => td.PassPercentage,
					t => t.MapFrom(x => (int)(x.TestStatistics.PassCount * 100.0
					/ (x.TestStatistics.AttemptCount > 0 ? x.TestStatistics.AttemptCount : 1))));

			CreateMap<TestGetDto, Test>();

			CreateMap<TestCreateUpdateDto, Test>();
		}
	}
}
