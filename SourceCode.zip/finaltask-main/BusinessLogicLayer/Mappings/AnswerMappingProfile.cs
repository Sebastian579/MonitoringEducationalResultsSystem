﻿using AutoMapper;
using BusinessLogicLayer.Dtos.Answers;
using DataAccessLayer.Entities;

namespace BusinessLogicLayer.Mappings
{
   public class AnswerMappingProfile : Profile
   {
      public AnswerMappingProfile()
      {
         CreateMap<Answer, AnswerGetDto>().ReverseMap();

         CreateMap<AnswerCreateUpdateDto, Answer>();
      }
   }
}
