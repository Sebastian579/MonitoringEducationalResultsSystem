﻿using AutoMapper;
using BusinessLogicLayer.Dtos.Question;
using DataAccessLayer.Entities;

namespace BusinessLogicLayer.Mappings
{
	/// <summary>
	/// Mapping profile for Question
	/// </summary>
	public class QuestionMappingProfile : Profile
	{
		public QuestionMappingProfile()
		{
			CreateMap<Question, QuestionGetDto>().ReverseMap();

			CreateMap<QuestionCreateUpdateDto, Question>();
		}
	}
}
