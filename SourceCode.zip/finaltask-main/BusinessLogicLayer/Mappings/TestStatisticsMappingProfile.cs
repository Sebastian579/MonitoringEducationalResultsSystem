﻿using AutoMapper;
using BusinessLogicLayer.Dtos.TestStatistics;
using DataAccessLayer.Entities;

namespace BusinessLogicLayer.Mappings
{
	/// <summary>
	/// Mapping profile for TestStatistics
	/// </summary>
	public class TestStatisticsMappingProfile : Profile
	{
		public TestStatisticsMappingProfile()
		{
			CreateMap<TestStatistics, TestStatisticsGetDto>().ReverseMap();

			CreateMap<TestStatisticsCreateUpdateDto, TestStatistics>();

			CreateMap<TestStatisticsGetDto, TestStatisticsCreateUpdateDto>();
		}
	}
}
