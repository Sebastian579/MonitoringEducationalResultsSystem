﻿using AutoMapper;
using BusinessLogicLayer.Dtos.User;
using DataAccessLayer.Entities;

namespace BusinessLogicLayer.Mappings
{
	/// <summary>
	/// Mapping profile for User
	/// </summary>
	public class UserMappingProfile : Profile
    {
        public UserMappingProfile()
        {
            CreateMap<UserRegistrationDto, User>();

            CreateMap<User, UserGetDto>();

            CreateMap<UserUpdateDto, User>();
        }
    }
}
