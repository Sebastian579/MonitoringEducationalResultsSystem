﻿using AutoMapper;
using BusinessLogicLayer.Dtos.TestStatistics;
using BusinessLogicLayer.Dtos.UserStatistics;
using DataAccessLayer.Entities;

namespace BusinessLogicLayer.Mappings
{
   /// <summary>
   /// Mapping profile for TestStatistics
   /// </summary>
   public class UserStatisticsMappingProfile : Profile
   {
      public UserStatisticsMappingProfile()
      {
         CreateMap<UserStatistics, UserStatisticsGetDto>().ReverseMap();

         CreateMap<UserStatisticsCreateUpdateDto, UserStatistics>();

         CreateMap<UserStatisticsGetDto, UserStatisticsCreateUpdateDto>();
      }
   }
}