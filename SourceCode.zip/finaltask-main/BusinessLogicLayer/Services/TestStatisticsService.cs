﻿using AutoMapper;
using BusinessLogicLayer.Dtos.TestStatistics;
using BusinessLogicLayer.Interfaces;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;

namespace BusinessLogicLayer.Services
{
	public class TestStatisticsService : CrudService<TestStatisticsGetDto, TestStatisticsCreateUpdateDto,
		TestStatistics>, ITestStatisticsService
	{
		public TestStatisticsService(IUnitOfWork unitOfWork, IMapper mapper)
			: base(unitOfWork, mapper) { }

		public async Task<TestStatisticsGetDto> GetByTestIdAsync(string testId)
		{
			var testStatistics = await GetAllAsync();

			return testStatistics.FirstOrDefault(ts => ts.TestId == testId);
		}

		public async Task IncrementCountAsync(TestStatisticsGetDto statisticsGetDto, bool isPass)
		{
			statisticsGetDto.AttemptCount++;

			if (isPass)
				statisticsGetDto.PassCount++;

			await UpdateAsync(_mapper.Map<TestStatisticsCreateUpdateDto>(statisticsGetDto));
		}
	}
}
