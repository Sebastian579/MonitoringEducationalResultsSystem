﻿using AutoMapper;
using BusinessLogicLayer.Dtos.UserStatistics;
using BusinessLogicLayer.Interfaces;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;

namespace BusinessLogicLayer.Services
{
   public class UserStatisticsService : CrudService<UserStatisticsGetDto, UserStatisticsCreateUpdateDto,
     UserStatistics>, IUserStatisticsService
   {
      public UserStatisticsService(IUnitOfWork unitOfWork, IMapper mapper)
         : base(unitOfWork, mapper) { }

      public async Task<UserStatisticsGetDto> GetByUserIdAsync(string userId)
      {
         var userStatistics = await GetAllAsync();

         return userStatistics.FirstOrDefault(us => us.UserId == userId);
      }

      public async Task IncrementCountAsync(UserStatisticsGetDto statisticsGetDto, bool isPass)
      {
         statisticsGetDto.AttemptCount++;

         if (isPass)
            statisticsGetDto.PassCount++;

         await UpdateAsync(_mapper.Map<UserStatisticsCreateUpdateDto>(statisticsGetDto));
      }
   }
}