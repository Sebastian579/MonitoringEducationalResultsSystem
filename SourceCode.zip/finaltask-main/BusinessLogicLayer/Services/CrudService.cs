﻿using AutoMapper;
using BusinessLogicLayer.Dtos.BaseDto;
using BusinessLogicLayer.Interfaces;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace BusinessLogicLayer.Services
{
	public class CrudService<TGetDto, TCreateUpdateDto, TEntity> : ICrud<TGetDto, TCreateUpdateDto>
		where TGetDto : BaseGetDto
		where TCreateUpdateDto : BaseCreateUpdateDto
		where TEntity : BaseEntity
	{
		protected readonly IUnitOfWork _unitOfWork;
		protected readonly IMapper _mapper;

		public CrudService(IUnitOfWork unitOfWork, IMapper mapper)
		{
			_unitOfWork = unitOfWork;
			_mapper = mapper;
		}

		public async Task CreateAsync(TCreateUpdateDto model)
		{
			await _unitOfWork.Repository<TEntity>().CreateAsync(_mapper.Map<TEntity>(model));
			await _unitOfWork.SaveAsync();
		}

		public async Task CreateRangeAsync(IEnumerable<TCreateUpdateDto> models)
		{
			await _unitOfWork.Repository<TEntity>().CreateRangeAsync(_mapper.Map<IEnumerable<TEntity>>(models));
			await _unitOfWork.SaveAsync();
		}

		public async Task DeleteAsync(TGetDto model)
		{
			await _unitOfWork.Repository<TEntity>().DeleteAsync(_mapper.Map<TEntity>(model));
			await _unitOfWork.SaveAsync();
		}

		public async Task<IEnumerable<TGetDto>> GetAllAsync()
		{
			var entities = await _unitOfWork.Repository<TEntity>().GetAllAsync();

			return _mapper.Map<IEnumerable<TGetDto>>(await entities.ToListAsync());
		}

		public async Task<IQueryable<TGetDto>> GetAllAsync(Expression<Func<TGetDto, bool>> expression)
		{
			var models = _mapper.ProjectTo<TGetDto>(await _unitOfWork.Repository<TEntity>().GetAllAsync());

			return models.Where(expression);
		}

		public async Task<TGetDto> GetByIdAsync(string id)
		{
			return _mapper.Map<TGetDto>(await _unitOfWork.Repository<TEntity>().GetByIdAsync(id));
		}

		public async Task UpdateAsync(TCreateUpdateDto model)
		{
			await _unitOfWork.Repository<TEntity>().UpdateAsync(_mapper.Map<TEntity>(model));
			await _unitOfWork.SaveAsync();
		}

		public async Task UpdateRangeAsync(IEnumerable<TCreateUpdateDto> models)
		{
			await _unitOfWork.Repository<TEntity>().UpdateRangeAsync(_mapper.Map<IEnumerable<TEntity>>(models));
			await _unitOfWork.SaveAsync();
		}
	}
}
