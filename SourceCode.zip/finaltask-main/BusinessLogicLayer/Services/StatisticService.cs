﻿using AutoMapper;
using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Dtos.User;
using BusinessLogicLayer.Interfaces;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace BusinessLogicLayer.Services
{
   public class StatisticService : IStatisticService
   {
      private readonly IUnitOfWork _unitOfWork;
      private readonly IMapper _mapper;

      public StatisticService(IUnitOfWork unitOfWork, IMapper mapper)
      {
         _unitOfWork = unitOfWork;
         _mapper = mapper;
      }

      public async Task<IEnumerable<UserGetDto>> GetMostActiveTestCreatorsAsync(int userCount)
      {
         var tests = await (await _unitOfWork.Repository<Test>().GetAllWithIncludeAsync(t => t.User))
                        .ToListAsync();

         var users = tests.GroupBy(x => x.UserId, y => y.User)
            .OrderByDescending(g => g.Count())
            .ThenBy(u => u.Key)
            .Select(g => g.First())
            .Take(userCount > 0 ? userCount : int.MaxValue);

         return _mapper.Map<IEnumerable<UserGetDto>>(users);
      }

      public async Task<IEnumerable<UserGetDto>> GetMostActiveUsersAsync(int userCount)
      {
         var userStatistics = await _unitOfWork.Repository<UserStatistics>().GetAllWithIncludeAsync(t => t.User);

         var users = userStatistics.OrderByDescending(us => us.AttemptCount)
            .ThenBy(us => us.User.Id)
            .Select(us => us.User)
            .Take(userCount > 0 ? userCount : int.MaxValue);

         return _mapper.Map<IEnumerable<UserGetDto>>(await users.ToListAsync());
      }

      public async Task<IEnumerable<UserGetDto>> GetMostSuccessfulUsersAsync(int userCount)
      {
         var userStatistics = await _unitOfWork.Repository<UserStatistics>().GetAllWithIncludeAsync(t => t.User);

         var users = userStatistics.OrderByDescending(us => us.PassCount)
            .ThenBy(us => us.User.Id)
            .Select(us => us.User)
            .Take(userCount > 0 ? userCount : int.MaxValue);

         return _mapper.Map<IEnumerable<UserGetDto>>(await users.ToListAsync());
      }

      public async Task<IEnumerable<TestGetDto>> GetMostPopularTestsAsync(int testsCount)
      {
         var tests = await _unitOfWork.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
            t => t.TestStatistics);

         tests = tests.OrderByDescending(t => t.TestStatistics.AttemptCount)
            .ThenBy(t => t.Id)
            .Take(testsCount > 0 ? testsCount : int.MaxValue);

         return _mapper.Map<IEnumerable<TestGetDto>>(await tests.ToListAsync());
      }

      public async Task<IEnumerable<QuestionGetDto>> GetMostValuableQuestionsAsync(int questionCount)
      {
         var tests = await _unitOfWork.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions);

         var questions = tests.SelectMany(t => t.Questions)
            .OrderByDescending(q => q.Points)
            .ThenBy(q => q.Id)
            .Take(questionCount > 0 ? questionCount : int.MaxValue);

         return _mapper.Map<IEnumerable<QuestionGetDto>>(await questions.ToListAsync());
      }
   }
}
