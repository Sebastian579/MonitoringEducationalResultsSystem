﻿using Azure.AI.OpenAI;
using BusinessLogicLayer.Models.AI;
using OpenAI;
using OpenAI.Chat;
using System.ClientModel;
using System.Text.Json;

namespace BusinessLogicLayer.Services;

public class AzureOpenAIService
{
	private const string AiModel = "gpt-4o-mini";

	private readonly OpenAIClient _client;

	public AzureOpenAIService(string endpoint, string apiKey)
	{
		if (!string.IsNullOrWhiteSpace(endpoint) && !string.IsNullOrWhiteSpace(apiKey))
		{
			_client = new AzureOpenAIClient(new Uri(endpoint), new ApiKeyCredential(apiKey));
		}
	}

	public async Task<AITest> GenerateTestAsync(string description)
	{
		if (_client is null || string.IsNullOrWhiteSpace(description))
			return null;

		ChatClient chatClient = _client.GetChatClient(AiModel);
		string aiPrompt = $"Generate a JSON representation of a test based on the following description: {description}. " +
				   "The JSON should include the test name (name), execution time in minutes (executionTime), pass score, and a list of questions. " +
				   "Each question should have the question text, points, and a list of answers. Each answer should have the answer text and a boolean indicating if it is correct. " +
				   "Ensure the total sum of points for all questions more or equal (>=) the pass score. And just return response in JSON format without '```json'.";

		ChatCompletion completion = await chatClient.CompleteChatAsync(
			new List<ChatMessage>
			{
				new SystemChatMessage("You are an Integrated AI that only generates JSON response of needed test based on user description."),
				new UserChatMessage(aiPrompt),
			});

		var generatedText = completion.Content[0].Text;
		var test = ParseGeneratedText(generatedText);

		return test;
	}

	private static AITest ParseGeneratedText(string generatedText)
	{
		try
		{
			var test = JsonSerializer.Deserialize<AITest>(generatedText, new JsonSerializerOptions
			{
				PropertyNameCaseInsensitive = true
			});
			return test;
		}
		catch (JsonException ex)
		{
			Console.WriteLine($"Error parsing JSON: {ex.Message}\n Generated text: {generatedText}");
			return null;
		}
	}
}
