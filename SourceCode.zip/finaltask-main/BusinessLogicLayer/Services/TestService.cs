﻿using AutoMapper;
using BusinessLogicLayer.Dtos.Test;
using BusinessLogicLayer.Interfaces;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

namespace BusinessLogicLayer.Services
{
	public class TestService : CrudService<TestGetDto, TestCreateUpdateDto, Test>, ITestService
	{
		public TestService(IUnitOfWork unitOfWork, IMapper mapper)
			: base(unitOfWork, mapper) { }

		public async Task<IEnumerable<TestGetDto>> GetTestsByNameSearchAsync(string name)
		{
			var tests = await _unitOfWork.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics);

			return _mapper.Map<IEnumerable<TestGetDto>>(await tests.ToListAsync())
					.Where(t => t.Name.Contains(name, StringComparison.OrdinalIgnoreCase));
		}

		public async Task<IEnumerable<TestGetDto>> GetAllTestsWithIncludeAsync()
		{
			var tests = await _unitOfWork.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics);

			return _mapper.Map<IEnumerable<TestGetDto>>(await tests.ToListAsync());
		}

		public async Task<TestGetDto> GetTestByIdWithIncludeAsync(string id)
		{
			return _mapper.Map<TestGetDto>(await _unitOfWork.Repository<Test>()
					.GetByIdWithIncludeAsync(id, t => t.Questions, t => t.TestStatistics));
		}

		public async Task<IEnumerable<TestGetDto>> GetTestsByUserIdAsync(string userId)
		{
			var tests = await _unitOfWork.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics);

			return _mapper.Map<IEnumerable<TestGetDto>>(await tests.Where(t => t.UserId == userId)
					.ToListAsync());
		}

		public async Task<IEnumerable<TestGetDto>> GetTestsByFilterAsync(FilterSearchTestModel filterModel)
		{
			var tests = await _unitOfWork.Repository<Test>().GetAllWithIncludeAsync(t => t.Questions,
				t => t.TestStatistics, t => t.User);

			if (filterModel.UserName != null)
				tests = tests.Where(t => t.User.UserName.ToLower() == filterModel.UserName.ToLower());

			if (filterModel.MinExecutionTime != null)
				tests = tests.Where(t => t.ExecutionTime >= filterModel.MinExecutionTime);

			if (filterModel.MaxExecutionTime != null)
				tests = tests.Where(t => t.ExecutionTime <= filterModel.MaxExecutionTime);

			if (filterModel.MinPassScore != null)
				tests = tests.Where(t => t.PassScore >= filterModel.MinPassScore);

			if (filterModel.MaxPassScore != null)
				tests = tests.Where(t => t.PassScore <= filterModel.MaxPassScore);

			return _mapper.Map<IEnumerable<TestGetDto>>(await tests.ToListAsync());
		}
	}
}
