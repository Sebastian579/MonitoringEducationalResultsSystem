﻿using AutoMapper;
using BusinessLogicLayer.Dtos.Answers;
using BusinessLogicLayer.Interfaces;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace BusinessLogicLayer.Services
{
   public class AnswerService : CrudService<AnswerGetDto, AnswerCreateUpdateDto, Answer>,
     IAnswerService
   {
      public AnswerService(IUnitOfWork unitOfWork, IMapper mapper)
   : base(unitOfWork, mapper) { }

      public async Task<IEnumerable<AnswerGetDto>> GetAnswersByQuestionIdAsync(string questionId)
      {
         var answers = await GetAllAsync(q => q.QuestionId == questionId);

         return await answers.ToListAsync();
      }

      public async Task<AnswerGetDto> GetAnswerByIdAsync(string questionId, string answerId)
      {
         var answers = await GetAllAsync(q => q.QuestionId == questionId);

         return await answers.FirstOrDefaultAsync(q => q.Id == answerId);
      }

      public async Task<bool> IsAnswersExistAsync(string questionId, IEnumerable<AnswerCreateUpdateDto> models)
      {
         var answers = await GetAllAsync(q => q.QuestionId == questionId);

         return models.All(m => answers.Any(q => q.Id == m.Id));
      }
   }
}