﻿using AutoMapper;
using BusinessLogicLayer.Dtos.Question;
using BusinessLogicLayer.Interfaces;
using BusinessLogicLayer.Models;
using DataAccessLayer.Entities;
using DataAccessLayer.Enums;
using DataAccessLayer.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace BusinessLogicLayer.Services
{
   public class QuestionService : CrudService<QuestionGetDto, QuestionCreateUpdateDto, Question>,
      IQuestionService
   {
      public QuestionService(IUnitOfWork unitOfWork, IMapper mapper)
         : base(unitOfWork, mapper) { }


      public async Task<IEnumerable<QuestionForTestModel>> GetQuestionsByTestIdForTestAsync(string testId)
      {
         var questions = (await _unitOfWork.Repository<Question>().GetAllWithIncludeAsync(q => q.Answers))
            .Where(q => q.TestId == testId).ToList();

         return questions.Select(q => new QuestionForTestModel
         {
            Id = q.Id,
            QuestionText = q.QuestionText,
            Type = q.Type,
            Points = q.Points,
            TestId = q.TestId,
            Answers = q.Answers.Select(a => new AnswerForTestModel
            {
               Id = a.Id,
               QuestionId = a.QuestionId,
               AnswerText = q.Type != QuestionType.FreeText ? a.AnswerText : ""
            })
         });
      }

      public async Task<int> CheckUserAnswersAsync(string testId, ICollection<UserAnswerModel> answers)
      {
         var questions = (await _unitOfWork.Repository<Question>().GetAllWithIncludeAsync(q => q.Answers))
            .Where(q => q.TestId == testId).ToList();

         int points = 0;

         foreach (var answer in answers)
         {
            var question = questions.First(q => q.Id == answer.QuestionId);
            switch (question.Type)
            {
               case QuestionType.FreeText:
                  if (question.Answers.First().AnswerText.ToLower() == answer.AnswerText.ToLower())
                  {
                     points += question.Points;
                  }
                  break;
               case QuestionType.SingleChoice:
                  var singleChoiceAnswer = question.Answers.FirstOrDefault(a => a.Id == answer.SingleChoiceId);
                  if (singleChoiceAnswer != null && singleChoiceAnswer.IsCorrect)
                  {
                     points += question.Points;
                  }
                  break;
               case QuestionType.MultipleChoice:
                  var correctCount = question.Answers.Count(a => a.IsCorrect);
                  decimal earnedPoints = 0m;
                  int userSelectedCount = 0;

                  for (int i = 0; i < question.Answers.Count; i++)
                  {
                     if (answer.MultipleChoice.ElementAt(i))
                     {
                        userSelectedCount++;
                        if (question.Answers.ElementAt(i).IsCorrect)
                        {
                           earnedPoints += (decimal)question.Points / correctCount;
                        }
                        else
                        {
                           earnedPoints -= (decimal)question.Points / correctCount;
                        }
                     }
                  }
                  earnedPoints = Math.Max(0m, earnedPoints);
                  if (userSelectedCount == question.Answers.Count && userSelectedCount != correctCount)
                  {
                     break;
                  }

                  points += (int)Math.Round(earnedPoints);
                  break;
               default:
                  throw new ArgumentException("Invalid question type.");
            }
         }

         return points;
      }

      public async Task<QuestionGetDto> GetQuestionByIdAsync(string testId, string questionId)
      {
         var questions = await GetAllAsync(q => q.TestId == testId);

         return await questions.FirstOrDefaultAsync(q => q.Id == questionId);
      }

      public async Task<IEnumerable<QuestionGetDto>> GetQuestionsByTestIdAsync(string testId)
      {
         var questions = await GetAllAsync(q => q.TestId == testId);

         return await questions.ToListAsync();
      }

      public async Task<bool> IsQuestionsExistAsync(string testId, IEnumerable<QuestionCreateUpdateDto> models)
      {
         var questions = await GetAllAsync(q => q.TestId == testId);

         return models.All(m => questions.Any(q => q.Id == m.Id));
      }

      public async Task SetQuestionTypeAsync(string questionId)
      {
         var question = await _unitOfWork.Repository<Question>()
            .GetByIdWithIncludeAsync(questionId, q => q.Answers);
         var type = GetQuestionType(question.Answers.Select(a => a.IsCorrect).ToList());

         if (type != question.Type)
         {
            question.Type = type;
            await _unitOfWork.Repository<Question>().UpdateAsync(question);
            await _unitOfWork.SaveAsync();
         }
      }

      public static void SetQuestionType(QuestionCreateUpdateDto questionDto)
      {
         var answers = questionDto.Answers?.Select(a => a.IsCorrect).ToList();

         questionDto.Type = GetQuestionType(answers);
      }

      private static QuestionType GetQuestionType(ICollection<bool> answers)
      {
         if (answers.Count == 1)
         {
            return QuestionType.FreeText;
         }
         else if (answers.Count > 1 && answers.Count(a => a) == 1)
         {
            return QuestionType.SingleChoice;
         }
         else if (answers.Count(a => a) > 1)
         {
            return QuestionType.MultipleChoice;
         }

         return QuestionType.None;
      }
   }
}