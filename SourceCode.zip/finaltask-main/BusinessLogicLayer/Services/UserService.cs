﻿using AutoMapper;
using BusinessLogicLayer.Dtos.User;
using BusinessLogicLayer.Interfaces;
using DataAccessLayer.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BusinessLogicLayer.Services
{
	public class UserService : IUserService
	{
		private readonly UserManager<User> _userManager;
		private readonly RoleManager<IdentityRole> _roleManager;
		private readonly IMapper _mapper;
		private readonly IConfiguration _configuration;
		private User _user;

		public UserService(UserManager<User> userManager, IMapper mapper,
			IConfiguration configuration, RoleManager<IdentityRole> roleManager)
		{
			_userManager = userManager;
			_mapper = mapper;
			_configuration = configuration;
			_roleManager = roleManager;
		}

		public async Task<string> CreateTokenAsync()
		{
			var signingCredentials = GetSigningCredentials();
			var claims = await GetClaims();
			var tokenOptions = GenerateTokenOptions(signingCredentials, claims);

			return new JwtSecurityTokenHandler().WriteToken(tokenOptions);
		}

		public async Task<IdentityResult> RegisterWithRoleAsync(UserRegistrationDto userRegistration,
			string roleName = "User")
		{
			var user = _mapper.Map<User>(userRegistration);
			var userResult = await _userManager.CreateAsync(user, userRegistration.Password);

			if (userResult.Succeeded && await _roleManager.RoleExistsAsync(roleName))
				return await _userManager.AddToRoleAsync(user, roleName);

			return userResult;
		}

		public async Task<bool> ValidateUserAsync(UserLoginDto userLogin)
		{
			_user = await _userManager.FindByNameAsync(userLogin.UserName);

			return _user != null
				&& await _userManager.CheckPasswordAsync(_user, userLogin.Password);
		}

		private SigningCredentials GetSigningCredentials()
		{
			var jwtConfig = _configuration.GetSection("JWT");
			var key = Encoding.UTF8.GetBytes(jwtConfig["Secret"]);
			var secret = new SymmetricSecurityKey(key);

			return new SigningCredentials(secret, SecurityAlgorithms.HmacSha256);
		}

		private async Task<List<Claim>> GetClaims()
		{
			var claims = new List<Claim>
			{
				new Claim(ClaimTypes.Name, _user.UserName),
				new Claim(ClaimTypes.NameIdentifier, _user.Id)
			};

			var roles = await _userManager.GetRolesAsync(_user);
			foreach (var role in roles)
			{
				claims.Add(new Claim(ClaimTypes.Role, role));
			}

			return claims;
		}

		private JwtSecurityToken GenerateTokenOptions(SigningCredentials signingCredentials, List<Claim> claims)
		{
			var jwtSettings = _configuration.GetSection("JWT");
			var tokenOptions = new JwtSecurityToken
			(
			issuer: jwtSettings["ValidIssuer"],
			audience: jwtSettings["ValidAudience"],
			claims: claims,
			expires: DateTime.Now.AddMinutes(Convert.ToDouble(jwtSettings["ExpiresIn"])),
			signingCredentials: signingCredentials
			);

			return tokenOptions;
		}

		public async Task<bool> DeleteUserAsync(string userName)
		{
			var user = await _userManager.FindByNameAsync(userName);

			if (user == null)
				return false;

			await _userManager.DeleteAsync(user);

			return true;
		}

		public async Task<IEnumerable<UserGetDto>> GetUsersAsync()
		{
			var users = await _userManager.Users.ToListAsync();
			List<UserGetDto> usersGetList = new();

			foreach (var user in users)
			{
				var userGet = _mapper.Map<UserGetDto>(user);
				userGet.Roles = await _userManager.GetRolesAsync(user);
				usersGetList.Add(userGet);
			}

			return usersGetList;
		}

		public async Task<UserGetDto> GetUserAsync(string userName)
		{
			User user = await _userManager.FindByNameAsync(userName);

			if (user == null)
				return null;

			UserGetDto userGet = _mapper.Map<UserGetDto>(user);
			userGet.Roles = await _userManager.GetRolesAsync(user);

			return userGet;
		}

		public async Task<IdentityResult> UpdateUserAsync(UserUpdateDto userDto)
		{
			var user = await _userManager.FindByNameAsync(userDto.UserName);

			user.FirstName = userDto.FirstName;
			user.LastName = userDto.LastName;
			user.Email = userDto.Email;

			return await _userManager.UpdateAsync(user);
		}

		public async Task<bool> AddRoleToUserAsync(string userName, string roleName)
		{
			var user = await _userManager.FindByNameAsync(userName);

			if (await _roleManager.RoleExistsAsync(roleName) && user != null)
			{
				await _userManager.AddToRoleAsync(user, roleName);
				return true;
			}

			return false;
		}

		public async Task<bool> RemoveRoleFromUserAsync(string userName, string roleName)
		{
			var user = await _userManager.FindByNameAsync(userName);

			if (await _roleManager.RoleExistsAsync(roleName) && user != null)
			{
				await _userManager.RemoveFromRoleAsync(user, roleName);
				return true;
			}

			return false;
		}
	}
}
