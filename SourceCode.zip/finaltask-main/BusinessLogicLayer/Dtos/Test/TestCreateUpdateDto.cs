﻿using System.ComponentModel.DataAnnotations;
using BusinessLogicLayer.Dtos.BaseDto;

namespace BusinessLogicLayer.Dtos.Test
{
   /// <summary>
   /// Test dto for creating or updating
   /// </summary>
   public class TestCreateUpdateDto : BaseCreateUpdateDto
   {
      [Required]
      public string Name { get; set; }

      [Required]
      [Range(5, 600)]
      public int ExecutionTime { get; set; }

      [Required]
      [Range(1, int.MaxValue)]
      public int PassScore { get; set; }

      public DateTime CreationDate { get; set; }

      public string UserId { get; set; }
   }
}
