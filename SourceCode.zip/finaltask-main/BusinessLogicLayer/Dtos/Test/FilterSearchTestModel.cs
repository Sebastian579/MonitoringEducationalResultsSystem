﻿namespace BusinessLogicLayer.Dtos.Test
{
	/// <summary>
	/// Contains property for filtering
	/// </summary>
	public class FilterSearchTestModel
	{
		public string UserName { get; set; }

		public int? MinExecutionTime { get; set; }

		public int? MaxExecutionTime { get; set; }

		public int? MinPassScore { get; set; }

		public int? MaxPassScore { get; set; }
	}
}
