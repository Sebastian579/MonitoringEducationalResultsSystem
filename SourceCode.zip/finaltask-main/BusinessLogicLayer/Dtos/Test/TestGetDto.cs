﻿using BusinessLogicLayer.Dtos.BaseDto;

namespace BusinessLogicLayer.Dtos.Test
{
	/// <summary>
	/// Test dto for getting
	/// </summary>
	public class TestGetDto : BaseGetDto
	{
		public string Name { get; set; }

		public int ExecutionTime { get; set; }

		public int PassScore { get; set; }

		public int QuestionCount { get; set; }

		public int PassPercentage { get; set; }

		public DateTime CreationDate { get; set; }

		public string UserId { get; set; }
	}
}
