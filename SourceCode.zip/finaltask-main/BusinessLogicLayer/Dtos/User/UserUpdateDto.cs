﻿using System.ComponentModel.DataAnnotations;

namespace BusinessLogicLayer.Dtos.User
{
	/// <summary>
	/// User dto for updating
	/// </summary>
	public class UserUpdateDto
	{
		public string Id { get; set; }

		public string FirstName { get; set; }

		public string LastName { get; set; }

		[Required(ErrorMessage = "Username is required")]
		[MinLength(6, ErrorMessage = "Username must be at least 6 characters")]
		[MaxLength(20, ErrorMessage = "Username must not exceed 20 characters")]
		public string UserName { get; set; }

		[Required(ErrorMessage = "Email is required")]
		[EmailAddress(ErrorMessage = "Email must be a valid email address")]
		public string Email { get; set; }
	}
}
