﻿using System.ComponentModel.DataAnnotations;

namespace BusinessLogicLayer.Dtos.User
{
    /// <summary>
    /// User dto for login
    /// </summary>
    public class UserLoginDto
    {
        [Required(ErrorMessage = "Username is required")]
        [MinLength(6, ErrorMessage = "Username must be at least 6 characters")]
        [MaxLength(20, ErrorMessage = "Username must not exceed 20 characters")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters")]
        [MaxLength(40, ErrorMessage = "Password must not exceed 40 characters")]
        public string Password { get; set; }
    }
}
