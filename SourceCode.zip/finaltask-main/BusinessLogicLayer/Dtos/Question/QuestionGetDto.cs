﻿using BusinessLogicLayer.Dtos.BaseDto;
using DataAccessLayer.Enums;

namespace BusinessLogicLayer.Dtos.Question
{
	/// <summary>
	/// Question dto for getting
	/// </summary>
	public class QuestionGetDto : BaseGetDto
	{
		public string QuestionText { get; set; }

		public int Points { get; set; }

		public QuestionType Type { get; set; }

		public string TestId { get; set; }
	}
}