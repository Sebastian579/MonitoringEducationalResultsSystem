﻿using System.ComponentModel.DataAnnotations;
using BusinessLogicLayer.Dtos.Answers;
using BusinessLogicLayer.Dtos.BaseDto;
using DataAccessLayer.Enums;

namespace BusinessLogicLayer.Dtos.Question
{
   /// <summary>
   /// Question dto for creating or updating
   /// </summary>
   public class QuestionCreateUpdateDto : BaseCreateUpdateDto
   {
      [Required(ErrorMessage = "Question text is required")]
      public string QuestionText { get; set; }

      [Range(1, int.MaxValue)]
      [Required(ErrorMessage = "Points is required")]
      public int Points { get; set; }

      public QuestionType Type { get; set; }

      [Required(ErrorMessage = "At least one answer")]
      public ICollection<AnswerCreateUpdateDto> Answers { get; set; }

      public string TestId { get; set; }
   }
}