﻿namespace BusinessLogicLayer.Dtos.BaseDto
{
    /// <summary>
    /// Base class for all dtos, which use in creating or updating
    /// </summary>
    public abstract class BaseCreateUpdateDto
    {
        public string Id { get; set; }
    }
}
