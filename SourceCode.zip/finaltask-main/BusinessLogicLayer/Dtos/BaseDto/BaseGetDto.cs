﻿namespace BusinessLogicLayer.Dtos.BaseDto
{
	/// <summary>
	/// Base class for all dtos, which use in getting
	/// </summary>
	public abstract class BaseGetDto
    {
        public string Id { get; set; }
    }
}
