﻿using BusinessLogicLayer.Dtos.BaseDto;

namespace BusinessLogicLayer.Dtos.UserStatistics
{
   /// <summary>
   /// UserStatistics dto for creating or updating
   /// </summary>
   public class UserStatisticsCreateUpdateDto : BaseCreateUpdateDto
   {
      public int AttemptCount { get; set; }

      public int PassCount { get; set; }

      public string UserId { get; set; }
   }
}