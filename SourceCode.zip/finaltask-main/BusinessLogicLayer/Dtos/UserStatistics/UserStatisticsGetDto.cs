﻿using BusinessLogicLayer.Dtos.BaseDto;

namespace BusinessLogicLayer.Dtos.UserStatistics
{
   /// <summary>
   /// UserStatistics dto for getting
   /// </summary>
   public class UserStatisticsGetDto : BaseGetDto
   {
      public int AttemptCount { get; set; }

      public int PassCount { get; set; }

      public string UserId { get; set; }
   }
}