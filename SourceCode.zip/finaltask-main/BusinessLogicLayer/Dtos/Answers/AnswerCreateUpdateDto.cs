﻿using BusinessLogicLayer.Dtos.BaseDto;
using System.ComponentModel.DataAnnotations;

namespace BusinessLogicLayer.Dtos.Answers
{
   /// <summary>
   /// Answer dto for creating or updating
   /// </summary>
   public class AnswerCreateUpdateDto : BaseCreateUpdateDto
   {
      [Required(ErrorMessage = "Answer text is required")]
      public string AnswerText { get; set; }

      public bool IsCorrect { get; set; }

      public string QuestionId { get; set; }
   }
}