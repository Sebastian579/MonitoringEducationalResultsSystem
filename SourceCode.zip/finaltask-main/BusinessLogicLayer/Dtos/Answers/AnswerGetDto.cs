﻿using BusinessLogicLayer.Dtos.BaseDto;

namespace BusinessLogicLayer.Dtos.Answers
{
   /// <summary>
   /// Answer dto for getting
   /// </summary>
   public class AnswerGetDto : BaseGetDto
   {
      public string AnswerText { get; set; }

      public bool IsCorrect { get; set; }

      public string QuestionId { get; set; }
   }
}