﻿using BusinessLogicLayer.Dtos.BaseDto;

namespace BusinessLogicLayer.Dtos.TestStatistics
{
	/// <summary>
	/// TestStatistics dto for getting
	/// </summary>
	public class TestStatisticsGetDto : BaseGetDto
	{
		public int AttemptCount { get; set; }

		public int PassCount { get; set; }

		public string TestId { get; set; }
	}
}
