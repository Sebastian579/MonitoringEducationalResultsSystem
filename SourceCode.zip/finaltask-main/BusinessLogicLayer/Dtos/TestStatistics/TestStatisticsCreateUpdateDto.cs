﻿using BusinessLogicLayer.Dtos.BaseDto;

namespace BusinessLogicLayer.Dtos.TestStatistics
{
	/// <summary>
	/// TestStatistics dto for creating or updating
	/// </summary>
	public class TestStatisticsCreateUpdateDto : BaseCreateUpdateDto
	{
		public int AttemptCount { get; set; }

		public int PassCount { get; set; }

		public string TestId { get; set; }
	}
}
