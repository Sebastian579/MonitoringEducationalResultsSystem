﻿using DataAccessLayer.Enums;

namespace BusinessLogicLayer.Models
{
   /// <summary>
   /// Question Model for giving to passing test
   /// </summary>
   public class QuestionForTestModel
   {
      public string Id { get; set; }

      public string QuestionText { get; set; }

      public QuestionType Type { get; set; }

      public int Points { get; set; }

      public string TestId { get; set; }

      public IEnumerable<AnswerForTestModel> Answers { get; set; }
   }
}