﻿namespace BusinessLogicLayer.Models
{
   /// <summary>
   /// User answer model of test result
   /// </summary>
   public class UserAnswerModel
   {
      public string AnswerText { get; set; }

      public string SingleChoiceId { get; set; }

      public ICollection<bool> MultipleChoice { get; set; }

      public string QuestionId { get; set; }
   }
}