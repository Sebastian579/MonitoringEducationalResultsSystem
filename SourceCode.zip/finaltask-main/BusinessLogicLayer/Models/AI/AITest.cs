﻿namespace BusinessLogicLayer.Models.AI
{
	public class AITest
	{
		public string Name { get; set; }

		public int ExecutionTime { get; set; }

		public int PassScore { get; set; }

		public List<AIQuestion> Questions { get; set; }
	}
}
