﻿namespace BusinessLogicLayer.Models.AI
{
	public class AIQuestion
	{
		public string QuestionText { get; set; }

		public int Points { get; set; }

		public List<AIAnswer> Answers { get; set; }
	}
}
