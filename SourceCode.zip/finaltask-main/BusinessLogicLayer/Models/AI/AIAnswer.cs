﻿namespace BusinessLogicLayer.Models.AI
{
	public class AIAnswer
	{
		public string AnswerText { get; set; }

		public bool IsCorrect { get; set; }
	}
}
