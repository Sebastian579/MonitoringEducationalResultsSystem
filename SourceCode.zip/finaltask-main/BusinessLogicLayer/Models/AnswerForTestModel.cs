﻿namespace BusinessLogicLayer.Models
{
   /// <summary>
   /// Answer Model for giving to passing test safely
   /// </summary>
   public class AnswerForTestModel
   {
      public string Id { get; set; }

      public string AnswerText { get; set; }

      public string QuestionId { get; set; }
   }
}