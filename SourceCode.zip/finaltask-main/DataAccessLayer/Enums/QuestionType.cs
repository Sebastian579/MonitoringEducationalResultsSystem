﻿namespace DataAccessLayer.Enums
{
   /// <summary>
   /// Enum of question type
   /// </summary>
   public enum QuestionType
   {
      FreeText = 0,
      SingleChoice = 1,
      MultipleChoice = 2,
      None = 3,
   }
}