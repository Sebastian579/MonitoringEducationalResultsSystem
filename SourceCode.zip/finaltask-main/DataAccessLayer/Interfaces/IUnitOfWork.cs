﻿using DataAccessLayer.Entities;

namespace DataAccessLayer.Interfaces
{
	/// <summary>
	/// Repository wrapper
	/// </summary>
	public interface IUnitOfWork : IDisposable
    {
		/// <summary>
		/// Gets repository by typeParam
		/// </summary>
		/// <typeparam name="TEntity">Represent entity type. Must inherit from BaseEntity</typeparam>
		/// <returns></returns>
		IRepository<TEntity> Repository<TEntity>() where TEntity : BaseEntity;

        /// <summary>
        /// Saves all changes in a DataBase
        /// </summary>
        /// <returns></returns>
        Task SaveAsync();
    }
}
