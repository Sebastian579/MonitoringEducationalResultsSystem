﻿using DataAccessLayer.Entities;
using System.Linq.Expressions;

namespace DataAccessLayer.Interfaces
{
	/// <summary>
	/// General interface for interaction with all entities
	/// </summary>
	/// <typeparam name="TEntity">Represent entity type. Must inherit from BaseEntity</typeparam>
	public interface IRepository<TEntity> where TEntity : BaseEntity
	{
		/// <summary>
		/// Gets all elements from DataBase
		/// </summary>
		/// <returns>All elements</returns>
		Task<IQueryable<TEntity>> GetAllAsync();

		/// <summary>
		/// Gets all elements from DataBase include other entities
		/// </summary>
		/// <param name="includes">Entities, which need be include</param>
		/// <returns>All elements with included entities</returns>
		Task<IQueryable<TEntity>> GetAllWithIncludeAsync(params Expression<Func<TEntity, object>>[] includes);

		/// <summary>
		/// Gets element from DataBase
		/// </summary>
		/// <param name="id">Element id</param>
		/// <returns>Element</returns>
		Task<TEntity> GetByIdAsync(string id);

		/// <summary>
		/// Gets element from DataBase include other entities
		/// </summary>
		/// <param name="id">Element id</param>
		/// <param name="includes">Entities, which need be include</param>
		/// <returns>Element with included entities</returns>
		Task<TEntity> GetByIdWithIncludeAsync(string id, params Expression<Func<TEntity, object>>[] includes);

		/// <summary>
		/// Adds new element to DataBase
		/// </summary>
		/// <param name="entity">Element for adding</param>
		/// <returns></returns>
		Task CreateAsync(TEntity entity);

		/// <summary>
		/// Adds new elements to DataBase
		/// </summary>
		/// <param name="entities">Elements for adding</param>
		/// <returns></returns>
		Task CreateRangeAsync(IEnumerable<TEntity> entities);

		/// <summary>
		/// Update element in DataBase
		/// </summary>
		/// <param name="entity">Element for updating</param>
		/// <returns></returns>
		Task UpdateAsync(TEntity entity);

		/// <summary>
		/// Update elements in DataBase
		/// </summary>
		/// <param name="entities">Elements for updating</param>
		/// <returns></returns>
		Task UpdateRangeAsync(IEnumerable<TEntity> entities);

		/// <summary>
		/// Delete element from DataBase
		/// </summary>
		/// <param name="entity">Element for deleting</param>
		/// <returns></returns>
		Task DeleteAsync(TEntity entity);
	}
}
