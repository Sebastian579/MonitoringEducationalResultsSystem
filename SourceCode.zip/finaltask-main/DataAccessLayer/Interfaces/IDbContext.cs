﻿using Microsoft.EntityFrameworkCore;

namespace DataAccessLayer.Interfaces
{
	/// <summary>
	/// Represents a DataBase
	/// </summary>
	public interface IDbContext : IDisposable
	{
		/// <summary>
		/// Gets Entity by typeParam
		/// </summary>
		/// <typeparam name="TEntity">Represent entity type</typeparam>
		/// <returns>Entity</returns>
		DbSet<TEntity> Set<TEntity>() where TEntity : class;

		/// <summary>
		/// Saves all tracked changes in a DataBase
		/// </summary>
		/// <param name="cancellationToken"></param>
		/// <returns></returns>
		Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
	}
}
