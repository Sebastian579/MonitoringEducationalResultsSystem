﻿using DataAccessLayer.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataAccessLayer.EntitiesConfiguration
{
   public class TestConfiguration : IEntityTypeConfiguration<Test>
   {
      public void Configure(EntityTypeBuilder<Test> builder)
      {
         builder.Property(g => g.CreationDate).HasDefaultValueSql("GETDATE()");
      }
   }
}