﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataAccessLayer.EntitiesConfiguration
{
	/// <summary>
	/// Configuration class for IdentityRole Entity in DataBase
	/// </summary>
	public class IdentityRoleConfiguration : IEntityTypeConfiguration<IdentityRole>
	{
		public void Configure(EntityTypeBuilder<IdentityRole> builder)
		{
			builder.HasData(
				new IdentityRole
				{
					Id = "e60fe7b6-fb13-4267-ab13-75aa7b796ff9",
					Name = "Admin",
					NormalizedName = "ADMIN",
					ConcurrencyStamp = "a4f137f7-3201-4dee-9e6b-efefe70908fa"
				},				
				new IdentityRole
				{
					Id = "76e3e331-d960-4246-9a00-3885fd5bf655",
					Name = "Teacher",
					NormalizedName = "TEACHER",
					ConcurrencyStamp = "1a4e9873-33d8-4be6-b2f4-cca1b68b66ef"
            },
				new IdentityRole
				{
					Id = "d2eb10be-187e-41b5-9ec5-d763b74edcdb",
					Name = "TestModerator",
					NormalizedName = "TESTMODERATOR",
					ConcurrencyStamp = "b51706c6-04b8-4bf3-8283-f55f1293b9ce"
				},
				new IdentityRole
				{
					Id = "6eaee4f4-209e-4a28-8936-156247e145be",
					Name = "User",
					NormalizedName = "USER",
					ConcurrencyStamp = "9e40c481-95fd-437a-9779-259d521ae1ce"
				});
		}
	}
}
