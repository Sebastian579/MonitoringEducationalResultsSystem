﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataAccessLayer.EntitiesConfiguration
{
	/// <summary>
	/// Configuration class for IdentityUserRole Entity in DataBase
	/// </summary>
	public class IdentityUserRoleConfiguration : IEntityTypeConfiguration<IdentityUserRole<string>>
	{
		public void Configure(EntityTypeBuilder<IdentityUserRole<string>> builder)
		{
			builder.HasData(
				new IdentityUserRole<string>
				{
					UserId = "c916ee75-7567-4f71-b0de-62552e483116",
					RoleId = "e60fe7b6-fb13-4267-ab13-75aa7b796ff9"
				},				
				new IdentityUserRole<string>
				{
					UserId = "c916ee75-7567-4f71-b0de-62552e483116",
					RoleId = "76e3e331-d960-4246-9a00-3885fd5bf655"
            },
				new IdentityUserRole<string>
				{
					UserId = "c916ee75-7567-4f71-b0de-62552e483116",
					RoleId = "d2eb10be-187e-41b5-9ec5-d763b74edcdb"
				},
				new IdentityUserRole<string>
				{
					UserId = "c916ee75-7567-4f71-b0de-62552e483116",
					RoleId = "6eaee4f4-209e-4a28-8936-156247e145be"
				});
		}
	}
}
