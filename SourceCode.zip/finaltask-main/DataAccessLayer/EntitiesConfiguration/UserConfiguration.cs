﻿using DataAccessLayer.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataAccessLayer.EntitiesConfiguration
{
	/// <summary>
	/// Configuration class for User Entity in DataBase
	/// </summary>
	public class UserConfiguration : IEntityTypeConfiguration<User>
	{
		public void Configure(EntityTypeBuilder<User> builder)
		{
			var hasher = new PasswordHasher<User>();

			builder.HasData(
				new User
				{
					Id = "c916ee75-7567-4f71-b0de-62552e483116",
					FirstName = "Sebastian",
					LastName = "Sirko",
					UserName = "Sebastian",
					NormalizedUserName = "SEBASTIAN",
					Email = "sebisirko@gmail.com",
					NormalizedEmail = "SEBISIRKO@GMAIL.COM",
					SecurityStamp = "QT4BOKNFMAWDVXB7BNYRKXHBSZNBURML",
					ConcurrencyStamp = "b4eeff12-8ac6-423b-b2e0-ed38e50ecbfd",
					PasswordHash = hasher.HashPassword(null, "QwertyS")
				});
		}
	}
}
