﻿using System.ComponentModel.DataAnnotations;

namespace DataAccessLayer.Entities
{
   /// <summary>
   /// Test Entity
   /// </summary>
   public class Test : BaseEntity
   {
      public string Name { get; set; }

      public int ExecutionTime { get; set; }

      public int PassScore { get; set; }

      public DateTime CreationDate { get; set; }

      [Required]
      public string UserId { get; set; }

      /// <summary>
      /// Navigation property to User entity
      /// </summary>
      public User User { get; set; }

      /// <summary>
      /// Navigation property to Question entity
      /// </summary>
      public ICollection<Question> Questions { get; set; }

      /// <summary>
      /// Navigation property to TestStatistics entity
      /// </summary>
      public TestStatistics TestStatistics { get; set; }
   }
}