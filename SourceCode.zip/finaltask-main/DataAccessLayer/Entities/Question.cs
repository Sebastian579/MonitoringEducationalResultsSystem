﻿using DataAccessLayer.Enums;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccessLayer.Entities
{
   /// <summary>
   /// Question Entity
   /// </summary>
   public class Question : BaseEntity
   {
      public string QuestionText { get; set; }

      public int Points { get; set; }

      [Column(TypeName = "nvarchar(20)")]
      public QuestionType Type { get; set; }

      [Required]
      public string TestId { get; set; }

      /// <summary>
      /// Navigation property to Test entity
      /// </summary>
      public Test Test { get; set; }

      /// <summary>
      /// Navigation property to Answer entity
      /// </summary>
      [Required]
      public ICollection<Answer> Answers { get; set; }
   }
}