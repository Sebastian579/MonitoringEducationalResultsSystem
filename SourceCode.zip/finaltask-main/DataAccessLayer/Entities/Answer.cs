﻿using System.ComponentModel.DataAnnotations;

namespace DataAccessLayer.Entities
{
   public class Answer : BaseEntity
   {
      public string AnswerText { get; set; }

      public bool IsCorrect { get; set; }

      [Required]
      public string QuestionId { get; set; }

      /// <summary>
      /// Navigation property to Question entity
      /// </summary>
      public Question Question { get; set; }
   }
}
