﻿using Microsoft.AspNetCore.Identity;

namespace DataAccessLayer.Entities
{
   /// <summary>
   /// User Entity
   /// </summary>
   public class User : IdentityUser
   {
      public string FirstName { get; set; }

      public string LastName { get; set; }

      /// <summary>
      /// Navigation property to Test entity
      /// </summary>
      public ICollection<Test> Tests { get; set; }

      /// <summary>
      /// Navigation property to UserStatistics entity
      /// </summary>
      public UserStatistics UserStatistics { get; set; }
   }
}