﻿namespace DataAccessLayer.Entities
{
    /// <summary>
    /// Base class for all entities
    /// </summary>
    public abstract class BaseEntity
    {
        public string Id { get; set; }
    }
}
