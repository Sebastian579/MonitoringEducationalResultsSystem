﻿using System.ComponentModel.DataAnnotations;

namespace DataAccessLayer.Entities
{
	/// <summary>
	/// TestStatistics Entity
	/// </summary>
	public class TestStatistics : BaseEntity
	{
		public int AttemptCount { get; set; }

		public int PassCount { get; set; }

		[Required]
		public string TestId { get; set; }

		/// <summary>
		/// Navigation property to Test entity
		/// </summary>
		public Test Test { get; set; }
	}
}
