﻿using System.ComponentModel.DataAnnotations;

namespace DataAccessLayer.Entities
{
   /// <summary>
   /// UserStatistics Entity
   /// </summary>
   public class UserStatistics : BaseEntity
   {
      public int AttemptCount { get; set; }

      public int PassCount { get; set; }

      [Required]
      public string UserId { get; set; }

      /// <summary>
      /// Navigation property to User entity
      /// </summary>
      public User User { get; set; }
   }
}