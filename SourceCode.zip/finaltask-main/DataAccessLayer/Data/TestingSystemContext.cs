﻿using DataAccessLayer.Entities;
using DataAccessLayer.EntitiesConfiguration;
using DataAccessLayer.Interfaces;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DataAccessLayer.Data
{
   public class TestingSystemContext : IdentityDbContext<User>, IDbContext
   {
      /// <summary>
      /// Constructor
      /// </summary>
      /// <param name="options">DataBase options</param>
      public TestingSystemContext(DbContextOptions<TestingSystemContext> options)
         : base(options) { }

      public DbSet<Test> Tests { get; set; }

      public DbSet<Question> Questions { get; set; }

      public DbSet<Answer> Answers { get; set; }

      public DbSet<TestStatistics> TestStatistics { get; set; }

      public DbSet<UserStatistics> UserStatistics { get; set; }

      protected override void OnModelCreating(ModelBuilder builder)
      {
         builder.ApplyConfiguration(new UserConfiguration());
         builder.ApplyConfiguration(new IdentityRoleConfiguration());
         builder.ApplyConfiguration(new IdentityUserRoleConfiguration());
         builder.ApplyConfiguration(new TestConfiguration());

         base.OnModelCreating(builder);
      }
   }
}