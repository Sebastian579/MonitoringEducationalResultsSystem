﻿using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using DataAccessLayer.Repository;
using System.Collections;

namespace DataAccessLayer.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IDbContext _db;
        private bool _disposedValue;
        private Hashtable _repositories;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db">DataBase</param>
        public UnitOfWork(IDbContext db)
        {
            _db = db;
        }

        public IRepository<TEntity> Repository<TEntity>() where TEntity : BaseEntity
        {
            _repositories ??= new Hashtable();

            var type = typeof(TEntity).Name;

            if (!_repositories.ContainsKey(type))
                _repositories.Add(type, new GenericRepository<TEntity>(_db));

            return _repositories[type] as IRepository<TEntity>;
        }

        public async Task SaveAsync() => await _db.SaveChangesAsync();

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                    _db.Dispose();

                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
