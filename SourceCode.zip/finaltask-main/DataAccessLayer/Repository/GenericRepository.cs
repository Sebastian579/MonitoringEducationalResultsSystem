﻿using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace DataAccessLayer.Repository
{
	public class GenericRepository<TEntity> : IRepository<TEntity> where TEntity : BaseEntity
	{
		private readonly DbSet<TEntity> _entitySet;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="db">DataBase</param>
		public GenericRepository(IDbContext db)
		{
			_entitySet = db.Set<TEntity>();
		}

		public async Task CreateAsync(TEntity entity) => await _entitySet.AddAsync(entity);

		public async Task CreateRangeAsync(IEnumerable<TEntity> entities) => await _entitySet.AddRangeAsync(entities);

		public async Task DeleteAsync(TEntity entity) => await Task.Run(() => _entitySet.Remove(entity));

		public async Task<IQueryable<TEntity>> GetAllAsync() => await Task.Run(() => _entitySet.AsNoTracking());

		public async Task<IQueryable<TEntity>> GetAllWithIncludeAsync(
			params Expression<Func<TEntity, object>>[] includes)
		{
			var query = await Task.Run(() => _entitySet.AsNoTracking());

			return includes.Aggregate(query, (current, includeRepository) => current.Include(includeRepository));
		}

		public async Task<TEntity> GetByIdAsync(string id)
			=> await _entitySet.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

		public async Task<TEntity> GetByIdWithIncludeAsync(string id,
			params Expression<Func<TEntity, object>>[] includes)
		{
			var query = await Task.Run(() => _entitySet.AsNoTracking());

			return await includes.Aggregate(query, (current, includeRepository)
				=> current.Include(includeRepository)).FirstOrDefaultAsync(x => x.Id == id);
		}

		public async Task UpdateAsync(TEntity entity) => await Task.Run(() => _entitySet.Update(entity));

		public async Task UpdateRangeAsync(IEnumerable<TEntity> entities)
			=> await Task.Run(() => _entitySet.UpdateRange(entities));
	}
}
